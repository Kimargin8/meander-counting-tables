# Meandric systems without interval components

Iaroslav Argunov, November 2026.

[Paper](intervals.pdf) · [LaTeX source](intervals.tex) · [Table, orders 0–38](data/interval-free.txt)

The sites are labelled in linear order and the upper and lower matchings are distinguished. A cluster cycle in the sense of Kargin visits exactly the sites of a single interval. The table counts systems without such a cycle. It starts with 1, 0, 0, 0, 4, 64, 806, 9400. The paper also treats the distribution of the number of cluster cycles. The companion [Limit laws for cluster cycles in random meandric systems](background/cluster-laws.pdf) gives the related shape-count results.

Run `python -B verify.py` from this directory, using Python 3.10 or later with assertions enabled. The verifier enumerates all physical pairs through order 8, compares their distributions with the exact coefficient formula, and recomputes the rational growth-rate enclosures and the certificate used in the large-span estimate. The values through 38 use the published connected meander numbers. For the quicker file-integrity check run `python -B verify.py --hashes-only`.

The paper cites Kargin for the underlying object and occurrence probabilities, and Janson and Thévenin for fixed shapes. The term search for an OEIS entry does not establish priority. Licensing and source credits are in [NOTICE.md](NOTICE.md).
