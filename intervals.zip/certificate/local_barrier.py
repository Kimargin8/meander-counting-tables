"""Rational all-K bounds for the explicit high-span catalogue at beta=2189/2368.

All arithmetic in the certificate is integer or rational. Optional independent
enumeration of the eight connected meander numbers uses only the standard library.
"""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
import json
from pathlib import Path

MEANDERS = (1, 2, 8, 42, 262, 1828, 13820, 110954)
ALPHA = F(179, 2368)


def forbidden_series(y):
    return y / (1 - 2*y) + sum((v - 2**i) * y**(i + 1)
                               for i, v in enumerate(MEANDERS))


def forbidden_derivative(y):
    return 1 / (1 - 2*y)**2 + sum((i + 1) * (v - 2**i) * y**i
                                  for i, v in enumerate(MEANDERS))


def slope_den(y):
    return 1 + forbidden_series(y) - 2*y*forbidden_derivative(y)


def equation(x, w):
    return w - (1 + x)**2 + w*forbidden_series((x/w)**2)


def root_bounds(x):
    # Fixed decimal precision controls the size of subsequent integer powers.
    scale = 10**21
    lo, hi = scale, 2*scale
    assert equation(x, F(lo, scale)) < 0 < equation(x, F(hi, scale))
    while hi - lo > 1:
        m = (hi + lo) // 2
        if equation(x, F(m, scale)) > 0:
            hi = m
        else:
            lo = m
    return F(lo, scale), F(hi, scale)


def slope_bounds(x):
    low, high = root_bounds(x)
    y0, y1 = (x/high)**2, (x/low)**2
    num_low = 2*(1+x) - 2*x*forbidden_derivative(y1)/low
    num_high = 2*(1+x) - 2*x*forbidden_derivative(y0)/high
    assert num_low > 0 and slope_den(y1) > 0
    return x*num_low/(high*slope_den(y0)), x*num_high/(low*slope_den(y1))


def rate_exceeds(w, x, threshold):
    p, q = ALPHA.numerator, ALPHA.denominator
    return w**(2*q) > threshold**q * x**(2*p)


def rate_below(w, x, threshold):
    p, q = ALPHA.numerator, ALPHA.denominator
    return w**(2*q) < threshold**q * x**(2*p)


@cache
def matchings(n):
    if n == 0:
        return ((),)
    return tuple((2*k + 1,) + tuple(v + 1 for v in inside) + (0,)
                 + tuple(v + 2*k + 2 for v in outside)
                 for k in range(n) for inside in matchings(k)
                 for outside in matchings(n - 1 - k))


def connected_totals():
    values = []
    for n in range(1, 9):
        count = 0
        for a in matchings(n):
            for b in matchings(n):
                at, size = b[a[0]], 1
                while at:
                    at = b[a[at]]
                    size += 1
                count += size == n
        values.append(count)
    assert tuple(values) == MEANDERS
    return values


def finite_word_checks():
    # Direct suffix matching for three finite cutoff dictionaries, with and
    # without the regular atoms. The four integer letter weights factor as
    # two binary weights (1,2) and (1,3); every balanced 2k-word weighs 6^k.
    from itertools import product
    shapes, atoms = {}, {}
    for n in range(1, 6):
        shapes[n] = set()
        for a in matchings(n):
            for b in matchings(n):
                at, size = b[a[0]], 1
                while at:
                    at = b[a[at]]
                    size += 1
                if size == n:
                    shapes[n].add(tuple(2*(v>i)+(w>i) for i,(v,w) in enumerate(zip(a,b))))
        atoms[n] = {(3,) + tuple(digit for pair in choices for digit in pair) + (0,)
                    for choices in product(((1, 2), (2, 1)), repeat=n-1)}
        assert atoms[n] <= shapes[n]
    checks = 0
    for cutoff, use_atoms in product((2, 3, 4), (False, True)):
        dictionary = set()
        for n in range(1, 6):
            if n <= cutoff:
                dictionary.update(shapes[n])
            elif use_atoms:
                dictionary.update(atoms[n])
        prefixes = {()} | {word[:i] for word in dictionary for i in range(1, len(word))}
        transitions = {}
        for state in prefixes:
            outgoing = []
            for letter, weight in enumerate((1, 2, 3, 6)):
                word = state + (letter,)
                suffixes = [word[i:] for i in range(len(word)+1)]
                if not any(s in dictionary for s in suffixes):
                    outgoing.append((next(s for s in suffixes if s in prefixes), weight))
            transitions[state] = outgoing
        frontier = {(): 1}
        sequence = [1]
        for length in range(1, 11):
            nxt = {}
            for u, val in frontier.items():
                for v, w in transitions[u]:
                    nxt[v] = nxt.get(v, 0) + w*val
            frontier = nxt
            expected = 12*sequence[-1]
            for n in range(1, length//2+1):
                number = MEANDERS[n-1] if n <= cutoff else 2**(n-1) if use_atoms else 0
                expected -= number*6**n*sequence[length-2*n]
            assert sum(frontier.values()) == expected
            sequence.append(expected)
            checks += 1
    return checks


def certificate():
    a, b, c = F(4, 100), F(415, 10000), F(407, 10000)
    eps = F(1, 10**14)
    tail = (16*b*b)**9 / (1 - 16*b*b)
    atom_tail = (2*b*b)**9 / (2 * (1 - 2*b*b))
    assert b*b < F(1, 16)
    assert slope_den(b*b) > F(99, 100)
    assert tail < eps * F(99, 100)
    assert atom_tail < eps * F(99, 100)
    assert eps < a
    for x in (a, b):
        assert rate_exceeds(root_bounds(x)[0] - eps, x, F(189794, 100000))
    assert rate_below(root_bounds(c)[1] + eps, c, F(189791, 100000))
    x0, x1 = F(4070238578615, 10**14), F(4070238578616, 10**14)
    assert a < x0 < x1 < b
    assert slope_bounds(x0)[1] < ALPHA < slope_bounds(x1)[0]
    lower = F(189790472894, 10**11)
    upper = F(189790472895, 10**11)
    assert rate_exceeds((1-eps)*root_bounds(x0)[0], x1, lower)
    assert rate_below(root_bounds(x0)[1] + eps, x0, upper)
    return dict(beta=str(1-ALPHA), alpha=str(ALPHA), known_meanders=MEANDERS,
                minimizer_for_reference_union=[str(x0), str(x1)],
                localization_for_all_K_at_least_eight=[str(a), str(b)],
                additive_root_error_at_most=str(eps), tail_bound=str(tail),
                missing_regular_atom_tail_bound=str(atom_tail),
                families=["all connected intervals through K",
                          "regular atoms plus all connected intervals through K"],
                direct_weighted_language_equalities=finite_word_checks(),
                strict_lower_all_fixed_K=str(lower), strict_upper_K_at_least_eight=str(upper),
                source_sha256=sha256(Path(__file__).read_bytes()).hexdigest())


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    p.add_argument("--verify-counts", action="store_true")
    p.add_argument("--out", type=Path)
    args = p.parse_args()
    if not __debug__:
        p.error("enable assertions")
    result = certificate()
    if args.verify_counts:
        result["independent_connected_pair_counts"] = connected_totals()
    text = json.dumps(result, indent=2) + "\n"
    if args.out:
        args.out.write_text(text, encoding="utf8")
    else:
        print(text, end="")
