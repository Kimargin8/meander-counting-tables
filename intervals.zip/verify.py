"""Run from an extracted review package. Standard Python 3.10 or newer."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent


def compare(script, args, reference, omit=()):
    with TemporaryDirectory() as work:
        out = Path(work)/"result.json"
        subprocess.run([sys.executable, "-B", str(HERE/script), *args, "--out", str(out)],
                       check=True, cwd=HERE)
        actual = json.loads(out.read_text(encoding="utf8"))
    want = json.loads((HERE/"results"/reference).read_text(encoding="utf8"))

    def selected(value):
        if isinstance(value, list):
            return [selected(v) for v in value]
        if isinstance(value, dict):
            return {k:selected(v) for k,v in value.items() if k not in omit}
        return value
    if selected(actual) != selected(want):
        raise ValueError(f"Independent replay disagrees with {reference}")
    print("Reproduced", reference, flush=True)


def main():
    p = ArgumentParser(description=__doc__)
    p.add_argument("--hashes-only", action="store_true")
    args = p.parse_args()
    if not __debug__:
        p.error("enable assertions")
    for line in (HERE/"SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        if sha256((HERE/name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Digest mismatch for {name}")
    print("All packaged files match their SHA-256 hashes.", flush=True)
    if args.hashes_only:
        return
    compare("check.py",["--table","data/b005315.txt","--physical-through","8"],
            "checked.json", ("python",))
    compare("certificate/local_barrier.py",["--verify-counts"],"local-barrier.json")


if __name__ == "__main__":
    main()
