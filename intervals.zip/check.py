"""Exact enumeration and growth enclosures for interval cycles in two labelled banks."""
import argparse
from collections import Counter
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import product
import json
from math import comb
from pathlib import Path
import platform


def power(series, exponent, degree):
    """Coefficients of a unit series to any integral power, from f g' = p f' g."""
    out = [1]
    for n in range(1, degree + 1):
        numerator = sum(((exponent + 1)*j - n)*series[j]*out[n-j]
                        for j in range(1, min(n, len(series)-1)+1))
        value, remainder = divmod(numerator, n)
        assert not remainder
        out.append(value)
    return out


def histogram_formula(n, cat2, counts):
    # H(z/D^2)/D, D=1+(1-t)M(z). First use the variable h=t-1.
    binomial = [0]*(n+1)
    m_power = [1] + [0]*n
    for marks in range(n+1):
        for outer in range(n+1-marks):
            binomial[marks] += cat2[outer]*comb(2*outer+marks, marks)*m_power[n-outer]
        m_power = [sum(counts[j]*m_power[k-j] for j in range(1,k+1))
                   for k in range(n+1)]
    histogram = [sum((-1)**(j-k)*comb(j,k)*binomial[j] for j in range(k,n+1))
                 for k in range(n+1)]
    assert min(histogram) >= 0 and sum(histogram) == cat2[n]
    return histogram


@cache
def banks(n):
    if n == 0:
        return ((),)
    return tuple((2*k+1,) + tuple(x+1 for x in inside) + (0,)
                 + tuple(x+2*k+2 for x in outside) for k in range(n)
                 for inside in banks(k) for outside in banks(n-k-1))


def component_sets(a, b):
    seen = set()
    result = []
    for first in range(len(a)):
        if first in seen:
            continue
        support = set()
        x = first
        while x not in support:
            support.update((x, a[x]))
            x = b[a[x]]
        seen.update(support)
        result.append(support)
    return result


def physical(n):
    hist = Counter()
    joint = Counter()
    seam = Counter()
    connected = 0
    for a, b in product(banks(n), repeat=2):
        comps = component_sets(a,b)
        connected += len(comps) == 1
        interval = [s for s in comps if max(s)-min(s)+1 == len(s)]
        small = sum(len(s)==2 for s in interval)
        hist[len(interval)] += 1
        joint[small,len(interval)-small] += 1
        # A proper cyclic interval crossing the cut can only be the cycle at 0.
        if comps:
            s = comps[0]
            if len(s)<2*n and 2*n-1 in s:
                other = set(range(2*n))-s
                if max(other)-min(other)+1==len(other):
                    seam[len(interval),len(s)//2]+=1
    return [hist[j] for j in range(n+1)], connected, joint, seam


def bivariate(n, cat2, shapes):
    """Coefficients marking order-one and all larger interval components."""
    shape_powers = [[1]+[0]*n]
    for q in range(1,n//2+1):
        prev = shape_powers[-1]
        shape_powers.append([sum(shapes[j]*prev[k-j] for j in range(2,k+1))
                             for k in range(n+1)])
    moments = {}
    for q, series in enumerate(shape_powers):
        for p in range(n-2*q+1):
            moments[p,q] = comb(p+q,p)*sum(
                cat2[m]*comb(2*m+p+q,p+q)*series[n-m-p] for m in range(n-p+1))
    hist = Counter()
    for (p,q), val in moments.items():
        for i in range(p+1):
            for j in range(q+1):
                hist[i,j] += (-1)**(p+q-i-j)*comb(p,i)*comb(q,j)*val
    assert min(hist.values())>=0 and sum(hist.values())==cat2[n]
    return +hist


def near_maximum(counts, cat2, hist):
    """Newton coefficients from the formal series, independently of interpolation."""
    limit = len(counts)-2
    previous = {(0,0): [1]}
    for h in range(1,limit+1):
        for total in range(h,limit+1):
            terms = [0]*(h+1)
            for j in range(1,total-h+2):
                for k,value in enumerate(previous.get((h-1,total-j),())):
                    terms[k] -= counts[j]*value
                    terms[k+1] += (counts[j+1]-counts[j])*value
            previous[h,total] = terms
    polynomials = []
    comparisons = 0
    for d in range(limit+1):
        row = [0]*(2*d+1)
        for m in range(d+1):
            for h in range(d-m+1):
                factor = cat2[m]*comb(2*m+h,h)
                for k,value in enumerate(previous.get((h,d-m),())):
                    for offset in range(2*m+1):
                        row[k+offset] += factor*value*comb(2*m,offset)
        assert row[-1] == cat2[d]
        for n in range(d,len(hist)):
            assert sum(comb(n-d,k)*c for k,c in enumerate(row)) == hist[n][n-d]
            comparisons += 1
        polynomials.append(row)
    samples = []
    for d in (4,8,16,24,32,limit):
        n=d*d
        value=sum(comb(n-d,k)*c for k,c in enumerate(polynomials[d]))
        base=cat2[d]*comb(n+d,2*d)
        samples.append(dict(d=d,n=n,exact=value,leading=base,ratio=value/base))
    return dict(basis="binom(n-d,j), valid n>=d",coefficients=polynomials,
                direct_histogram_comparisons=comparisons,square_root_samples=samples)


def atan_bounds(q):
    terms = [F((-1)**i, (2*i+1)*q**(2*i+1)) for i in range(24)]
    return sum(terms), sum(terms[:-1])


def growth_bounds(cat2, counts):
    last = len(counts)-1
    irreducible = [0]
    for k in range(1, last+1):
        exponent = 1-2*k
        coeff = power(cat2, exponent, k)[k]
        assert coeff % exponent == 0
        irreducible.append(coeff//exponent)
    assert all(a <= b for a,b in zip(counts,irreducible)) and irreducible[4]==46
    a,b = atan_bounds(5)
    c,d = atan_bounds(239)
    pi_lo,pi_hi = 16*a-4*d,16*b-4*c
    scale = 10**13
    h_lower = F((16/pi_hi-4)*scale//1, scale)
    h_upper = F((16/pi_lo-4)*scale//1+1, scale)
    radius = h_lower**2/16
    tail = h_upper-1-sum(v*radius**k for k,v in enumerate(irreducible))
    assert 0 < tail < F(42,10**6)

    def endpoints(s):
        assert s < radius
        low = sum(v*s**k for k,v in enumerate(counts))
        return low,low+tail*(s/radius)**(last+1)

    lo,hi = F(1342726,100000),F(1342845,100000)
    lower, _ = endpoints(1/hi)
    _, upper = endpoints(1/lo)
    assert 16/hi < (1+lower)**2 and 16/lo > (1+upper)**2
    r = F(1,16)
    ratio = r/radius
    assert (last+2)*ratio < last+1
    m0, m0_hi = endpoints(r)
    m1 = sum(k*v*r**k for k,v in enumerate(counts))
    m1_hi = m1+(last+1)*ratio**(last+1)*tail
    var_lo = 2*m0*(1+m0-4*m1_hi)
    var_hi = 2*m0_hi*(1+m0_hi-4*m1)
    assert 0 < var_lo < var_hi
    def six_down(x):
        return (10**6*x).__floor__()
    cumulants = {"scale":10**6, "mean_interval":[six_down(2*m0),six_down(2*m0_hi)+1],
                 "variance_interval":[six_down(var_lo),six_down(var_hi)+1]}
    # For all 0<s<=1/hi the Lagrange root test at the right endpoint alone
    # uses uniqueness of the root throughout the disc, proved in the note.
    return dict(corner_rooted_irreducible=irreducible,
                H_at_critical=[str(h_lower),str(h_upper)],
                irreducible_majorant_point=str(radius),
                upper_majorant_tail_at_point=str(tail),
                linear_cumulants=cumulants,
                growth_interval=list(map(str,(lo,hi))),
                probability_base_interval=list(map(str,(lo/16,hi/16))))


def signs(a):
    return tuple(int(p>i) for i,p in enumerate(a))


def literal_shapes(max_order):
    forbidden = set()
    for n in range(1,max_order+1):
        for a,b in product(banks(n),repeat=2):
            if len(component_sets(a,b))==1:
                forbidden.add(tuple(2*x+y for x,y in zip(signs(a),signs(b))))
    return forbidden


def has_factor(word, shapes):
    return any(word[i:j] in shapes for i in range(len(word))
               for j in range(i+2,len(word)+1,2))


def separator_check():
    nested = tuple(reversed(range(8)))
    two_pairs = (3,2,1,0,7,6,5,4)
    supports = sorted(sorted(i+1 for i in part) for part in component_sets(nested,two_pairs))
    assert supports == [[1,4,5,8],[2,3,6,7]]
    separator = tuple(2*x+y for x,y in zip(signs(nested),signs(two_pairs)))
    # Arbitrary words include those which are not Dyck. An extra direct matching
    # test below can detect arbitrary connected factors up to the whole length.
    def scan(word):
        for start,symbol in enumerate(word):
            if symbol != 3:
                continue
            stacks = [[],[]]
            edges = [{},{}]
            for i in range(start,len(word)):
                letter = word[i]
                if any(not (letter & bit) and not stacks[t] for t,bit in enumerate((2,1))):
                    break
                for t,bit in enumerate((2,1)):
                    if letter & bit:
                        stacks[t].append(i)
                    else:
                        a = stacks[t].pop()
                        edges[t][a]=i
                        edges[t][i]=a
                if not any(stacks):
                    at,visited=start,0
                    while True:
                        at=edges[1][edges[0][at]]
                        visited+=2
                        if at==start:
                            break
                    if visited==i-start+1:
                        return True
        return False
    shapes = literal_shapes(2)
    fragments = [w for length in range(4) for w in product(range(4),repeat=length)]
    for left,right in product(fragments,repeat=2):
        assert scan(left+separator+right)==(has_factor(left,shapes) or has_factor(right,shapes))
    return dict(separator=separator, labelled_supports=supports, arbitrary_joins=len(fragments)**2)


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--table",type=Path,required=True)
    cli.add_argument("--physical-through",type=int,default=7,choices=range(1,9))
    cli.add_argument("--out",type=Path,required=True)
    args=cli.parse_args()
    assert __debug__
    table=dict(tuple(map(int,s.split())) for s in args.table.read_text().splitlines()
               if s.strip() and not s.startswith("#"))
    counts=[0]+[table[n] for n in range(1,39)]
    cat2=[(comb(2*n,n)//(n+1))**2 for n in range(len(counts))]
    hist=[histogram_formula(n,cat2,counts) for n in range(len(counts))]
    joint, cyclic = [], []
    for n in range(39):
        two = bivariate(n,cat2,counts)
        assert [sum(v for (i,j),v in two.items() if i+j==h) for h in range(n+1)]==hist[n]
        seam = {(h,k):(2*k-1)*counts[k]*number for k in range(1,n)
                for h,number in enumerate(hist[n-k]) if number}
        cr = hist[n].copy()
        for (h,_),value in seam.items():
            cr[h]-=value
            cr[h+1]+=value
        assert min(cr)>=0 and sum(cr)==cat2[n]
        cyclic.append(cr)
        if n<=args.physical_through:
            row,conn,literal_two,literal_seam=physical(n)
            assert row==hist[n] and conn==counts[n] and literal_two==two and literal_seam==seam
        joint.append(sorted([i,j,v] for (i,j),v in two.items()))
    result=dict(order_is_half_number_of_sites=True, banks_distinguished=True, cyclic_wrap=False,
                histogram_by_order=hist, zero_cluster_cycle_counts=[h[0] for h in hist],
                direct_pairs=sum(cat2[:args.physical_through+1]), through=args.physical_through,
                separator=separator_check(),bounds=growth_bounds(cat2,counts),
                deficit=near_maximum(counts,cat2,hist),
                bivariate_small_and_long={"entries":"[order-one count, larger count, systems]",
                                          "by_order":joint},
                cyclic_support_histograms=cyclic,
                inputs={p.name:sha256(p.read_bytes()).hexdigest()
                        for p in (args.table,Path(__file__))},python=platform.python_version())
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(result["zero_cluster_cycle_counts"][:10], result["zero_cluster_cycle_counts"][-1],
          result["bounds"]["growth_interval"])


if __name__=="__main__":
    main()
