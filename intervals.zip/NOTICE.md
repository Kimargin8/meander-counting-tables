# Rights and sources
Copyright © 2026 Iaroslav Argunov. Original code is released under the [MIT License](licenses/MIT.txt). The papers and original research data are licensed under [CC BY 4.0](licenses/CC-BY-4.0.txt).
The frozen input data/b005315.txt comes from [OEIS A005315](https://oeis.org/A005315), including enumerations credited there to multiple contributors. It is reproduced under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Original b-file](https://oeis.org/A005315/b005315.txt).

Full share-alike text: [CC BY-SA 4.0](licenses/CC-BY-SA-4.0.txt).
