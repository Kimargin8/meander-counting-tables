# First-bridge parity and open meander numbers modulo four

Iaroslav Argunov · Version 1.0.0. [Permanent record](https://doi.org/10.5281/zenodo.24516878).

Iaroslav Argunov. Computational supplement, November 2026. The manuscript is in `output/research85/pilot/root-congruences.pdf`. The exact counts fix the site labels and distinguish the upper and lower banks. In the first-bridge strings the leftmost entry corresponds to position 1, and the following entries to positions 3, 5 and so on.

On Linux with Python 3.12+ and a C++17 compiler named `g++`, extract this archive and run from its root

~~~sh
python3 -B research/review85/paths/bridge_reading.py
~~~

The check verifies the SHA-256 manifest, enumerates 1,060,374 connected labelled pairs at orders two through nine, checks all 210 public even-size first-bridge entries and computes the determinants and ranks of their circulant matrices over the integers and modulo two. It combines both modular formulas through 98 crossings and cross-checks all 32 exact even-size open counts through 64. By default the transfers are repeated through half-order twelve. Use `--through 19` to repeat all comparisons against the exact-moment implementation, or `--through 21` for all stored parity profiles up to 84 crossings. With `--through 24` the transfer recomputes the three statistics modulo eight for 96 crossings. That order used approximately 10 GiB of memory in the original run.

The separate archive `first-bridge-41-44.zip` inside the results directory contains the exact, position-by-position extension at 41 to 44 crossings, including both odd and even rows, and its own replay. File `A259974-additions.txt` lists the 86 new terms, at indices 421 to 506.

The public data copies come from OEIS [A005315](https://oeis.org/A005315), [A005316](https://oeis.org/A005316), [A000682](https://oeis.org/A000682), [A060206](https://oeis.org/A060206) and Andrew Howroyd's [A259974](https://oeis.org/A259974). The earlier open counts at 60 and 62 crossings have their numerator, divisor and closed reconstruction order in the two files named `result.json`. The paper identifies the predecessors for the marked first bridge and the unmarked symmetry counts. The numerical files document finite checks of the proofs.

## Credits

The exact 41–44 crossing extension and all comparisons with the published tables are supplied in the nested first-bridge rows archive. See [sources and rights](NOTICE.md) for data credits and license scope.
