# Sources and licenses

Copyright © 2026 Iaroslav Argunov for the original contributions.

The original verification programs are released under the [MIT License](licenses/MIT.txt). The original manuscript, explanatory text and original verification records are released under [CC BY 4.0](licenses/CC-BY-4.0.txt).

Reproduced OEIS inputs, their transformations, combined tables and the original contributions to those adaptations are distributed under [CC BY-SA 4.0](licenses/CC-BY-SA-4.0.txt). Credit The On-Line Encyclopedia of Integer Sequences, OEIS Foundation Inc. and the credited contributors. Retain attribution and identify changes when redistributing an adaptation. [OEIS terms](https://oeis.org/wiki/The_OEIS_End-User_License_Agreement)

- [A005315](https://oeis.org/A005315) — closed meanders; E. Alepis, I. Jensen, A. Howroyd and V. Osipov. [Source table](https://oeis.org/A005315/b005315.txt)
- [A005316](https://oeis.org/A005316) — open meanders; A. Khrabrov, I. Jensen, A. Howroyd and contributors. [Source table](https://oeis.org/A005316/b005316.txt)
- [A259974](https://oeis.org/A259974) — first-bridge table; A. Howroyd. [Source table](https://oeis.org/A259974/b259974.txt)
- [A000682](https://oeis.org/A000682) — semi-meanders; OEIS contributors. [Source table](https://oeis.org/A000682/b000682.txt)
- [A060206](https://oeis.org/A060206) — semi-meanders of odd orders; OEIS contributors. [Source table](https://oeis.org/A060206/b060206.txt)
- [A076876](https://oeis.org/A076876) — two-road systems; OEIS contributors; fifth-position identity by H. Hogan in A006661. [Source table](https://oeis.org/A076876/b076876.txt)
- [A380369](https://oeis.org/A380369) — open meanders by exterior upper arches; A. Howroyd. [Source table](https://oeis.org/A380369/b380369.txt)

The A259974 extension supplies indices 421–506. The 86 entries are additions to the b-file. At least 16 can also be recovered from earlier published tables and identities. The original proof and the independent computations are credited to Iaroslav Argunov. Arithmetic adaptations and combined tables are released under CC BY-SA 4.0.
