"""Integer checks of the first-bridge circulant on the public exact rows."""
from hashlib import sha256
from fractions import Fraction
from math import isqrt
import json
from pathlib import Path
from first_bridge import OUT, read_table
from root_residues import degrees, oracle


def circulant(row):
    n = len(row)
    return [[row[(j-i) % n] for j in range(n)] for i in range(n)]


def leading_determinants(matrix):
    a = [r.copy() for r in matrix]
    previous = 1
    minors = []
    for k in range(len(a)):
        pivot = a[k][k]
        minors.append(pivot)
        if k == len(a)-1:
            break
        assert pivot > 0
        for i in range(k+1,len(a)):
            for j in range(k+1,len(a)):
                a[i][j], rem = divmod(a[i][j]*pivot - a[i][k]*a[k][j], previous)
                assert rem == 0
        previous = pivot
    return minors


def rank_mod_two(matrix):
    basis = {}
    for row in matrix:
        vec = sum((x % 2) << i for i,x in enumerate(row))
        while vec:
            k = vec.bit_length()-1
            if k not in basis:
                basis[k] = vec
                break
            vec ^= basis[k]
    return len(basis)


def check_semidefinite(matrix):
    a = [[Fraction(v) for v in row] for row in matrix]
    for i,row in enumerate(a):
        pivot = row[i]
        assert pivot >= 0
        if not pivot:
            assert all(x == 0 for x in row[i:])
            continue
        for j in range(i+1,len(a)):
            scale = a[j][i]/pivot
            for k in range(i+1,len(a)):
                a[j][k] -= scale*row[k]


def valuation(x):
    assert x > 0
    return (x & -x).bit_length()-1


def polynomial_gcd(a,b):
    while b:
        while a and a.bit_length() >= b.bit_length():
            a ^= b << (a.bit_length()-b.bit_length())
        a,b = b,a
    return a


def base_counts(m):
    banks = oracle.matchings(m)
    exterior = [degrees(bank)[0] for bank in banks]
    cuts = [[all(bank[a]<2*k for a in range(2*k)) for k in range(m+1)] for bank in banks]
    counts = [0]*(m+1)
    for i, upper in enumerate(banks):
        for j,lower in enumerate(banks):
            if (exterior[i]+exterior[j])%2 and oracle.connected(upper,lower):
                counts = [a+visible for a,visible in zip(counts,cuts[j])]
    return counts


def main():
    src = OUT / "first-bridge-Howroyd.txt"
    values = read_table(src)
    offset = 1
    result = []
    stored = {}
    prior_open = 1
    for q in range(1,41):
        n = (q+1)//2
        row = [values[offset+i] for i in range(n)]
        offset += n
        if q % 2:
            continue
        a = circulant(row)
        stored[n] = row
        minors = leading_determinants(a)
        assert all(x>0 for x in minors)
        det, rank, total = minors[-1], rank_mod_two(a), sum(row)
        if n >= 2:
            shifted = [[v - (prior_open if i==j else 0) for j,v in enumerate(r)] for i,r in enumerate(a)]
            check_semidefinite(shifted)
        if n & (n-1) == 0:
            assert rank == n and det % 2 == 1
        if n >= 3 and (n-1) & (n-2) == 0:
            assert rank == n-1 and valuation(det) == valuation(total)
        if n>1 and n%2:
            square, remainder = divmod(det,total)
            assert remainder == 0 and isqrt(square)**2 == square
            power = (n-1) & (1-n)
            core = (n-1)//power + 1
            g = sum((x%2)<<i for i,x in enumerate(stored[core][1:]))
            common = polynomial_gcd(g,(1<<n)-1)
            nullity = common.bit_length()  # one plus the polynomial degree
            assert rank == n-nullity
        result.append(dict(n=n, determinant=str(det), rank_mod_two=rank, open_sum=total,
                           determinant_valuation=valuation(det)))
        prior_open = total
    out = OUT / "bridge-matrices.json"
    base_four,base_six = base_counts(4),base_counts(6)
    assert base_four == [22,7,5,7,22] and base_six == [968,270,172,158,172,270,968]
    profiles = json.loads((OUT / "profiles-21.json").read_bytes())["profiles"]
    for n,corank in ((15,3),(29,1)):
        assert n-rank_mod_two(circulant(list(map(int,profiles[str(2*n)])))) == corank
    out.write_text(json.dumps(dict(input_sha256=sha256(src.read_bytes()).hexdigest(),
                                   base_four=base_four,base_six=base_six,rows=result),indent=2)+"\n")
    print(len(result),"exact determinants, ranks, and shifted positivity tests")


if __name__ == "__main__":
    main()
