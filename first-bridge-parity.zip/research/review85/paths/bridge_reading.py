"""Build the reading copy, or verify it and repeat the finite checks on Linux."""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[3]
PATHS = Path("research/review85/paths")
PILOT = Path("research/review85/pilot")
OUT = Path("output/research85/pilot")
EARLIER = [
    "output/research80/open-ear/marked-groups-n31/result.json",
    "output/research83/open62/result.json",
]


def read(path):
    return json.loads(path.read_bytes())


def verify(through):
    hashes = read(ROOT / "SHA256SUMS.json")
    with tempfile.TemporaryDirectory() as folder:
        target = Path(folder)
        for name, digest in hashes.items():
            path = ROOT / name
            if sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError(name)
            copy = target / name
            copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, copy)
        def run(*args):
            return subprocess.check_output(list(map(str, args)), cwd=target, text=True)
        run(sys.executable, "-B", PATHS / "first_bridge.py")
        assert read(target / OUT / "first-bridge-public-check.json") == read(ROOT / OUT / "first-bridge-public-check.json")
        run(sys.executable, "-B", PATHS / "bridge_matrix.py")
        assert read(target / OUT / "bridge-matrices.json") == read(ROOT / OUT / "bridge-matrices.json")
        run(sys.executable, "-B", PATHS / "residue_table.py")
        assert read(target / OUT / "all-even-mod4.json") == read(ROOT / OUT / "all-even-mod4.json")
        run(sys.executable, "-B", PILOT / "related_cells.py")
        assert read(target / OUT / "first-bridge-existing-columns.json") == read(ROOT / OUT / "first-bridge-existing-columns.json")
        run(sys.executable, "-B", PATHS / "root_residues.py")
        direct = read(target / OUT / "root-residues-direct.json")["rows"]
        assert direct == read(ROOT / OUT / "root-residues-direct.json")["rows"]
        run(sys.executable, "-B", PILOT / "mod4.py", "--through", min(through, 19))
        def exact_part(row):
            return {k: v for k, v in row.items() if k != "seconds"}
        exact = read(target / OUT / f"mod4-{min(through, 19)}.json")
        expected = read(ROOT / OUT / "mod4-19.json")
        for key in ("rows", "odd_rows"):
            assert list(map(exact_part, exact[key])) == list(map(exact_part, expected[key][:len(exact[key])]))
        run("g++", "-O3", "-std=c++17", PILOT / "folded.cpp", "-o", target / "folded")
        for row in read(ROOT / OUT / "folded.json")["rows"]:
            m = row["m"]
            if m <= through:
                result = run(target / "folded", m, max(11, m + 3 if m < 20 else m + 4))
                assert list(map(int, result.split()))[:3] == [row[k] for k in ("even_mod8", "odd_mod8", "children_mod8")]
        run("g++", "-O3", "-std=c++17", PILOT / "profile.cpp", "-o", target / "profile")
        for m in range(23,through+1):
            ref = read(ROOT / OUT / f"folded-native-{m}.json")
            result = run(target / "folded",m,ref["slot_bits"])
            assert result.split() == ref["raw_stdout"].split()
        profiles = read(ROOT / OUT / "profiles-21.json")["profiles"]
        for m in range(2, min(through, 21) + 1):
            stored = profiles[str(4 * m)]
            for lo in range(1,m//2+1,7):
                hi = min(m//2,lo+6)
                bits = int(run(target / "profile", m, lo, hi, max(11, m + 5)).split()[0])
                assert all(((bits >> (k-lo)) & 1) == int(stored[2*k]) for k in range(lo,hi+1))
        print(json.dumps(dict(files=len(hashes), exact_closed_pairs=sum(r["closed_count"] for r in direct),
                              public_even_positions=210, half_order_checked=through)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--through", type=int, choices=range(4, 25), default=12)
    args = parser.parse_args()
    verify(args.through)
