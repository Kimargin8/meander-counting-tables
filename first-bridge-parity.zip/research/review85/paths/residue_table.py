"""Combine the two modular formulas and check their overlap with the exact open table."""
from hashlib import sha256
import json
from first_bridge import ROOT, OUT, read_table


def main():
    sources = {}
    def read(name):
        path = OUT / name
        sources[name] = sha256(path.read_bytes()).hexdigest()
        return json.loads(path.read_bytes())
    table = {}
    def add(q,value):
        assert 2 <= q <= 98 and q % 2 == 0 and value in range(4)
        assert table.setdefault(q,value) == value
    moments = read("mod4-19.json")
    for row in moments["rows"] + moments["odd_rows"]:
        add(row["crossings"],row["residue"])
    packed = read("extended.json")
    for row in packed["even"] + packed["odd"]:
        if row["crossings"] <= 98:
            add(row["crossings"],row["residue"])
    for row in read("folded.json")["rows"]:
        double = (row["m"]+1)*row["closed_mass"] + row["odd_mod8"] + row["children_mod8"]
        assert double % 2 == 0 and double//2 % 4 == row["residue"]
        add(row["crossings"],row["residue"])
    closed = read_table(ROOT / "references/oeis/2026-11-15/b005315.txt")
    for m in (23,24):
        native = read(f"folded-native-{m}.json")
        even,odd,children,states = map(int,native["raw_stdout"].split())
        assert native["status"]=="complete" and (even+odd-closed[m])%8 == 0 and states>0
        double = (m+1)*closed[m] + odd + children
        assert double%2 == 0
        add(4*m, double//2%4)
    assert set(table) == set(range(2,99,2))
    known = read_table(ROOT / "references/oeis/2026-11-15/b005316.txt")
    extras = ["output/research80/open-ear/marked-groups-n31/result.json",
              "output/research83/open62/result.json","output/research85/pilot/progress.json"]
    for q,rel in zip((60,62,64),extras):
        known[q] = int(json.loads((ROOT / rel).read_bytes())["open_count"])
    for q in range(2,65,2):
        assert table[q] == known[q] % 4
    result = dict(modulus=4,rows=[dict(crossings=q,residue=table[q]) for q in sorted(table)],
                  checked_exact_through=64,source_sha256=sources)
    (OUT / "all-even-mod4.json").write_text(json.dumps(result,indent=2)+"\n")
    print("49 even crossing numbers through 98; all 32 exact residues through 64 agree")


if __name__=="__main__":
    main()
