"""Check the first-bridge parity law against Andrew Howroyd's complete b-file."""
from hashlib import sha256
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'output/research85/pilot'


def read_table(path):
    return {int(line.split()[0]):int(line.split()[1])
            for line in path.read_text().splitlines() if line.strip() and line.strip()[0].isdigit()}


def tail_blocks(n):
    power=(n-1)&(1-n)
    return 1+(n-1)//power,power


def main():
    source=OUT/'first-bridge-Howroyd.txt'
    flat=read_table(source)
    assert set(flat)==set(range(1,421))
    pos=1
    rows={}
    for crossings in range(1,41):
        count=(crossings+1)//2
        if crossings%2==0: rows[crossings//2]=[flat[i] for i in range(pos,pos+count)]
        pos+=count
    assert pos==421
    checked=[]
    for n,row in rows.items():
        tail=[x%2 for x in row[1:]]
        assert tail==tail[::-1]
        if n>1:
            core,power=tail_blocks(n)
            expanded=[x%2 for x in rows[core][1:] for _ in range(power)]
            assert tail==expanded
            if core==2:
                assert all(tail)
            else:
                assert all(not bit or ((s-1)//power)%2 for s,bit in enumerate(tail,1))
                assert sum(tail)<len(tail)/2
            checked.append(dict(physical_crossings=2*n,core=core,run_length=power,
                                odd_tail_entries=sum(tail),tail_length=len(tail)))
    sample={}
    for core in [2,4,6,8,10,12,14,16,18,20]:
        bits=''.join(str(x%2) for x in rows[core][1:])
        sample[core]=dict(tail_bits=bits,
            general_n=f'1+{core-1}*2^t',multiplicity_of_each_bit='2^t')
    res=dict(source='https://oeis.org/A259974/b259974.txt',author='Andrew Howroyd',
             input_sha256=sha256(source.read_bytes()).hexdigest(),input_entries=420,even_rows=20,
             tested_positions=sum(map(len,rows.values())),full_profile_examples=sample,checked=checked)
    (OUT/'first-bridge-public-check.json').write_text(json.dumps(res,indent=2)+'\n')
    print(res['tested_positions'],'positions in the even rows')


if __name__=='__main__':
    main()
