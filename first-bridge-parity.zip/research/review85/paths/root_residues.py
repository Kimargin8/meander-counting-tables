"""Directly check the bank-symmetric formula for ordinary O_(4m), m>1."""
from fractions import Fraction
from hashlib import sha256
from importlib.util import module_from_spec,spec_from_file_location
import json
from pathlib import Path
import time

ROOT=Path(__file__).resolve().parents[3]
ORACLE=ROOT/'research/review79/open-ear-pilot/check.py'
SPEC=spec_from_file_location('ordered_matchings',ORACLE)
oracle=module_from_spec(SPEC)
SPEC.loader.exec_module(oracle)


def degrees(bank):
    # A whole primitive arch ends at its right partner. Its immediate children
    # are the primitive arches strictly between its endpoints.
    corner=exterior=children=0
    while corner<len(bank):
        right=bank[corner]
        inner=corner+1
        while inner<right:
            children+=1
            inner=bank[inner]+1
        exterior+=1
        corner=right+1
    return exterior,children


def check(m,known):
    match=oracle.matchings(m)
    roots=list(map(degrees,match))
    mass=odd_ordered=all_children=square=exact_abc=0
    for i,bank in enumerate(match):
        k,child=roots[i]
        for j in range(i):
            if not oracle.connected(bank,match[j]): continue
            h,other=roots[j]
            mass+=2
            odd_ordered+=2*((k+h)%2)
            all_children+=2*(child+other)
            square+=(k+h)**2
            exact_abc+=2*k*h+k*(k-1)+h*(h-1)+k+h
    assert exact_abc==square and (2*square-odd_ordered)%8==0
    double=(m+1)*mass+odd_ordered+all_children
    four=(2*m+3)*mass-(mass-2*odd_ordered)+2*all_children
    assert double%8==2*(known[4*m]%4) and four%16==4*(known[4*m]%4)
    return dict(order=m,closed_count=mass,unordered_connected=mass//2,
                mixed_parity_ordered=odd_ordered,all_immediate_children=all_children,
                signed_exterior_evaluation=mass-2*odd_ordered,residue=(double%8)//2)


if __name__=='__main__':
    bfile=ROOT/'references/oeis/2026-11-15/b005316.txt'
    known={int(line.split()[0]):int(line.split()[1]) for line in bfile.read_text().splitlines()
           if line.strip() and line.strip()[0].isdigit()}
    start=time.perf_counter()
    rows=[check(m,known) for m in range(2,10)]
    result=dict(rows=rows,seconds=time.perf_counter()-start,
                sha256={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest()
                        for p in [Path(__file__),ORACLE,bfile]})
    out=ROOT/'output/research85/pilot/root-residues-direct.json'
    out.write_text(json.dumps(result,indent=2)+'\n')
    print('all complete marked pairs:',sum(row['closed_count'] for row in rows))
