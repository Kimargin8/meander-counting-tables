"""Certify first-bridge parity rows by half-order bank-labelled transfer and odd-row doubling."""
import argparse
import os
from pathlib import Path
import platform
import resource
import subprocess
import tempfile
import time
from extended import save
from seams import ROOT,digest,table

HERE=Path(__file__).resolve().parent
OUT=ROOT/'output/research85/pilot'


def main(maximum):
    triangle=OUT/'b259974.txt'
    source=HERE/'profile.cpp'
    checks=table(triangle)
    expected={}
    i=1
    for crossings in range(1,41):
        length=(crossings+1)//2
        if crossings%2==0:
            expected[crossings//2]=[checks[z]%2 for z in range(i,i+length)]
        i+=length
    assert i-1==len(checks)==420
    rows={1:[1],2:[0,1]}
    timings={}
    with tempfile.TemporaryDirectory() as temp:
        exe=Path(temp)/'profile'
        flags=['-O3','-std=c++17']
        subprocess.run(['g++',*flags,source,'-o',exe],check=True)
        for m in range(2,maximum+1):
            vals=[0]*(2*m)
            width=9 if m<=19 else (7 if m<=21 else 5)
            peak=ticks=0
            for lo in range(1,m//2+1,width):
                hi=min(m//2,lo+width-1)
                tic=time.perf_counter()
                bits=min(27,m+5)
                def cap():
                    os.sched_setaffinity(0,{8})
                    resource.setrlimit(resource.RLIMIT_AS,(3<<30,3<<30))
                out=subprocess.check_output(['/usr/bin/time','-f','%M','-o',str(exe)+'.rss',
                        exe,str(m),str(lo),str(hi),str(max(11,bits))],text=True,preexec_fn=cap,timeout=600)
                v,cells=map(int,out.split())
                assert 0<=v<1<<(hi-lo+1)
                for k in range(lo,hi+1):
                    vals[2*k]=vals[2*m-2*k]=(v>>(k-lo))&1
                peak=max(peak,int(Path(str(exe)+'.rss').read_text().strip()))
                ticks+=time.perf_counter()-tic
            rows[2*m]=vals
            timings[m]=dict(seconds=round(ticks,4),peak_worker_rss_kib=peak)
        for n in range(3,2*maximum+1,2):
            left=rows[(n+1)//2]
            rows[n]=[left[0]]+[bit for bit in left[1:] for _ in (0,1)]
        holdouts=sum(len(bits) for n,bits in rows.items() if n in expected)
        for n,bits in sorted(rows.items()):
            if n in expected:
                assert bits==expected[n],(n,bits,expected[n])
            assert len(bits)==n and bits[1:]==list(reversed(bits[1:]))
        files=[source,HERE/'flat_layer.hpp',Path(__file__).resolve(),triangle]
        result=dict(profiles={2*n:''.join(map(str,bits)) for n,bits in sorted(rows.items())},
            definition='Position s is bridge 2s+1. The leftmost character is s=0.',
            checked_against_A259974=holdouts,source_bfile='https://oeis.org/A259974/b259974.txt',
            timings=timings,sha256={p.relative_to(ROOT).as_posix():digest(p) for p in files},
            binary_sha256=digest(exe),python=platform.python_version(),flags=flags,
            compiler=subprocess.check_output(['g++','-dumpfullversion'],text=True).strip())
        save(OUT/f'profiles-{maximum}.json',result)
        print('Compared',holdouts,'published even-size cells.',result['profiles'][4*maximum])


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--through',type=int,choices=range(2,24),default=19)
    main(parser.parse_args().through)
