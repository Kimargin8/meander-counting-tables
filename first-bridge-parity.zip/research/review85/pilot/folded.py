"""Run the exchange-invariant three-field transfer and compare two independent encodings."""
import argparse
import os
from pathlib import Path
import platform
import resource
import subprocess
import tempfile
import time
from extended import HERE,OUT,ROOT,digest,read,save,table


def main(maximum,cap_gib):
    src=HERE/'folded.cpp'
    direct=OUT/'root-residues-direct.json'
    known=OUT/'mod4-19.json'
    other=OUT/'extended.json'
    if not other.is_file():
        raise RuntimeError('Run extended.py first')
    series=ROOT/'references/oeis/2026-11-15/b005315.txt'
    M=table(series)
    ref={r['order']:r for r in read(direct)['rows']}
    exact={r['m']:r for r in read(known)['rows']}
    modular={r['m']:r for r in read(other)['even']}
    sources={p.relative_to(ROOT).as_posix():digest(p) for p in
             (src,HERE/'flat_layer.hpp',HERE/'folded.py',direct,known,series)}
    path=OUT/'folded.json'
    rows={}
    if path.exists() and read(path)['sources']==sources:
        rows={r['m']:r for r in read(path)['rows']}
    compiler=subprocess.check_output(['g++','-dumpfullversion'],text=True).strip()
    flags=['-O3','-std=c++17']
    with tempfile.TemporaryDirectory() as tmp:
        exe=Path(tmp)/'folded'
        subprocess.run(['g++',*flags,src,'-o',exe],check=True)
        for m in range(2,maximum+1):
            if m in rows:
                continue
            bits=min(29,max(11,m+3 if m<20 else m+4))
            def limited():
                mem=cap_gib*(1<<30)
                resource.setrlimit(resource.RLIMIT_AS,(mem,mem))
                os.sched_setaffinity(0,{6})
            tic=time.perf_counter()
            raw=subprocess.check_output(['/usr/bin/time','-f','%M','-o',str(exe)+'.rss',
                    exe,str(m),str(bits)],text=True,preexec_fn=limited,timeout=720)
            sec=time.perf_counter()-tic
            even,odd,children,states=map(int,raw.split())
            assert (even+odd)%8==M[m]%8
            doubled=(m+1)*M[m]+odd+children
            assert doubled%2==0
            answer=doubled//2%4
            if m in ref:
                r=ref[m]
                assert (odd,children,answer)==(r['mixed_parity_ordered']%8,
                                              r['all_immediate_children']%8,r['residue'])
            if m in exact:
                r=exact[m]
                assert (2*r['A'])%8==children and r['residue']==answer
            if m in modular:
                assert modular[m]['residue']==answer
            rows[m]=dict(m=m,crossings=4*m,closed_mass=M[m],even_mod8=even,odd_mod8=odd,
                children_mod8=children,residue=answer,maximum_occupied_slots=states,
                peak_worker_rss_kib=int(Path(str(exe)+'.rss').read_text().strip()),
                seconds=round(sec,4),address_cap_gib=cap_gib,binary_sha256=digest(exe))
            save(path,dict(rows=list(rows.values()),sources=sources,
                           full_field_check=other.relative_to(ROOT).as_posix(),
                           validated_full_field_through=max(set(modular)&set(rows),default=None),
                           compiler=compiler,flags=flags,python=platform.python_version()))
            print('O',4*m,'mod4',answer,'seconds',round(sec,2),'peak KiB',rows[m]['peak_worker_rss_kib'],flush=True)


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--through',type=int,choices=range(2,27),default=22)
    cli.add_argument('--cap-gib',type=int,choices=range(1,9),default=3)
    args=cli.parse_args()
    main(args.through,args.cap_gib)
