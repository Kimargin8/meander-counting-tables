"""Test the four-element action on marked exterior gaps; predict open counts modulo four."""
import argparse
import json
from pathlib import Path
import platform
import resource
import subprocess
import tempfile
from time import perf_counter
from seams import ROOT, digest, oracle, outside, table

HERE=Path(__file__).resolve().parent


def image(bank, offset, sign):
    n=len(bank)
    new=[None]*n
    for i,v in enumerate(bank):
        new[(offset+sign*i)%n]=(offset+sign*v)%n
    return tuple(new)


def fixed_sets(n):
    banks=oracle.matchings(n)
    counts=dict(identity=0,exchange=0,mirror=0,composition=0,both=0)
    for lower in banks:
        gaps=[2*s%(2*n) for s in outside(lower)]
        for upper in banks:
            if not oracle.connected(upper,lower): continue
            for h in gaps:
                x=2*h%(2*n)==0 and all(image(p,-h,1)==p for p in (lower,upper))
                y=2*h%(2*n)==0 and all(image(p,-1,-1)==p for p in (lower,upper))
                xy=all(image(p,h-1,-1)==p for p in (lower,upper))
                counts['identity']+=1
                counts['exchange']+=x
                counts['mirror']+=y
                counts['composition']+=xy
                counts['both']+=int(x and y)
    return counts


def certify(maximum):
    start=perf_counter()
    data=ROOT/'references/oeis/2026-11-15'
    closed,open_file=data/'b005315.txt',data/'b005316.txt'
    M,O=table(closed),table(open_file)
    recent=ROOT/'output/research80/open-ear/marked-groups-n31/result.json'
    O[60]=int(json.loads(recent.read_bytes())['open_count'])
    direct62=ROOT/'output/research83/open62/result.json'
    O[62]=int(json.loads(direct62.read_bytes())['open_count'])
    src=HERE/'corners.cpp'
    rows=[]
    with tempfile.TemporaryDirectory() as tmp:
        helper=Path(tmp)/'corner-counts'
        flags=['-O3','-std=c++17']
        subprocess.run(['g++',*flags,str(src),'-o',helper],check=True)
        exe_hash=digest(helper)
        for m in range(1,maximum+1):
            tic=perf_counter()
            raw=subprocess.check_output([helper,str(m)],text=True,timeout=90)
            mass,E,E2,A,B,C,states=map(int,raw.split())
            assert mass==M[m] and E==E2==O[2*m]
            assert (m+1)*mass%2==0
            T=(m+1)*mass//2
            predicted=(M[2*m]+T+C+A+2*B-E)%4
            row=dict(m=m,n=2*m,crossings=4*m,M_half=mass,E_half=E,M_full=M[2*m],
                     A=A,B=B,C=C,equal_halves=T,modulus=4,residue=predicted,
                     maximum_layer_states=states,seconds=round(perf_counter()-tic,4))
            if m<=4:
                fixed=fixed_sets(2*m)
                assert fixed['identity']==O[4*m]
                assert fixed['exchange']==M[2*m]+T
                assert fixed['mirror']==3*E
                assert fixed['composition']==C+A+2*B+2*E
                assert (fixed['both']-2*E)%2==E%2
                assert (fixed['exchange']+fixed['mirror']+fixed['composition']-
                        2*fixed['both']-fixed['identity'])%4==0
                row['direct_fixed_sets']=fixed
            if 4*m in O:
                assert predicted==O[4*m]%4
                row['known_value']=str(O[4*m])
            rows.append(row)
    checked=sum('known_value' in row for row in rows)
    odd_rows=[]
    for n in range(1,2*maximum,2):
        j=(n+1)//2
        exposed=2*(O[2*j]-M[j])
        predicted=(M[n]+exposed)%4
        odd=dict(n=n,crossings=2*n,half_order=j,M_full=M[n],M_half=M[j],
                 E_half=O[2*j],exposed=exposed,modulus=4,residue=predicted)
        if 2*n in O:
            assert predicted==O[2*n]%4
            odd['known_value']=str(O[2*n])
        if n<=7:
            fixed=fixed_sets(n)
            assert fixed['exchange']==M[n] and fixed['mirror']==fixed['both']==O[n]
            assert fixed['composition']==O[n]+exposed
            odd['direct_fixed_sets']=fixed
        odd_rows.append(odd)
    sources=[Path(__file__),HERE/'seams.py',src,closed,open_file,recent,direct62]
    result=dict(rows=rows,odd_rows=odd_rows,known_held_out=checked,
                known_held_out_odd=sum('known_value' in row for row in odd_rows),
                elapsed_seconds=round(perf_counter()-start,4),
                peak_process_rss_kib=max(resource.getrusage(kind).ru_maxrss for kind in
                    (resource.RUSAGE_SELF,resource.RUSAGE_CHILDREN)),python=platform.python_version(),
                compiler=subprocess.check_output(['g++','-dumpfullversion'],text=True).strip(),
                flags=flags,helper_sha256=exe_hash,
                sha256={p.relative_to(ROOT).as_posix():digest(p) for p in sources})
    out=ROOT/f'output/research85/pilot/mod4-{maximum}.json'
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(rows[-1], 'held out', checked, 'seconds',result['elapsed_seconds'])


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--through',type=int,choices=range(1,20),default=19)
    certify(parser.parse_args().through)
