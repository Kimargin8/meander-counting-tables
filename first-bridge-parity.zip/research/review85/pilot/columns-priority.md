# Previously determined entries in rows 41 to 44

The public first-bridge table of Andrew Howroyd contained 420 entries through 40 crossings in the copy used for the calculation. Rows 41 to 44 add 86 entries to that table. At least 16 of those entries already follow from other public data and reflection. The remaining 70 entries have not received a comprehensive priority review. [A259974](https://oeis.org/A259974)

| Crossings | Positions supplied by the total counts | Additional positions supplied by published columns |
|---:|---|---|
| 41 | 1, 41 | 3, 39 |
| 42 | 1, 3, 41 | 5, 39 |
| 43 | 1, 43 | |
| 44 | 1, 3, 43 | 5, 41 |

For even \(q=2n\), bridge 1 gives the closed count \(M_n\) and bridge 3 gives the open count \(O_{q-2}\). The reflection of a bridge after the first cell pairs its column \(s\) with \(n-s\), with bridge \(2s+1\). For odd \(q=2n-1\), the endpoint cells both give \(O_{q-1}\). [Closed counts](https://oeis.org/A005315) · [Open counts](https://oeis.org/A005316)

Howroyd records the odd-crossing bridge-3 column as column 1 of the triangle for open meanders counted by exterior top arches. Substitution of its 20 published nontrivial orders gives agreement in all 20 cases. At 41 crossings this yields 53068346437495316. [A380369](https://oeis.org/A380369) · [Published table](https://oeis.org/A380369/b380369.txt)

Hunter Hogan gives the even-crossing bridge-5 value by adding the two-road meander count and the open count, both at four fewer crossings. We checked all 20 even orders from 6 to 44. In particular the public terms at 38 and 40 crossings give 87403949721328864 and 911707851407544350 in the bridge-5 column at 42 and 44 crossings respectively. The two half-order moment formulas in the calculation report provide another computation of these entries. [A006661, formula dated 17 September 2026](https://oeis.org/A006661) · [Two-road counts](https://oeis.org/A076876/b076876.txt)

The machine-readable cross-check lists the 16 b-file indices and gives content hashes of its input tables. [Cross-check](../../../output/research85/pilot/first-bridge-existing-columns.json) · [Program](related_cells.py)
