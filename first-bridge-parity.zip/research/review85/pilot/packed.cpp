// Six residues modulo four in 12 bits; one labelled planar frontier per key.
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <vector>

#include "flat_layer.hpp"
constexpr Word MASK=(1U<<12)-1;

Residues plus4(Residues a,Residues b) {
    return (a^b)^((a&b&0x555U)<<1);
}

using Layer=FlatLayer<12,plus4>;

int mate(Word w,int j) {
    const bool up=(w>>j)&1;
    int balance=0;
    for(;;j+=up?1:-1) {
        if(j<0 || j>46) throw std::logic_error("invalid link pattern");
        balance+=bool((w>>j)&1)==up?1:-1;
        if(!balance) return j;
    }
}

Residues advance(Residues x,bool top,bool bottom,bool child) {
    auto mass=x&3,upper=(x>>2)&3,lower=(x>>4)&3;
    const auto increments=(top*mass<<2)|(bottom*mass<<4)|(child*mass<<6)
        |(top*upper<<8)|(((top*lower+bottom*upper+top*bottom*mass)&3)<<10);
    return plus4(x,increments);
}

int main(int argc,char** argv) {
    if(argc!=3) return 2;
    const int n=std::atoi(argv[1]), slot_bits=std::atoi(argv[2]);
    if(n<1 || n>23 || slot_bits<10 || slot_bits>28) return 2;
    auto max_slots=std::size_t(1)<<slot_bits;
    Layer layer(64,max_slots);
    layer.add(1ULL<<5,1);
    Residues final=0;
    std::size_t peak=0;
    for(int i=0;i<2*n;++i) {
        std::size_t cap=64;
        // Reuse the measured scale while leaving enough room for cancellations.
        while(cap<max_slots && cap<layer.size()) cap*=2;
        Layer next(cap,max_slots);
        int left=2*n-i-1;
        for(const Word cell:layer) {
            Residues x=cell&MASK;
            if(!x) continue;
            Word k=cell>>12;
            int l=2*int(k&31)+(i&1);
            Word w=k>>5;
            int len=63-__builtin_clzll(w),u=len-l;
            w^=Word(1)<<len;
            auto send=[&](Word pattern,int low,int high,bool top,bool bot) {
                if(low>left || high>left) return;
                const Word target=((pattern|(Word(1)<<(low+high)))<<5)|(low>>1);
                next.add(target,advance(x,top && u==1,bot && l==1,top && u==2));
            };
            if(l<left && u<left) {
                const Word before=(Word(1)<<l)-1;
                send((w&before)|(Word(1)<<l)|((w&~before)<<2),l+1,u+1,false,false);
            }
            if(l<left && u) send(w,l+1,u-1,true,false);
            if(u<left && l) send(w,l-1,u+1,false,true);
            if(!l || !u) continue;
            int a=l-1;
            int signs=(w>>a)&3;
            if(signs==1) {
                if(!left && len==2) final=plus4(final,advance(x,u==1,l==1,u==2));
                continue;
            }
            Word v=w;
            if(signs==3) v^=Word(1)<<mate(w,l);
            if(signs==0) v^=Word(1)<<mate(w,a);
            send((v&((Word(1)<<a)-1))|((v>>(a+2))<<a),l-1,u-1,true,true);
        }
        peak=std::max(peak,next.size());
        layer=std::move(next);
    }
    for(int j=0;j<6;++j) std::cout<<((final>>(2*j))&3)<<" ";
    std::cout<<peak<<"\n";
}
