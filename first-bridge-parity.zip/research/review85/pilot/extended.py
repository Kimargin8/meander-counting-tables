"""Compute open residues with no full-order closed inputs."""
import argparse
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import tempfile
import time
from seams import ROOT,digest,table

HERE=Path(__file__).resolve().parent
OUT=ROOT/'output/research85/pilot'


def read(path):
    return json.loads(path.read_bytes())


def save(path,content):
    tmp=path.with_suffix('.new')
    tmp.write_text(json.dumps(content,indent=2)+'\n',encoding='utf8')
    tmp.replace(path)


def main(maximum):
    old=OUT/'mod4-19.json'
    previous=read(old)
    check={r['m']:r for r in previous['rows']}
    directory=ROOT/'references/oeis/2026-11-15'
    mf,ef=directory/'b005315.txt',directory/'b005316.txt'
    semi=ROOT/'references/oeis/historical/A000682.txt'
    semi_check=ROOT/'references/oeis/historical/A060206.txt'
    M,O,S,diag=map(table,(mf,ef,semi,semi_check))
    assert all(S[2*i+1]==v for i,v in diag.items() if 2*i+1 in S)
    odd=[]
    for n in sorted(k for k in S if k>1 and k%2):
        j=(n+1)//2
        predicted=(M[j]-S[n]+2*O[2*j])%4
        if n in M:
            assert (M[n]+M[j]+S[n])%4==0
            assert predicted==(M[n]+2*(O[2*j]-M[j]))%4
        odd.append(dict(crossings=2*n,residue=predicted,half_closed=M[j],half_open=O[2*j],
                        semimeanders=S[n]))
    src=HERE/'packed.cpp'
    common=[src,HERE/'flat_layer.hpp',Path(__file__).resolve(),old,mf,ef,semi,semi_check]
    sources={p.relative_to(ROOT).as_posix():digest(p) for p in common}
    flags=['-std=c++17','-O3']
    out=OUT/'extended.json'
    rows={}
    if out.exists():
        last=read(out)
        if last['sources']==sources:
            rows={r['m']:r for r in last['even']}
    def write():
        save(out,dict(odd=odd,even=list(rows.values()),sources=sources,
             semi_source='https://oeis.org/A000682/b000682.txt',crosscheck_source='https://oeis.org/A060206',
             closed_symmetry_source='https://oeis.org/A077460',flags=flags,compiler=compiler,
             python=platform.python_version()))
    compiler=subprocess.check_output(['g++','-dumpfullversion'],text=True).strip()
    write()
    with tempfile.TemporaryDirectory() as tmp:
        exe=Path(tmp)/'packed'
        subprocess.run(['g++',*flags,src,'-o',exe],check=True)
        def limited(m):
            bits=min(28,max(11,m+5))
            def cap():
                # Each slot uses 8 bytes. During growth at most three tables
                # coexist, including the old table being reinserted.
                allowed=(3*(1<<bits)*8)+(128<<20)
                resource.setrlimit(resource.RLIMIT_AS,(allowed,allowed))
                os.sched_setaffinity(0,{6})
            return subprocess.check_output(['/usr/bin/time','-f','%M','-o',str(exe)+'.rss',
                                            exe,str(m),str(bits)],text=True,preexec_fn=cap,timeout=450)
        for m in range(1,maximum+1):
            if m in rows: continue
            tic=time.perf_counter()
            raw=limited(m)
            elapsed=time.perf_counter()-tic
            mass,E,E2,A,B,C,states=map(int,raw.split())
            assert mass==M[m]%4 and E==E2==O[2*m]%4
            T=(m+1)*M[m]//2
            predicted=(T+A+2*B+C+E)%4
            if m in check:
                ref=check[m]
                assert [A,B,C]==[ref[k]%4 for k in ('A','B','C')] and predicted==ref['residue']
                assert (ref['M_full']+2*E)%4==0
            if m%2==0:
                assert C==0
            rows[m]=dict(m=m,crossings=4*m,residue=predicted,mass_mod4=mass,
                upper_mod4=E,lower_mod4=E2,A_mod4=A,B_mod4=B,C_mod4=C,T_mod4=T%4,
                maximum_occupied_slots=states,seconds=round(elapsed,4),
                peak_worker_rss_kib=int(Path(str(exe)+'.rss').read_text().strip()),
                binary_sha256=digest(exe))
            write()
            print('O',4*m,'mod 4 =',predicted,'seconds',round(elapsed,2),'peak KiB',
                  rows[m]['peak_worker_rss_kib'],flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--through',type=int,choices=range(1,24),default=20)
    main(parser.parse_args().through)
