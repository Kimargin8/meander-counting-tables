#pragma once
#include <cstdint>
#include <stdexcept>
#include <vector>
using Word=std::uint64_t;
using Residues=unsigned;
inline Word mix(Word x) {
    x^=x>>30; x*=0xbf58476d1ce4e5b9ULL;
    x^=x>>27; x*=0x94d049bb133111ebULL;
    return x^(x>>31);
}

template<unsigned Bits, unsigned (*Combine)(unsigned,unsigned)>
class FlatLayer {
    static constexpr Word MASK=(1U<<Bits)-1;
    std::vector<Word> slots;
    std::size_t entries=0;
    std::size_t limit;
    std::size_t locate(Word key) const {
        const auto mask=slots.size()-1;
        auto i=std::size_t(mix(key))&mask;
        while(slots[i] && (slots[i]>>Bits)!=key) i=(i+1)&mask;
        return i;
    }
    void grow() {
        if(slots.size()>=limit) throw std::runtime_error("declared table cap");
        std::vector<Word> old(2*slots.size());
        slots.swap(old);
        entries=0;
        for(const Word v:old) if(v&MASK) {
            slots[locate(v>>Bits)]=v;
            ++entries;
        }
    }
public:
    FlatLayer(std::size_t capacity,std::size_t max_slots):slots(capacity),limit(max_slots) {}
    auto begin() const {return slots.begin();}
    auto end() const {return slots.end();}
    auto size() const {return entries;}
    void add(Word key,Residues value) {
        auto i=locate(key);
        if(!slots[i]) {
            if((entries+1)*4>slots.size()*3) {grow();i=locate(key);}
            slots[i]=(key<<Bits)|value;
            ++entries;
        } else {
            slots[i]=(key<<Bits)|Combine(Residues(slots[i]&MASK),value);
        }
    }
};

