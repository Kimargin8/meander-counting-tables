// Bank exchange preserves exterior parity and the sum of both child counts.
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <utility>
#include "flat_layer.hpp"

constexpr unsigned MASK=511;
Residues plus8(Residues a,Residues b) {
    auto x=a^b,first=(a&b&0x49U)<<1;
    return x^first^(((a&b&0x92U)|(x&first))<<1);
}
using Layer=FlatLayer<9,plus8>;

Word mirror(Word w,int len) {
    Word x=~w;
    x=((x>>1)&0x5555555555555555ULL)|((x&0x5555555555555555ULL)<<1);
    x=((x>>2)&0x3333333333333333ULL)|((x&0x3333333333333333ULL)<<2);
    x=((x>>4)&0x0f0f0f0f0f0f0f0fULL)|((x&0x0f0f0f0f0f0f0f0fULL)<<4);
    return __builtin_bswap64(x)>>(64-len);
}

Word canonical(Word w,int l,int u) {
    int len=l+u;
    if(!len) return 0;
    if(l>=u) {
        Word refl=mirror(w,len);
        if(l>u || refl<w) {w=refl;std::swap(l,u);}
    }
    // The first endpoint always opens, the last always closes.
    return ((((w>>1)|(Word(1)<<(len-2)))<<4)|(l>>1));
}

int mate(Word w,int j) {
    const bool up=(w>>j)&1;
    int excess=0;
    for(;;j+=up?1:-1) {
        if(j<0 || j>52) throw std::logic_error("unpaired endpoint");
        excess+=bool((w>>j)&1)==up?1:-1;
        if(!excess) return j;
    }
}

unsigned advance(unsigned x,bool toggle,int children) {
    auto even=x&7,odd=(x>>3)&7,mark=(x>>6)&7;
    if(toggle) std::swap(even,odd);
    mark=(mark+children*(even+odd))&7;
    return even|(odd<<3)|(mark<<6);
}

int main(int argc,char** argv) {
    if(argc!=3) return 2;
    const int n=std::atoi(argv[1]),bits=std::atoi(argv[2]);
    if(n<1 || n>26 || bits<10 || bits>29) return 2;
    std::size_t limit=std::size_t(1)<<bits,peak=0;
    Layer layer(64,limit);
    layer.add(0,1);
    unsigned result=0;
    for(int i=0;i<2*n;++i) {
        std::size_t cap=64;
        while(cap<limit && cap<layer.size()) cap*=2;
        Layer next(cap,limit);
        int left=2*n-i-1;
        for(Word cell:layer) {
            auto x=unsigned(cell&MASK);
            if(!x) continue;
            Word k=cell>>9,encoded=k>>4;
            int l=2*int(k&15)+(i&1);
            int len=encoded?65-__builtin_clzll(encoded):0,u=len-l;
            Word w=len?((encoded^(Word(1)<<(len-2)))<<1)|1:0;
            auto send=[&](Word nw,int low,int high,bool tc,bool bc) {
                if(low>left || high>left) return;
                bool toggle=(tc && u==1)!=(bc && l==1);
                int children=(tc && u==2)+(bc && l==2);
                next.add(canonical(nw,low,high),advance(x,toggle,children));
            };
            if(l<left && u<left) {
                Word mask=(Word(1)<<l)-1;
                send((w&mask)|(Word(1)<<l)|((w&~mask)<<2),l+1,u+1,false,false);
            }
            if(u && l<left) send(w,l+1,u-1,true,false);
            if(l && u<left) send(w,l-1,u+1,false,true);
            if(!u || !l) continue;
            int a=l-1,signs=(w>>a)&3;
            if(signs==1) {
                if(!left && len==2)
                    result=plus8(result,advance(x,(u==1)!=(l==1),(u==2)+(l==2)));
            } else {
                Word v=w;
                if(signs==3) v^=Word(1)<<mate(w,l);
                if(signs==0) v^=Word(1)<<mate(w,a);
                send((v&((Word(1)<<a)-1))|((v>>(a+2))<<a),l-1,u-1,true,true);
            }
        }
        peak=std::max(peak,next.size());
        layer=std::move(next);
    }
    std::cout<<(result&7)<<" "<<((result>>3)&7)<<" "<<((result>>6)&7)<<" "<<peak<<"\n";
}
