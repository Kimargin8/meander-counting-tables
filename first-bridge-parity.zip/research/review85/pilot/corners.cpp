// Sweep labelled meanders, carrying the first two exterior-arch moments.
// Frontier endpoints are in their planar order, split into lower and upper lists.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <unordered_map>
using U=std::uint64_t;

struct Moments {
    U count{},upper{},lower{},children{},pairs{},product{};
};

void add(Moments& z,const Moments& a,int upper,int lower,int child) {
    z.count+=a.count;
    z.upper+=a.upper+upper*a.count;
    z.lower+=a.lower+lower*a.count;
    z.children+=a.children+child*a.count;
    z.pairs+=a.pairs+upper*a.upper;
    z.product+=a.product+upper*a.lower+lower*a.upper+upper*lower*a.count;
}

U key(U w,int l,int len) { return w|(U(l)<<40)|(U(len)<<46); }

int partner(U w,int at) {
    bool open=((w>>at)&1U)!=0;
    int excess=0;
    for(int j=at;;j+=open?1:-1){
        if(j<0 || j>=40) throw std::logic_error("unpaired endpoint");
        excess+=bool((w>>j)&1U)==open?1:-1;
        if(!excess) return j;
    }
}

int main(int argc,char** argv){
    if(argc!=2) return 2;
    int n=std::stoi(argv[1]);
    if(n<1 || n>19) return 2;
    // Each single path contributes at most n*n to any moment. Before merging
    // two rows their counts are at most UINT64_MAX/2048, so every addition
    // fits, then we enforce the same invariant on the result.
    std::unordered_map<U,Moments> layer;
    layer[0].count=1;
    std::size_t peak=1;
    Moments final{};
    for(int i=0;i<2*n;++i){
        int left=2*n-i-1;
        std::unordered_map<U,Moments> next;
        for(const auto& entry:layer){
            U k=entry.first, w=k&((U(1)<<40)-1);
            int l=(k>>40)&63, length=k>>46, u=length-l;
            const auto& old=entry.second;
            auto record=[&](U ww,int low,int up,bool close_u,bool close_l){
                if(low>left || up>left) return;
                Moments& dst=next[key(ww,low,low+up)];
                add(dst,old,close_u && u==1,close_l && l==1,close_u && u==2);
                if(dst.count>std::numeric_limits<U>::max()/2048)
                    throw std::overflow_error("conservative whole-moment bound");
                if(next.size()>7000000) throw std::runtime_error("state cap");
            };
            if(l<left && u<left){
                U before=(U(1)<<l)-1;
                U opened=(w&before)|(U(1)<<l)|((w&~before)<<2);
                record(opened,l+1,u+1,false,false);
            }
            if(u && l<left) record(w,l+1,u-1,true,false);
            if(l && u<left) record(w,l-1,u+1,false,true);
            if(l && u){
                int a=l-1,b=l;
                U signs=(w>>a)&3U;
                if(signs==1){
                    if(!left && length==2) {
                        add(final,old,u==1,l==1,u==2);
                        if(final.count>std::numeric_limits<U>::max()/2048)
                            throw std::overflow_error("final count bound");
                    }
                }else{
                    U v=w;
                    if(signs==3) v^=U(1)<<partner(w,b);
                    if(signs==0) v^=U(1)<<partner(w,a);
                    U before=(U(1)<<a)-1;
                    record((v&before)|((v>>(a+2))<<a),l-1,u-1,true,true);
                }
            }
        }
        peak=std::max(peak,next.size());
        layer.swap(next);
    }
    std::cout<<final.count<<" "<<final.upper<<" "<<final.lower<<" "<<final.children
             <<" "<<final.pairs<<" "<<final.product<<" "<<peak<<"\n";
}
