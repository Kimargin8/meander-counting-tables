"""Identify cells of the extension that also follow from published OEIS tables."""
from pathlib import Path
import json
from seams import ROOT,digest,table


def main():
    root=ROOT/'output/research85/pilot'
    tables=ROOT/'references/oeis/2026-11-15'
    edges=root/'b380369.txt'
    roads=root/'b076876.txt'
    counts=tables/'b005316.txt'
    closed=tables/'b005315.txt'
    full=root/'bridge-rows-22.json'
    ext,parallel,O,M=map(table,(edges,roads,counts,closed))
    rows=json.loads(full.read_bytes())['rows']
    hits={}
    def check(q,s,value,source):
        assert rows[str(q)][s]==value
        if q>40:
            index=1+s+sum((j+1)//2 for j in range(1,q))
            hits[index]=dict(crossings=q,bridge=2*s+1,value=value,formula=source)
    for n in range(21,23):
        for s in (0,n-1):
            check(2*n-1,s,O[2*n-2],'outer positions on odd crossings')
        check(2*n,0,M[n],'closed mass')
        for s in (1,n-1):
            check(2*n,s,O[2*n-2],'bridge 3 or its reflection on even crossings')
    for m in range(1,21):
        q=2*m+1
        value=ext[m*(m+1)//2+1]
        for s in (1,m-1):
            check(q,s,value,'A380369 column 1, reflected on odd crossings')
    for q in range(6,45,2):
        n=q//2
        value=parallel[q-4]+O[q-4]
        for s in (2,n-2):
            check(q,s,value,'Hunter Hogan, A006661 (2026-09-17), and reflection')
    assert len(hits)==16
    result=dict(old_public_A259974_entries=420,extension_entries=86,
         extension_cells_also_obtained_from_listed_identities=len(hits),
         matches=dict(sorted(hits.items())),odd_A380369_orders_checked=20,
         even_A006661_orders_checked=20,
         urls=['https://oeis.org/A380369','https://oeis.org/A076876',
               'https://oeis.org/A006661','https://oeis.org/A005315','https://oeis.org/A005316'],
         sha256={p.relative_to(ROOT).as_posix():digest(p) for p in
                 (edges,roads,counts,closed,full,Path(__file__).resolve())})
    (root/'first-bridge-existing-columns.json').write_text(json.dumps(result,indent=2)+'\n')
    print('16 extension cells recovered from prior exact tables.')


if __name__=='__main__':
    main()
