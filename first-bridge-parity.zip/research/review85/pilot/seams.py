"""Independent exact cut check for usual open meanders and the centroid-root residual."""
from collections import Counter, defaultdict
from functools import cache
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import platform
from time import perf_counter

ROOT = Path(__file__).resolve().parents[3]
ORACLE = ROOT / "research/review79/open-ear-pilot/check.py"
spec = spec_from_file_location("ordinary_open_oracle", ORACLE)
oracle = module_from_spec(spec)
spec.loader.exec_module(oracle)


def outside(bank):
    ends = []
    stop = 0
    while stop < len(bank):
        stop = bank[stop] + 1
        ends.append(stop // 2)
    return ends


def centroid_degree(bank):
    # Each opening adds one edge to the dual tree.
    n = len(bank) // 2
    parent = [-1]
    stack = [0]
    children = [[]]
    for i, j in enumerate(bank):
        if i < j:
            vertex = len(parent)
            parent.append(stack[-1])
            children[stack[-1]].append(vertex)
            children.append([])
            stack.append(vertex)
        else:
            stack.pop()
    size = [1] * len(parent)
    for v in reversed(range(1,len(parent))):
        size[parent[v]] += size[v]
    for v in range(len(parent)):
        t = max([n+1-size[v]]+[size[w] for w in children[v]])
        if 2*t < n+1:
            return t, len(children[v]) + int(v!=0)
    return None


def partial_banks(n):
    stack, word = [], [-1]*(2*n)
    def build(pos):
        if pos == 2*n:
            yield tuple(word), tuple(stack)
            return
        stack.append(pos)
        yield from build(pos+1)
        stack.pop()
        if stack:
            prev = stack.pop()
            word[prev], word[pos] = pos, prev
            yield from build(pos+1)
            word[prev] = word[pos] = -1
            stack.append(prev)
    yield from build(0)


def signature(lower, upper, ports):
    ports_at = {p:i for i,p in enumerate(ports)}
    links = [-1]*len(ports)
    visited = 0
    for i,start in enumerate(ports):
        if links[i] >= 0:
            continue
        v = start
        while True:
            visited += 2
            v = lower[v]
            if upper[v] == -1:
                j = ports_at[v]
                links[i],links[j]=j,i
                break
            v = upper[v]
    if visited == len(lower):
        return tuple(links)
    return None


@cache
def census(n):
    partial = [(p,q) for p,q in partial_banks(n) if q]
    counts = defaultdict(Counter)
    for bank in oracle.matchings(n):
        ends = outside(bank)
        t = max(b-a for a,b in zip([0]+ends, ends))
        for other,ports in partial:
            sig = signature(bank,other,ports)
            if sig is not None:
                counts[t,len(ports)//2][sig] += 1
    return counts


@cache
def side(n,r,cap,primitive=False):
    hist = Counter()
    for (t,j),counts in census(n).items():
        if j==r and t<=cap and (not primitive or t==n):
            hist.update(counts)
    return hist


def reflected(p):
    return tuple(len(p)-1-i for i in reversed(p))


@cache
def kernel(p,q):
    return oracle.connected(p,reflected(q))


@cache
def glue(n,s,cap,left_primitive=False):
    return tuple(sum(a*b for p,a in side(s,r,cap,left_primitive).items()
                     for q,b in side(n-s,r,cap).items() if kernel(p,q))
                 for r in range(1,min(s,n-s)+1))


def by_cap(n,cap):
    f = sum(sum(glue(n,s,cap,True)) for s in range(1,min(cap,n-1)+1))
    d = f + sum(sum(glue(n,s,cap)) for s in range(1,n))
    return f,d


def study(n):
    physical = Counter()
    by_t = defaultdict(Counter)
    numbers = oracle.matchings(n)
    for lower in numbers:
        ends = outside(lower)
        centroid = centroid_degree(lower)
        connected = 0
        for upper in numbers:
            if not oracle.connected(lower,upper):
                continue
            connected += 1
            for s in ends[:-1]:
                defects = sum(x>=2*s for x in upper[:2*s])
                assert defects>=2 and defects%2==0
                physical[s,defects//2] += 1
        if centroid:
            t,k = centroid
            by_t[t]['M'] += connected
            by_t[t]['R0'] += connected*(k-2)*(k-3)
            outer_max = max(b-a for a,b in zip([0]+ends,ends))
            if outer_max==t:
                by_t[t]['F'] += connected
                by_t[t]['D'] += len(ends)*connected
        physical[0,0]+=connected
    nontrivial=0
    for s in range(1,n):
        row=glue(n,s,n)
        for r,value in enumerate(row,1):
            assert physical[s,r]==value
            nontrivial+=1
    for t,row in by_t.items():
        prev=by_cap(n,t-1)
        F,D=(a-b for a,b in zip(by_cap(n,t),prev))
        assert (F,D)==(row['F'],row['D'])
        assert row['R0']==2*n*(D-5*F)+6*row['M']
    return dict(n=n,cells=nontrivial,M=physical[0,0],open=sum(physical.values()),
                channels={str(r):sum(v for (s,j),v in physical.items() if j==r)
                          for r in range(n//2+1)}, families={str(t):dict(v) for t,v in sorted(by_t.items())})


def ideals(bank):
    # Choose an ancestor-closed edge subset of the rooted upper arch tree.
    opening=[i for i,j in enumerate(bank) if i<j]
    index={p:k for k,p in enumerate(opening)}
    parents=[]
    stack=[]
    for p,q in enumerate(bank):
        if p<q:
            parents.append(stack[-1] if stack else -1)
            stack.append(index[p])
        else:
            stack.pop()
    result=Counter()
    for mask in range(1,1<<len(opening)):
        if any(mask>>k&1 and p>=0 and not(mask>>p&1) for k,p in enumerate(parents)):
            continue
        points=sorted(p for k,a in enumerate(opening) if mask>>k&1 for p in (a,bank[a]))
        rank={p:i for i,p in enumerate(points)}
        result[tuple(rank[bank[p]] for p in points)]+=1
    return result


def audit_closed_observables(maximum):
    results=[]
    for m in range(1,maximum+1):
        banks=oracle.matchings(m)
        observables=Counter()
        for top in banks:
            completions=sum(oracle.connected(top,bottom) for bottom in banks)
            row=ideals(top)
            k=len(outside(top))
            assert row[(1,0,3,2)]==k*(k-1)//2
            at,children=0,0
            for end in outside(top):
                right=2*end-1
                children+=len(outside(tuple(x-at-1 for x in top[at+1:right])))
                at=right+1
            assert row[(3,2,1,0)]==children
            for key,v in row.items():
                observables[key]+=v*completions
        forms=0
        for r in range(1,m+1):
            v=side(m,r,m)
            for cap in oracle.matchings(r):
                assert observables[cap]==sum(count for p,count in v.items() if oracle.connected(p,cap))
                forms+=1
        results.append(dict(m=m,checked_cap_shapes=forms,
                            two_separate=observables[(1,0,3,2)],two_nested=observables[(3,2,1,0)]))
    return results


def table(path):
    return dict(tuple(map(int,line.split())) for line in path.read_text().splitlines()
                if line.strip() and not line.lstrip().startswith('#'))


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def main():
    start=perf_counter()
    data=ROOT/'references/oeis/2026-11-15'
    closed,opened=data/'b005315.txt',data/'b005316.txt'
    M,O=table(closed),table(opened)
    recent=[ROOT/'output/research80/open-ear/marked-groups-n31/result.json',ROOT/'output/research83/open62/result.json']
    for j,p in zip((60,62),recent):
        O[j]=int(json.loads(p.read_bytes())['open_count'])
    rows=[study(n) for n in range(2,9)]
    observable=audit_closed_observables(7)
    for row in rows:
        n=row['n']
        assert row['open']==O[2*n] and row['M']==M[n]
        assert row['channels']['1']==sum(O[2*s]*O[2*(n-s)] for s in range(1,n))
        r=n//2
        highest=M[r] if n%2==0 else 2*(2*r+1)*O[2*r]
        assert row['channels'][str(r)]==highest
        if n>=4:
            second=2*sum(observable[s-1]['two_separate']*observable[n-s-1]['two_nested']
                         for s in range(2,n-1))
            assert second==row['channels']['2']
    pairs=0
    for r in range(1,7):
        one_ear=side(r+1,r,r+1)
        for pattern in oracle.matchings(r):
            outside_degree,squares,*_=oracle.root_and_faces(pattern)
            assert one_ear[pattern]==outside_degree+squares
            pairs+=1
    n=32
    exact={"channel0":M[n],"channel1":sum(O[2*s]*O[2*(n-s)] for s in range(1,n)),"channel16":M[16],
           "order33_channel16":66*O[32]}
    exact["known_subtotal_O64"]=sum(exact[k] for k in ('channel0','channel1','channel16'))
    floor=int(json.loads((ROOT/'output/research84/open64/nc-join/forecasts.json').read_bytes())['forecasts'][0]['lower'])
    assert exact["known_subtotal_O64"]<floor
    active=ROOT/'output/research84/open64/midpoint-pilot/small-memory/t13-depth-0.stopped.json'
    g=json.loads(active.read_bytes())
    l=g['linux']
    assert l['status']=='stopped' and l['part']['midpoint']==2 and l['peak_sampled']>l['limits']['ram_cap']
    receipt=dict(rows=rows,closed_observable_checks=observable,
                 closed_pairs_visited=sum(len(oracle.matchings(n))**2 for n in range(2,9)),
                 one_ear_sector_patterns=pairs, physical=exact,
                 pilot=dict(part=l['part'],peak_sampled=l['peak_sampled'],rss_cap=l['limits']['ram_cap'],
                            elapsed_linux=l['elapsed'],elapsed_windows=g['seconds'],
                            min_available=l['min_available'],max_swap_growth=l['max_swap_growth']),
                 python=platform.python_version(),python_seconds=perf_counter()-start,
                 sha256={p.relative_to(ROOT).as_posix():digest(p) for p in
                         [Path(__file__),ORACLE,closed,opened,*recent,active]})
    out=ROOT/'output/research85/pilot/seams.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
    print(exact, len(rows),pairs,round(receipt['python_seconds'],2))


if __name__=='__main__':
    main()
