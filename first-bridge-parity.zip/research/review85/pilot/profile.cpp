// On one representative per bank-swap pair, mark an outer gap on either bank.
// XOR records the complete first-bridge profile over F_2 in small batches.
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include "flat_layer.hpp"

unsigned parity_sum(unsigned a,unsigned b) {return a^b;}

int mate(Word w,int j) {
    const int dir=(w&(Word(1)<<j))?1:-1;
    int balance=0;
    do {
        if(j<0 || j>48) throw std::logic_error("planar pairing escaped");
        balance+=((w>>j)&1)?1:-1;
        if(!balance) return j;
        j+=dir;
    } while(true);
}

template<unsigned Width>
unsigned sweep(int m,int first,int last,int bits,std::size_t& peak) {
    constexpr auto lane=(1U<<Width)-1;
    constexpr auto value_mask=(1U<<(2*Width))-1;
    using Layer=FlatLayer<2*Width,parity_sum>;
    if(last-first+2>int(Width) || 2*m+5+2*Width>=64)
        throw std::logic_error("too many selected cuts for this packing");
    std::size_t limit=std::size_t(1)<<bits;
    Layer current(64,limit);
    current.add(Word(1)<<5,1);
    unsigned result=0;
    for(int i=0;i<2*m;++i) {
        std::size_t cap=64;
        while(cap<limit && cap<current.size()) cap*=2;
        Layer next(cap,limit);
        int left=2*m-i-1;
        for(Word cell:current) {
            unsigned x=cell&value_mask;
            if(!x) continue;
            Word key=cell>>(2*Width),w=key>>5;
            int len=63-__builtin_clzll(w),l=2*int(key&31)+(i&1),u=len-l;
            w^=Word(1)<<len;
            bool tied=len==2*i;
            auto write=[&](Word v,int lower,int upper,bool close_top,bool close_bottom) {
                if(lower>left || upper>left) return;
                unsigned y=x;
                const bool toggle=(close_top && u==1)!=(close_bottom && l==1);
                if(toggle) y=((y&lane)<<Width)|(y>>Width);
                int step=i+1,k=step/2;
                if(step%2==0 && first<=k && k<=last && ((lower==0)!=(upper==0)))
                    y^=(y&(1U|(1U<<Width)))<<(k-first+1);
                next.add(((v|(Word(1)<<(lower+upper)))<<5)|(lower>>1),y);
            };
            if(l<left && u<left) {
                Word low=(Word(1)<<l)-1;
                write((w&low)|(Word(1)<<l)|((w&~low)<<2),l+1,u+1,false,false);
            }
            if(u && l<left) write(w,l+1,u-1,true,false);
            // Prior to the first disagreement both shores opened at every site.
            // Choose the upper closure at the first disagreement once and for all.
            if(!tied && l && u<left) write(w,l-1,u+1,false,true);
            if(!l || !u) continue;
            int a=l-1,signs=(w>>a)&3;
            if(signs==1) {
                if(!left && len==2) result^=x;
            } else {
                Word v=w;
                if(signs==3) v^=Word(1)<<mate(w,l);
                if(signs==0) v^=Word(1)<<mate(w,a);
                write((v&((Word(1)<<a)-1))|((v>>(a+2))<<a),l-1,u-1,true,true);
            }
        }
        peak=std::max(peak,next.size());
        current=std::move(next);
    }
    return (result>>Width)>>1;
}

int main(int argc,char** argv) {
    if(argc!=5) return 2;
    int m=std::atoi(argv[1]),lo=std::atoi(argv[2]),hi=std::atoi(argv[3]),bits=std::atoi(argv[4]);
    if(m<2 || m>23 || lo<1 || hi<lo || hi>m/2 || bits<10 || bits>28) return 2;
    std::size_t peak=0;
    unsigned v;
    if(hi-lo+2<=6) v=sweep<6>(m,lo,hi,bits,peak);
    else if(hi-lo+2<=8) v=sweep<8>(m,lo,hi,bits,peak);
    else if(hi-lo+2<=10) v=sweep<10>(m,lo,hi,bits,peak);
    else return 2;
    std::cout<<v<<" "<<peak<<"\n";
}
