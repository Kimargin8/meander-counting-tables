"""Three exact descriptions of O_(2n), with a direct open-path oracle."""
from functools import cache
from hashlib import sha256
from pathlib import Path
from time import perf_counter
import argparse
import json
import platform


@cache
def matchings(n):
    if n == 0:
        return ((),)
    return tuple(
        (2 * k + 1,) + tuple(i + 1 for i in inner) + (0,)
        + tuple(i + 2 * k + 2 for i in outer)
        for k in range(n)
        for inner in matchings(k)
        for outer in matchings(n - 1 - k)
    )


def connected(upper, lower):
    i, visited = 0, 0
    while True:
        i = lower[upper[i]]
        visited += 2
        if i == 0:
            return visited == len(upper)


def root_and_faces(bank):
    # Node 0 is the exterior. Each opened chord introduces its child face.
    degree = [0]
    parent = [-1]
    stack = [0]
    for i, j in enumerate(bank):
        if i < j:
            degree[stack[-1]] += 1
            parent.append(stack[-1])
            stack.append(len(degree))
            degree.append(1)
        else:
            stack.pop()
    subtree = [1]*len(degree)
    largest_child = [0]*len(degree)
    for node in range(len(degree)-1, 0, -1):
        p = parent[node]
        subtree[p] += subtree[node]
        largest_child[p] = max(largest_child[p], subtree[node])
    largest_branch = [max(x, len(degree)-s) for x,s in zip(largest_child, subtree)]
    family = min(largest_branch)
    return degree[0], sum(d*d for d in degree), degree, family, largest_branch[0] == family


def closed(n):
    m = 2 * n
    totals = dict(connected=0, exterior=0, squared_degrees=0,
                  cyclic_adjacent_arcs=0, fixed_terminal_ear=0)
    families = {}
    for lower in matchings(n):
        upper_count = sum(connected(upper, lower) for upper in matchings(n))
        root_degree, squared, degree, family, centered = root_and_faces(lower)
        # A cyclic starting corner, rather than an unoriented edge, is marked.
        # At n = 1 both starting corners see the unique arc.
        adjacent = sum(lower[i] == (i + 1) % m for i in range(m))
        assert adjacent == degree.count(1)
        if n >= 2 and centered:
            assert root_degree >= 2 and lower[-1] != 0
            assert sum(lower[i] == i+1 for i in range(m-1)) == adjacent
        counts = families.setdefault(family, dict(connected=0, cyclic_ears=0, fixed_terminal_ear=0))
        counts['connected'] += upper_count
        counts['cyclic_ears'] += upper_count*adjacent
        counts['fixed_terminal_ear'] += upper_count*(lower[-1]==m-2)
        totals['connected'] += upper_count
        totals['exterior'] += upper_count * root_degree
        totals['squared_degrees'] += upper_count * squared
        totals['cyclic_adjacent_arcs'] += upper_count * adjacent
        totals['fixed_terminal_ear'] += upper_count * (lower[-1] == m - 2)
    for counts in families.values():
        assert counts['cyclic_ears'] == m*counts['fixed_terminal_ear']
    totals['by_centroid_family'] = families
    return totals


def open_direct(n):
    # The two upward rays split the finite upper matching into three independent intervals.
    m, count = 2 * n, 0
    for left in range(n):
        for middle in range(n - left):
            right = n - 1 - left - middle
            a, b = 2 * left, 2 * (left + middle) + 1
            for p in matchings(left):
                for q in matchings(middle):
                    for r in matchings(right):
                        upper = (p + (-1,) + tuple(a + 1 + i for i in q)
                                 + (-1,) + tuple(b + 1 + i for i in r))
                        for lower in matchings(n):
                            i, vertices = a, 1
                            while True:
                                i = lower[i]
                                vertices += 1
                                if upper[i] == -1:
                                    assert i == b
                                    break
                                i = upper[i]
                                vertices += 1
                            count += vertices == m
    return count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--through', type=int, default=6, choices=range(1,8))
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    ref = Path(__file__).resolve().parents[3] / 'references/oeis/2026-11-15/b005316.txt'
    values = dict(tuple(map(int, line.split())) for line in ref.read_text().splitlines()
                  if line.strip() and not line.startswith('#'))
    start = perf_counter()
    c = {n: closed(n) for n in range(1,args.through+2)}
    rows = []
    for n in range(1,args.through+1):
        fun = open_direct(n)
        assert fun == values[2*n] == c[n]['exterior'] == c[n+1]['fixed_terminal_ear']
        assert c[n]['squared_degrees'] == 2*n*fun
        assert c[n+1]['cyclic_adjacent_arcs'] == 2*(n+1)*fun
        rows.append(dict(n=n, open_crossings=2*n, open_direct=fun, known=values[2*n],
                         lower_exterior_weight=c[n]['exterior'], lower_degree_squares=c[n]['squared_degrees'],
                         higher_one_fixed_ear=c[n+1]['fixed_terminal_ear'],
                         higher_all_ear_positions=c[n+1]['cyclic_adjacent_arcs'],
                         higher_by_centroid_family=c[n+1]['by_centroid_family']))
    result = dict(rows=rows, closed_pairs_tested=sum(len(matchings(n))**2 for n in c), through=args.through,
                  reference='https://oeis.org/A005316/b005316.txt',
                  input_sha256=sha256(ref.read_bytes()).hexdigest(),
                  source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
                  python=platform.python_version(), wall_seconds=round(perf_counter()-start,4))
    text=json.dumps(result,indent=2)+'\n'
    if args.out: args.out.write_text(text,encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()

