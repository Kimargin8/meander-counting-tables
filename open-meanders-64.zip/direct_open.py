"""A small exact reference implementation of the physical frontier sweep.

The order is the number of arcs in one bank. Each active path connects two
points on the cut. Read the cut from the bottom bank to the top bank.
"""
import argparse
from pathlib import Path


def partner(word, at):
    forward = word[at] == "("
    depth = 0
    for i in (range(at, len(word)) if forward else range(at, -1, -1)):
        depth += 1 if word[i] == word[at] else -1
        if depth == 0:
            return i
    raise ValueError("unmatched endpoint")


def join(word, left):
    # The two central endpoints disappear. Their partners become a new pair.
    a, b = left - 1, left
    signs = word[a:b + 1]
    if signs == "()":
        return None  # The path already joined these endpoints, forming a cycle.
    if signs == "((":
        j = partner(word, b)
        word = word[:j] + "(" + word[j + 1:]
    elif signs == "))":
        j = partner(word, a)
        word = word[:j] + ")" + word[j + 1:]
    return word[:a] + word[b + 1:]


def count(n):
    # Each stored pair is (ways, total number of completed exterior lower arcs).
    layer = {("", 0): (1, 0)}
    total_closed = total_open = 0
    for step in range(2 * n):
        left = 2 * n - step - 1
        following = {}
        for (word, lower), (ways, outer) in layer.items():
            upper = len(word) - lower
            def record(new_word, new_lower, closed_lower):
                key = new_word, new_lower
                old_ways, old_outer = following.get(key, (0, 0))
                following[key] = (old_ways + ways, old_outer + outer + (ways if closed_lower and lower == 1 else 0))
            # Open both arcs, transpose the split in either direction, or close both.
            if lower < left and upper < left:
                record(word[:lower] + "()" + word[lower:], lower + 1, False)
            if upper and lower < left:
                record(word, lower + 1, False)
            if lower and upper < left:
                record(word, lower - 1, True)
            if lower and upper:
                updated = join(word, lower)
                if updated is not None:
                    record(updated, lower - 1, True)
                elif left == 0 and len(word) == 2:
                    total_closed += ways
                    total_open += outer + ways
        layer = following
    return total_closed, total_open


def load_table(path):
    lines = path.read_text().splitlines()
    return dict(tuple(map(int, line.split())) for line in lines if line.strip() and not line.lstrip().startswith("#"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--order", type=int)
    group.add_argument("--check-through", type=int)
    args = parser.parse_args()
    if args.order is not None:
        if args.order < 1:
            parser.error("the order must be positive")
        closed, ordinary = count(args.order)
        print(f"M({args.order}) = {closed}; O({2 * args.order}) = {ordinary}")
    else:
        inputs = Path(__file__).resolve().parent / "references/oeis/2026-11-15"
        closed = load_table(inputs / "b005315.txt")
        ordinary = load_table(inputs / "b005316.txt")
        if not (1 <= args.check_through <= min(max(closed), max(ordinary) // 2)):
            parser.error("the requested check exceeds the bundled comparison tables")
        for i in range(1, args.check_through + 1):
            if count(i) != (closed[i], ordinary[2 * i]):
                raise ValueError(f"table disagreement at order {i}")
        print(f"Recounted closed and even open meanders through {2 * args.check_through} crossings.")
