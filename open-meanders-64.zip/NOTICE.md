# Sources and licenses

Copyright © 2026 Iaroslav Argunov for the original contributions.

The original verification programs are released under the [MIT License](licenses/MIT.txt). The original manuscript, explanatory text and original verification records are released under [CC BY 4.0](licenses/CC-BY-4.0.txt).

Reproduced OEIS inputs, their transformations, combined tables and the original contributions to those adaptations are distributed under [CC BY-SA 4.0](licenses/CC-BY-SA-4.0.txt). Credit The On-Line Encyclopedia of Integer Sequences, OEIS Foundation Inc. and the credited contributors. Retain attribution and identify changes when redistributing an adaptation. [OEIS terms](https://oeis.org/wiki/The_OEIS_End-User_License_Agreement)

- [A005315](https://oeis.org/A005315) — closed meanders; E. Alepis, I. Jensen, A. Howroyd and V. Osipov. [Source table](https://oeis.org/A005315/b005315.txt)
- [A005316](https://oeis.org/A005316) — open meanders; A. Khrabrov, I. Jensen, A. Howroyd and contributors. [Source table](https://oeis.org/A005316/b005316.txt)

The original 62- and 64-crossing values, their weighted contributions, and their numerical extracts are released under CC BY 4.0. The consistency checks compare counts against the credited OEIS inputs. Vladimir Osipov published O60 in [September 2026](https://doi.org/10.5281/zenodo.22773575).
