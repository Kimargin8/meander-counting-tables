"""Physical multiplicities of a midpoint-height / marked-depth rectangle.

A pointed cyclic forest starts with a largest branch. Its weight is twice
the distance to the next largest branch in vertices, taking one full turn
if the maximum is unique. The factor is one for a bicentral tree. Local
marks contribute (degree-2)(degree-3) at vertices of degree at least four.
This uses decomposition into ordered trees, without a bitmap or word parser.
"""
from functools import cache


def tail(k):
    return (k-2)*(k-3) if k>=4 else 0


def add(dst,h,values,f=1):
    row=dst.setdefault(h,[0]*len(values))
    if len(row)<len(values):
        row.extend([0]*(len(values)-len(row)))
    for i,v in enumerate(values):
        row[i]+=f*v


def mult(left,right):
    # Multiplication of the unmarked count and one marked position.
    x,y=left[0],right[0]
    arr=[0]*max(len(left),len(right))
    arr[0]=x*y
    for j in range(1,len(left)):
        arr[j]+=y*left[j]
    for j in range(1,len(right)):
        arr[j]+=x*right[j]
    return arr


@cache
def tree(s,cut,kind):
    # A primitive contour has two exterior steps around its children.
    inside=0<cut<2*s
    found={}
    for k in range(s):
        value=int(k==0) if kind=='ear' else tail(k+1)
        for h,row in forest(s-1,k,cut-1 if inside else -1,kind).items():
            add(found,h+1 if inside else 0,[row[0],row[0]*value,*row[1:]])
    return found


@cache
def forest(total,k,cut,kind):
    if k==0:
        return {0:[1]} if total==0 else {}
    found={}
    for s in range(1,total-k+2):
        a=cut if 0<=cut<=2*s else -1
        b=cut-2*s if cut>2*s else -1
        for g,left in tree(s,a,kind).items():
            for h,right in forest(total-s,k-1,b,kind).items():
                add(found,g+h,mult(left,right))
    return found


@cache
def profile(n,t,cut,kind='tail'):
    assert kind in ('tail','ear')
    @cache
    def top(used,k,awaiting):
        if used==n:
            factor=n if awaiting else 1
            mark=int(k==1) if kind=='ear' else tail(k)
            return {0:[factor,mark*factor]}
        found={}
        for s in ([t] if not used else range(1,min(n-used,t)+1)):
            local=cut-2*used
            marks=tree(s,local if 0<=local<=2*s else -1,kind)
            next_max=bool(used and s==t and awaiting)
            factor=used if next_max else 1
            right=top(used+s,k+1,awaiting and not next_max)
            for g,L in marks.items():
                for h,R in right.items():
                    # In the forest around the centroid the branch root is at
                    # depth one. Its local marks shift by one depth.
                    add(found,h+g,mult([L[0],0,*L[1:]],R),factor)
        return found
    corners=1 if 2*t==n+1 else 2
    return {h:[corners*x for x in v] for h,v in top(0,0,True).items()}


if __name__=='__main__':
    import json
    from pathlib import Path
    root=Path(__file__).resolve().parents[3]
    old=root/'output/research84/open64/tail-cut/n7/t04-mod-1/plan.json'
    p=profile(7,4,5)
    for piece in json.loads(old.read_bytes())['parts']:
        row=p[piece['midpoint']]
        assert int(piece['lower'])==row[0] and int(piece['weight'])==sum(row[1:])
    print('Order 7: exact unmarked and marked masses at both midpoint heights.')
