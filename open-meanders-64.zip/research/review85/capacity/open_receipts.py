"""Rebuild O64 from the original weighted family outputs and depth receipts.

Independent of the pilot aggregation. The lower-bank witness is the rooted
plane-tree census by number of children, subtree size and marked depth.
Run with --write to save coverage, or --verify to check a completed snapshot.
"""
import argparse
import hashlib
import json
from fractions import Fraction
from functools import cache
from math import comb
from pathlib import Path
from midpoint_mass import profile
from double_mass import joint

ROOT = Path(__file__).resolve().parents[3]
OLD = ROOT / 'output/research84/open64'
OUT = ROOT / 'output/research85/capacity/open-receipts.json'
N = 32
C = comb(2*N, N)//(N+1)


def tail(degree):
    return (degree-2)*(degree-3) if degree >= 4 else 0


@cache
def forest(total, k, bound):
    """Number of ordinary lists of k planted trees, at most bound vertices each."""
    if k == 0:
        return int(total == 0)
    if total < k or total > k*bound:
        return 0
    return sum(branch(s)*forest(total-s,k-1,bound)
               for s in range(1,min(bound,total-k+1)+1))


@cache
def branch(s):
    return sum(forest(s-1,k,s-1) for k in range(s))


@cache
def marks(s, h, kind):
    """Total local weight of a vertex at depth h inside a planted tree."""
    if h >= s:
        return 0
    if h == 0:
        def value(k):
            if kind == 'ear':
                return int(k == 0)
            if kind == 'siblings':
                return k*(k-1)
            return tail(k+1)
        return sum(value(k)*forest(s-1,k,s-1) for k in range(s))
    return sum(k*marks(j,h-1,kind)*forest(s-1-j,k-1,s-1)
               for k in range(1,s) for j in range(1,s-k+1))


@cache
def census(t):
    pieces = dict(lower=0,base=0,ear=0)
    for k in range(1,N+1):
        # Unroot the distinguished centroid corner, root a physical boundary
        # corner, then difference the cumulative largest-branch restrictions.
        rot = Fraction(2*N,k)
        def ways(bound):
            return forest(N,k,bound)
        qty=rot*(ways(t)-ways(t-1))
        for name,weight in [('lower',1),('base',4*N-2*k),('ear',int(k==1)),
                            (('tail',0),tail(k)),(('siblings',0),k*(k-1))]:
            pieces[name]=pieces.get(name,0)+qty*weight
        for s in range(1,t+1):
            oth=forest(N-s,k-1,t)-(forest(N-s,k-1,t-1) if s<t else 0)
            if not oth:
                continue
            for h in range(s):
                for kind in ('siblings','ear','tail'):
                    key='ear' if kind=='ear' else (kind,h+1)
                    pieces[key]=pieces.get(key,0)+2*N*marks(s,h,kind)*oth
    assert all(a>=0 and int(a)==a for a in pieces.values())
    return {k:int(v) for k,v in pieces.items()}


class Inputs:
    def __init__(self):
        self.files={}

    def sha(self,path):
        key=path.relative_to(ROOT).as_posix()
        if key not in self.files:
            self.files[key]=hashlib.sha256(path.read_bytes()).hexdigest()
        return self.files[key]

    def read(self,path):
        self.sha(path)
        return json.loads(path.read_bytes())

    def inputs(self,stamps):
        for name,digest in stamps.items():
            assert self.sha(ROOT/name)==digest,name

    def row(self,path):
        cert=self.read(path)
        out=path.with_name(path.name.replace('.receipt.json','.json'))
        assert self.sha(out)==cert['output_sha256'] and cert['exit']==0
        z=self.read(out)
        assert z['part']==cert['part']
        self.inputs(cert['sources'])
        return self.value(z)

    def value(self,z):
        p=z['part']
        assert p['order']==N and z['actual_weight']==p['weight'] and z['actual_lower']==p['lower']
        assert 0 <= int(z['value']) <= C*int(p['weight'])
        assert int(z['global_bound'])==4*N*N*C*C<(1<<128)
        return p,int(z['value'])


def direct_areas(io):
    out={}
    for t in [*range(1,11),15,16]:
        ref=census(t)
        weight=ref['base']+sum(ref.get(('siblings',h),0) for h in range(N))
        if t in (10,15):
            folder=OLD/'parts'/'n32'/f't{t:02d}'
            keys={(0,0):ref['base']}
            for j in range(4):
                v=sum(ref.get(('siblings',h),0) for h in range(j,N,4))
                if v: keys[4,j]=v
            total=0
            for path in sorted(folder.glob('*.receipt.json')):
                p,v=io.row(path)
                key=(p['classes'],p['residue'])
                assert p['family']==t and int(p['lower'])==ref['lower']
                assert p['kind']==('siblings' if key[0] else 'base')
                assert int(p['weight'])==keys.pop(key)
                total+=v
            assert not keys
        else:
            p,total=io.row(OLD/'n32'/f't{t:02d}-whole.receipt.json')
            assert (p['family'],int(p['lower']),int(p['weight']))==(t,ref['lower'],weight)
        assert total%(2*N)==0
        out[t]=total
    return out


def known_closed(io):
    folder=ROOT/'output/research61/threshold/paired32'
    design=io.read(folder/'audit.json')['records']['B']['groups']
    closed={}
    for i,entry in enumerate(design):
        f=folder/'B'/f'g{i}'/'RESULT.json'
        assert io.sha(f)==entry['sha256']
        row=io.read(f)
        keys=tuple(entry['sizes'])
        assert row['status']=='PASS' and row['n']==N
        assert sum(census(t)['lower'] for t in keys)==entry['factor']*int(row['weighted_lower_coverage'])
        closed[keys]=entry['factor']*int(row['Mn'])
    assert sorted(t for ts in closed for t in ts)==list(range(1,17))
    source=ROOT/'references/oeis/2026-11-15/b005315.txt'
    io.sha(source)
    terms=dict(tuple(map(int,s.split())) for s in source.read_text().splitlines() if s.strip() and not s.startswith('#'))
    assert sum(closed.values())==terms[N]
    p,v=io.row(OLD/'tail/n32/t14-plain.receipt.json')
    assert p['mode']=='plain' and p['family']==14 and int(p['weight'])==census(14)['lower']
    return {(11,12):closed[11,12],(13,):closed[13,],(14,):v}


def ear_values(io):
    folder=ROOT/'output/research83/open62'
    ref=io.read(folder/'result.json')
    exact={}
    for t in range(1,17):
        source=folder/f't{t:02d}.json'
        assert io.sha(source)==ref['worker_files_sha256'][source.name]
        z=io.read(source)
        assert (z['order'],z['family'],z['mode'])==(N,t,'marked')
        assert census(t)['ear']==int(z['marked_lower_coverage']) and census(t)['lower']==int(z['lower_coverage'])
        exact[t]=int(z['value'])
    assert sum(exact.values())==64*int(ref['open_count'])
    return exact


class Rectangles:
    """Recover unmeasured unions with exact linear combinations of rectangles."""
    def __init__(self,keys):
        self.keys=sorted(keys)
        self.pivots={}
        self.measurements={}

    def reduce(self,cells,amount):
        vec=[Fraction(int(k in cells)) for k in self.keys]+[Fraction(amount)]
        for pivot,row in sorted(self.pivots.items()):
            coeff=vec[pivot]
            if coeff:
                vec=[a-coeff*b for a,b in zip(vec,row)]
        return vec

    def add(self,cells,value):
        key=frozenset(cells)
        assert self.measurements.setdefault(key,value)==value
        row=self.reduce(cells,value)
        pivot=next((i for i,x in enumerate(row[:-1]) if x),None)
        if pivot is None:
            assert row[-1]==0,'incompatible overlapping exact receipts'
        else:
            scale=row[pivot]
            self.pivots[pivot]=[x/scale for x in row]

    def infer(self,cells):
        row=self.reduce(cells,0)
        if any(row[:-1]):
            return None
        value=-row[-1]
        assert value>=0 and value.denominator==1
        return int(value)


def residual(io,t):
    ref=census(t)
    expected={h:ref.get(('tail',h),0) for h in range(t)}
    expected={h:w for h,w in expected.items() if w}
    byheight=profile(N,t,N)
    assert sum(row[0] for row in byheight.values())==ref['lower']
    for h in range(N):
        assert sum(row[h+1] for row in byheight.values() if h+1<len(row))==expected.get(h,0)
    cutdir=OLD/'tail-cut/n32'
    for plan in sorted(cutdir.glob(f't{t:02d}-mod-*/plan.json')):
        m=int(plan.parent.name.rsplit('-',1)[1])
        keys={(mid,r):(row[0],sum(row[r+1::m])) for mid,row in byheight.items()
              for r in range(m) if sum(row[r+1::m])}
        for p in io.read(plan)['parts']:
            assert (p['order'],p['family'],p['cut_step'],p['modulus'])==(N,t,N,m)
            assert keys.pop((p['midpoint'],p['residue']))==(int(p['lower']),int(p['weight']))
        assert not keys
    subsets={}

    def accept(p,v):
        assert p['family']==t and int(p['lower'])==ref['lower']
        m,r=p['modulus'],p['residue']
        S=frozenset(h for h in expected if h%m==r)
        assert S and sum(expected[h] for h in S)==int(p['weight'])
        assert subsets.setdefault(S,v)==v
    for f in sorted((OLD/'tail-depth/n32').glob(f't{t:02d}-mod-*/*.receipt.json')):
        accept(*io.row(f))
    for f in sorted((OLD/'small-memory').glob(f't{t:02d}-depth-*.json')):
        if f.name.endswith('.stopped.json'):
            continue
        z=io.read(f)
        assert z['host_status']==z['linux']['status']=='ok'
        io.inputs(z['sources'])
        assert z['linux']['part']==z['linux']['row']['part']
        accept(*io.value(z['linux']['row']))
    by_mid={}
    other_cuts=[]
    for f in sorted(cutdir.glob(f't{t:02d}-mod-*/*.receipt.json')):
        p,v=io.row(f)
        h,mid,m=p['residue'],p['midpoint'],p['modulus']
        assert p['family']==t and p['cut_step']==N and 0<=h<m<=N and 0<=mid<=N and mid%2==0
        assert int(p['weight'])==sum(byheight[mid][h+1::m]) and int(p['lower'])==byheight[mid][0]
        if m!=N:
            other_cuts.append((mid,m,h,v))
            continue
        parts=by_mid.setdefault(h,{})
        assert mid not in parts
        parts[mid]=int(p['weight']),v
    for h,parts in by_mid.items():
        w=sum(a for a,b in parts.values())
        assert w<=expected[h]
        if w==expected[h]:
            v=sum(b for a,b in parts.values())
            assert subsets.setdefault(frozenset([h]),v)==v
    two_paths=sorted((ROOT/'output/research85/pilot/mask2/n32').glob(f't{t:02d}-cut-*-mask-*/*.receipt.json'))
    two_rows=[io.row(path) for path in two_paths]
    if two_rows:
        cuts={p['second_cut'] for p,v in two_rows}
        assert len(cuts)==1,'Use a common second cut for each family'
        detail=joint(N,t,(N,cuts.pop()))
        granular={(H,h,H2):w for (H,H2),row in detail.items() for h,w in enumerate(row[1:]) if w}
    else:
        granular={(H,h):w for H,row in byheight.items() for h,w in enumerate(row[1:]) if w}
    rectangles=Rectangles(granular)
    cells=set(rectangles.keys)
    for S,val in subsets.items():
        rectangles.add({k for k in cells if k[1] in S},val)
    for depth,parts in by_mid.items():
        for H,(weight,val) in parts.items():
            rectangles.add({k for k in cells if k[0]==H and k[1]==depth},val)
    for H,m,r,val in other_cuts:
        rectangles.add({k for k in cells if k[0]==H and k[1]%m==r},val)
    mask_receipts=sorted((ROOT/'output/research85/pilot/mask/n32').glob(f't{t:02d}-mask-*/*.receipt.json'))
    for f in mask_receipts:
        p,val=io.row(f)
        mid,mask=p['midpoint'],p['depth_mask']
        assert p['family']==t and p['cut_step']==N and int(p['lower'])==byheight[mid][0]
        rect={k for k in cells if k[0]==mid and (mask>>k[1])&1}
        assert rect and sum(granular[k] for k in rect)==int(p['weight'])
        rectangles.add(rect,val)
    for p,val in two_rows:
        H,H2,mask=p['midpoint'],p['second_height'],p['depth_mask']
        assert p['family']==t and p['cut_step']==N and int(p['lower'])==detail[H,H2][0]
        rect={k for k in cells if k[0]==H and k[2]==H2 and mask>>k[1]&1}
        assert rect and sum(granular[k] for k in rect)==int(p['weight'])
        rectangles.add(rect,val)
    known_depths=[]
    for h in expected:
        inferred=rectangles.infer({k for k in cells if k[1]==h})
        if inferred is not None:
            known_depths.append(h)
            assert subsets.setdefault(frozenset([h]),inferred)==inferred
    # If alternate encodings are fully available, their composition must agree.
    for S,v in subsets.items():
        if all(frozenset([h]) in subsets for h in S):
            assert v==sum(subsets[frozenset([h])] for h in S)
    # All currently used moduli form a divisibility chain: keep maximal
    # certified classes. Incorrect overlapping non-nested receipts are fatal.
    maximal=[s for s in subsets if not any(s<t0 for t0 in subsets)]
    covered=set()
    for S in maximal:
        assert covered.isdisjoint(S)
        covered.update(S)
    whole=rectangles.infer(cells)
    accounted={k for k in cells if k[1] in covered}
    if whole is not None:
        value=whole
        covered=set(expected)
        accounted=cells
    else:
        value=sum(subsets[s] for s in maximal)
        # Newly counted midpoint rectangles can contribute before that depth
        # is complete across all the other midpoints.
        for rect,measured in sorted(rectangles.measurements.items(),key=lambda kv:-kv[1]):
            if rect.isdisjoint(accounted):
                accounted.update(rect)
                value+=measured
        # Full-depth priority can mask a much larger partially overlapping
        # height slice. Also try starting with the largest raw amounts.
        other=set()
        total=0
        for rect,measured in sorted(rectangles.measurements.items(),key=lambda kv:-kv[1]):
            rest=rect-other
            if not rest:continue
            gain=measured if rest==rect else rectangles.infer(rest)
            if gain is not None:
                total+=gain
                other.update(rest)
        if total>value:
            value,accounted=total,other
    return dict(lower_bank_mass=sum(expected.values()),covered_depths=sorted(covered),
                missing_depths=sorted(expected.keys()-covered),value=str(value),
                internally_determined_depths=known_depths,rectangle_rank=len(rectangles.pivots),
                rectangle_cells=len(cells),covered_cells=len(accounted))


def main():
    if not __debug__:
        raise RuntimeError('Assertions are required')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify',action='store_true')
    parser.add_argument('--write',action='store_true')
    option=parser.parse_args()
    io=Inputs()
    io.sha(Path(__file__).resolve())
    io.sha(Path(__file__).with_name('midpoint_mass.py').resolve())
    io.sha(Path(__file__).with_name('double_mass.py').resolve())
    previous=io.read(ROOT/'output/research83/open62-split/n32-single/plan.json')
    ears_by_height=profile(N,13,N,'ear')
    assert {p['cuts'][0][1] for p in previous['parts']}==set(ears_by_height)
    for p in previous['parts']:
        assert p['family']==13 and p['order']==N and len(p['cuts'])==1 and p['cuts'][0][0]==N
        old=ears_by_height[p['cuts'][0][1]]
        assert int(p['lower'])==old[0] and int(p['marked'])==sum(old[1:])
    assert sum(census(t)['lower'] for t in range(1,17))==C
    S=direct_areas(io)
    closed=known_closed(io)
    m=sum(closed.values())
    E=ear_values(io)
    families={str(t):residual(io,t) for t in range(11,15)}
    subgroup_sums={}
    for group,connected in closed.items():
        if any(families[str(t)]['missing_depths'] for t in group):
            continue
        moment=(4*N-6)*connected+sum(2*E[t]+int(families[str(t)]['value']) for t in group)
        # Each rotation orbit contributes sum(degree^2)/(2N) to the
        # exterior-degree statistic, counting with stabilizer multiplicity.
        quotient,remainder=divmod(moment,2*N)
        assert remainder==0
        subgroup_sums[','.join(map(str,group))]=str(quotient)
    base=sum(S.values())+(4*N-6)*m+2*sum(E[t] for t in range(11,15))
    partial=base+sum(int(q['value']) for q in families.values())
    check=next(z for z in io.read(ROOT/'output/research85/paths/filtered.json')['forecasts'] if z['crossings']==64)
    congr=next(z for z in io.read(ROOT/'output/research85/pilot/mod4-19.json')['rows'] if z['crossings']==64)
    half_order=congr['m']
    norm=(half_order+1)*congr['M_half']
    assert norm%2==0 and norm//2==congr['equal_halves']
    mod4=(congr['M_full']+norm//2+congr['C']+congr['A']+2*congr['B']-congr['E_half'])%4
    assert mod4==congr['residue']
    # Freeze the endpoints and the independent symmetry prediction while the
    # direct computation still has whole unresolved families.
    assert (check['lower'],check['upper'],mod4)==(411154648288804845393389922374,
                                                  411170598697626385256220114785,3)
    complete=not any(x['missing_depths'] for x in families.values())
    lo,hi=check['lower'],check['upper']
    assert ((partial+63)//64)<=hi
    final=None
    if complete:
        final,r=divmod(partial,64)
        assert not r and lo<=final<=hi and final%4==mod4
        assert len(subgroup_sums)==len(closed)
        assert final==sum(v//64 for v in S.values())+sum(int(v) for v in subgroup_sums.values())
    record=dict(order=N,crossings=64,complete=complete,open_count=str(final) if complete else None,
        raw_square_by_family={str(t):str(v) for t,v in S.items()},
        ears_by_family={str(t):str(v) for t,v in E.items()},closed_mass_11_14=str(m),
        baseline=str(base),depth_receipts=families,complete_group_open_values=subgroup_sums,
        available_numerator=str(partial),
        prediction=[str(lo),str(hi)],independent_mod4=mod4,sources=io.files)
    if option.write:
        tmp=OUT.with_suffix('.new')
        tmp.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
        tmp.replace(OUT)
    if option.verify:
        assert json.loads(OUT.read_bytes())==record
    print('Base:',base,'missing:',{t:f['missing_depths'] for t,f in families.items()},'O64:',final)


if __name__=='__main__':
    main()
