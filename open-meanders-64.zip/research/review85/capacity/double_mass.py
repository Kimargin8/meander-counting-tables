"""Ordered-tree census of a marked-depth mask at two prescribed cuts."""
from functools import cache
from midpoint_mass import add,mult,profile,tail


def merge(left,right):
    return tuple(a+b for a,b in zip(left,right))


@cache
def tree(s,cuts,kind):
    inside=tuple(0<j<2*s for j in cuts)
    children=tuple(j-1 if b else -1 for j,b in zip(cuts,inside))
    result={}
    for k in range(s):
        local=int(k==0) if kind=='ear' else tail(k+1)
        for key,row in forest(s-1,k,children,kind).items():
            H=tuple(h+1 if b else 0 for h,b in zip(key,inside))
            add(result,H,[row[0],row[0]*local,*row[1:]])
    return result


@cache
def forest(s,k,cuts,kind):
    if k==0:
        return {(0,)*len(cuts):[1]} if s==0 else {}
    result={}
    for size in range(1,s-k+2):
        a=tuple(j if 0<=j<=2*size else -1 for j in cuts)
        b=tuple(j-2*size if j>2*size else -1 for j in cuts)
        for g,left in tree(size,a,kind).items():
            for h,right in forest(s-size,k-1,b,kind).items():
                add(result,merge(g,h),mult(left,right))
    return result


@cache
def joint(n,t,cuts,kind='tail'):
    assert kind in ('ear','tail') and len(cuts)==2 and 0<cuts[0]<cuts[1]<2*n
    @cache
    def from_gap(used,k,waiting):
        if used==n:
            w=n if waiting else 1
            mark=int(k==1) if kind=='ear' else tail(k)
            return {(0,0):[w,w*mark]}
        result={}
        for s in ([t] if not used else range(1,min(t,n-used)+1)):
            inner=tuple(j-2*used if 2*used<=j<=2*(used+s) else -1 for j in cuts)
            repeat=bool(used and waiting and s==t)
            rest=from_gap(used+s,k+1,waiting and not repeat)
            for g,left in tree(s,inner,kind).items():
                for h,right in rest.items():
                    add(result,merge(g,h),mult([left[0],0,*left[1:]],right),used if repeat else 1)
        return result
    factor=1 if 2*t==n+1 else 2
    result={H:[factor*v for v in row] for H,row in from_gap(0,0,True).items()}
    for axis,cut in enumerate(cuts):
        summed={}
        for H,row in result.items():
            add(summed,H[axis],row)
        assert summed==profile(n,t,cut,kind)
    return result


if __name__=='__main__':
    import json
    from pathlib import Path
    root=Path(__file__).resolve().parents[3]
    ref=root/'output/research83/open62-split/n32-double/plan.json'
    past=json.loads(ref.read_bytes())['parts']
    rows=joint(32,13,(32,36),'ear')
    assert {tuple(g[1] for g in z['cuts']) for z in past}==set(rows)
    for z in past:
        H=tuple(g[1] for g in z['cuts'])
        assert [z['lower'],z['marked']]==list(map(str,[rows[H][0],sum(rows[H][1:])]))
    print('Matched all',len(rows),'historical height pairs in both physical weights.')
