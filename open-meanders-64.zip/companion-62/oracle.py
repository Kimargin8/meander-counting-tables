"""Exact lower-tree census by centroid size and by depth, without an upper bitmap."""
from fractions import Fraction
from math import comb


def cat(n):
    return comb(2*n, n)//(n+1)


def multiply(a, b, n):
    out = [0]*(n+1)
    for i, x in enumerate(a):
        if x:
            for j in range(min(n-i+1, len(b))):
                out[i+j] += x*b[j]
    return out


def lower_census(n):
    # B=z/(1-B). B/z is the Catalan series, and its square has coefficients C_(i+1).
    b = [0] + [cat(i) for i in range(n)]
    factor = [0] + [cat(i+1) for i in range(n)]
    # D0=2z B^2/(1-B)^3=2 B^5/z^2 marks an ordered pair of different children
    # of the root of a planted tree. [z^m] B^5=5/m binom(2m-6,m-5).
    depth_mass = [0]*(n+1)
    for s in range(3, n+1):
        m = s+2
        depth_mass[s] = 10*comb(2*m-6, m-5)//m
    depths = []
    for h in range(n):
        depths.append(depth_mass)
        depth_mass = multiply(depth_mass, factor, n)

    previous = [Fraction(0)]*(n+2)
    families = {}
    for t in range(1, (n+1)//2+1):
        B = b[:t+1]
        powers = [[1]+[0]*n]
        for k in range(1, n+1):
            powers.append(multiply(powers[-1], B, n))
        inclusive = [Fraction(0)]*(n+2)
        for k in range(1, n+1):
            ways = powers[k][n]
            if not ways:
                continue
            rotate = Fraction(2*n, k)
            inclusive[0] += rotate*ways
            inclusive[1] += rotate*(4*n-2*k)*ways
            inclusive[2] += rotate*k*(k-1)*ways
            for h in range(1, min(t-1, n-1)):
                mass = sum(depths[h-1][s]*powers[k-1][n-s] for s in range(h+2,t+1))
                inclusive[2+h] += 2*n*mass
        centers = 2 if 2*t == n+1 else 1
        exact = [(x-y)/centers for x,y in zip(inclusive, previous)]
        assert all(x.denominator == 1 and x >= 0 for x in exact)
        lower, base, *by_depth = map(int, exact)
        families[t] = dict(lower=lower, base=base, by_depth=by_depth,
                           degree=base+sum(by_depth))
        previous = inclusive
    assert sum(x['lower'] for x in families.values()) == cat(n)
    assert sum(x['degree'] for x in families.values()) == 2*n*(cat(n+1)-cat(n))
    return families


def plan(n):
    families = lower_census(n)
    parts = []
    for t, row in families.items():
        # The small full run exercises whole, base and sibling calculations.
        if n == 31:
            classes = 0 if t <= 8 else (4 if t in (9, 10, 15, 16) else 8)
        else:
            classes = 0 if t == 1 else 2
        if not classes:
            labels = [('whole', 0, 0, row['degree'])]
        else:
            labels = [('base', 0, 0, row['base'])]
            for residue in range(classes):
                weight = sum(row['by_depth'][residue::classes])
                if weight:
                    labels.append(('siblings', residue, classes, weight))
        assert sum(w for _,_,_,w in labels) == row['degree']
        for kind, residue, classes, weight in labels:
            name = f't{t:02d}-{kind}'
            if classes:
                name += f'-{residue}-mod-{classes}'
            parts.append(dict(id=name, order=n, family=t, kind=kind, residue=residue,
                              classes=classes, lower=str(row['lower']), weight=str(weight)))
    return parts
