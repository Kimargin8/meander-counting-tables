"""Reconstruct the ordinary 62-crossing count from two lower-tree evaluations."""
import json
from pathlib import Path
from oracle import cat, lower_census, plan

ROOT = Path(__file__).resolve().parent


def check(condition, description):
    if not condition:
        raise ValueError(description)


def read(name):
    return json.loads((ROOT / name).read_bytes())


def verify():
    marked = read("marked.json")
    degree = read("degree.json")
    result = read("result.json")
    check(list(range(1, 17)) == [r["family"] for r in marked], "marked families")
    census = lower_census(32)
    for row in marked:
        lower, weight, value = (int(row[k]) for k in ("lower", "weight", "value"))
        check(lower == census[row["family"]]["lower"], "family size")
        check(2 * lower <= weight <= 32 * lower, "cyclic ear bounds")
        check(0 < value <= weight * cat(32) and value % 64 == 0, "marked value")
    check(sum(int(r["lower"]) for r in marked) == cat(32), "lower matchings")
    check(sum(int(r["weight"]) for r in marked) == 64 * cat(31), "marked matchings")
    parts = plan(31)
    check([row["part"] for row in degree] == parts and len(parts) == 64, "degree partition")
    for row in degree:
        check(0 <= int(row["value"]) <= int(row["part"]["weight"]) * cat(31), "slice bound")
    check(sum(int(p["weight"]) for p in parts) == 62 * (cat(32) - cat(31)), "degree mass")
    a = sum(int(r["value"]) for r in marked)
    b = sum(int(r["value"]) for r in degree)
    check(a == int(result["marked"]["numerator"]) and b == int(result["degree"]["numerator"]), "numerators")
    q, r = divmod(a, 64)
    check(r == 0 and b == 62 * q and q == int(result["ordinary_open_62"]), "exact quotients")
    return q


if __name__ == "__main__":
    print("Verified O62 =", verify())
