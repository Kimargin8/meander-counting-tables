# The ordinary 62-crossing count

Iaroslav Argunov

Each linked pair of noncrossing perfect matchings has labelled crossing positions and distinguished banks. For a lower matching of order 32, choose a cyclically adjacent arc and remove it with its endpoints. The inverse inserts a short arc in a chosen cyclic gap. This gives 64 copies of every 62-crossing open diagram. The successful weighted contributions of the 16 families sum to 2383059763353199848510120177792.

At order 31, choose a gap on a face of the lower tree and cut an incident arc. A face of degree d has d possible gaps and d possible arc choices. Summing its squared degree over all faces, then summing over connected pairs, gives 62 copies of every 62-crossing open diagram. The 64 contributions sum to 2308589145748412353244178922236.

Division by 64 and by 62 respectively gives 37235308802393747632970627778. The two computations share the upper-connectivity transfer. The included lower-tree oracle reconstructs the partition weights. The offline verifier checks the family partition, sizes, arithmetic bounds, contributions and both divisions. Use `python -B companion-62/verify.py` from the dataset root. SHA-256 digests in each table identify the original measured contributions.

The predecessor O60 was published by Vladimir Osipov. [Osipov's preprint](https://doi.org/10.5281/zenodo.22773575) · [Alepis's tree/bitmap implementation](https://github.com/talepis/meander-tree-bitmap/tree/c6904a0e2970ce46c70fc79c1378c575d3336431) · [Ordinary open meanders](https://oeis.org/A005316)
