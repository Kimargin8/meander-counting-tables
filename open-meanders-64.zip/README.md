# An independent reconstruction of the open meander number at 64 crossings

Iaroslav Argunov · Version 1.0.0. [Permanent record](https://doi.org/10.5281/zenodo.24516880).

This dataset reconstructs the integer from weighted transfer receipts. Python 3.10 or later and its standard library suffice. From the extracted top-level directory run

~~~sh
python -B research/review85/capacity/open_receipts.py --verify
~~~

The machine-readable result is in `output/research85/capacity/open-receipts.json`. The program checks every contributing output hash, the family and marking keys, the weight of the lower-bank class, the lower-bank coverage, the transfer's 128-bit envelope, the final divisibilities, the previous prediction interval and a separately derived residue.

## Counting identity

Choose physical labels on the line and distinguish the banks. For a connected closed pair of order 32, the lower arcs define a plane tree with 32 edges. Passing the cut through the 64 corners in turn counts each face of degree \(d\) with multiplicity \(d\). The number of open configurations obtained by marking an exterior arc is the exterior degree. Rotation therefore gives the identity

\[
64 O_{64}=\sum_{\text{connected closed pairs of order }32}\sum_v d(v)^2.
\]

The decomposition of the second moment for an \(n\)-edge tree with \(L\) leaves follows from \(\sum_v d(v)=2n\):

\[
\sum_v d(v)^2=(4n-6)+2L+
       \sum_{v:\,d(v)\ge4}(d(v)-2)(d(v)-3).
\]

The complete second moments are available directly for twelve centroid families. For the other four families (11 through 14), earlier closed and leaf-marked counts provide the first two summands. New transfers supply the last one. The value is assembled both by adding the entire numerator and by dividing complete rotation-invariant centroid groups separately.

## Coverage and numerical checks

The family index is the largest branch of a centroid. At a fixed first largest branch the physical weight is twice the forward distance, in tree vertices, to the next largest branch, including a full turn when the maximum is unique. An independent ordered-tree recursion yields the complete lower-bank count and every marked mass by mark depth and one or two contour heights. At both historical cuts, unmarked and leaf-marked masses can be compared with independent older lower-language plans.

Each finished transfer measures the sum of unknown nonnegative values over specified height/depth cells. Exact rational elimination tests consistency of overlapping receipts. It recovers the total when the all-ones indicator lies in the linear span of the measured indicators. An incomplete run keeps an explicit incomplete flag. Failed or interrupted jobs have no successful receipt and contribute nothing. The final integer must lie between 411154648288804845393389922374 and 411170598697626385256220114785, inclusive, and have residue 3 modulo 4. Both checks were recorded while family 14 was still incomplete.

The two reconstructions use different lower-bank calculations and assembly procedures. They share the original upper-connectivity transfer. This archive verifies the deposited outputs and their provenance. A new enumeration with a different upper transfer would provide an additional test.

## Provenance and scope

The deposited numerical extracts contain the family definitions, measured integer weights and exact connected contributions. The verifier recomputes every family coverage, consistency equation, division, residue and aggregate from those extracts. Hashes in the extracts refer to the public files. The original run records have separate digests in `original-output-digests.json`. The two assemblies share their upper-connectivity counts. Generating all those counts afresh requires the high-order transfer and its computational resources. The method uses the tree/bitmap transfer of Efthimios Alepis and the weighted lower-tree extension described here. [Alepis, tree/bitmap source](https://github.com/talepis/meander-tree-bitmap/tree/c6904a0e2970ce46c70fc79c1378c575d3336431)

## Earlier even open counts

Vladimir Osipov published the ordinary count **O60 = 3383262281572596355695881934** in September 2026, on page 13 of his preprint. [Osipov, *Exact enumeration of closed and open meanders*](https://doi.org/10.5281/zenodo.22773575) · [Production release](https://github.com/zouxuoz/first-crossing-meanders/releases/tag/v1.0-preprint).

The ordinary count **O62 = 37235308802393747632970627778** is documented in the [companion data](companion-62/README.md). The marked-ear calculation has 16 families and the squared-degree calculation has 64 pieces. The lower constructions and orders differ. Both use the Alepis upper transfer. Run `python -B companion-62/verify.py` to recover the two exact numerators and their common quotient.

## Independent small-order recount

The self-contained `direct_open.py` enumerates the frontier of the labelled closed pairs directly. An exterior lower arc corresponds to one ordinary open diagram. The first entry in a state counts paths and the second totals exterior lower arcs. A component closes only at the final crossing. Python integers have arbitrary precision. Run `python -B direct_open.py --check-through 11` to compare the full counts with two earlier tables through 22 crossings. The command `python -B direct_open.py --order 32` specifies an exact alternative for the 64-crossing count on sufficiently large resources. Its full runtime and memory requirement at order 32 have not been measured.
