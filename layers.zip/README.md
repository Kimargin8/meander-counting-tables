# An exact census of semi-meander transfer states

**Iaroslav Argunov · November 2026**

The article counts the boundary matchings reached at each step of the classical semi-meander transfer when all admissible initial windings are included. Its test for reachability uses the eccentricity of the river gap in a tree. Summed over all layers, the number of reflection classes is asymptotic to half the Fibonacci number $F_{n+1}$. The supplement gives separate second terms at even and odd orders.

[Article (PDF)](paper/layer-census.pdf) · [Parity supplement (PDF)](paper/frontier-pairs.pdf) · [Two complete coefficient rows](data/A046726-additions-821-903.txt) · [Five fixed-component sequences](data/fixed-components.tsv)

## The enumeration

On $2n$ ordered points, fix the fully nested matching joining the first point to the last, the second to the penultimate, and so on. The upper matching ranges over all labelled noncrossing perfect matchings. The coefficient of degree $k$ counts those choices whose union with the fixed matching has k components. The transfer combines reflected intermediate states by adding their multiplicities. The coefficient row still counts all labelled upper matchings.

OEIS A046726 lists each row in decreasing component count. The 41 entries at order 41 occupy positions 821–861. The 42 entries at order 42 occupy positions 862–903. Degrees 2 through 6 give A046721 through A046725. Andrew Howroyd supplied the preceding complete rows through order 40. The connected coefficients at orders 41 and 42 already occur in A000682. [A046726](https://oeis.org/A046726) · [A000682](https://oeis.org/A000682)

The classical local transitions appear in Di Francesco, Guitter and Jacobsen and in Jensen. Alepis derived a sharp Fibonacci exponent for the transfer starting at the empty frontier. Here the count concerns the union over admissible initial windings, with an exact formula at each layer and an explicit limiting profile. [Di Francesco, Guitter and Jacobsen](https://arxiv.org/abs/cond-mat/0003008) · [Jensen](https://arxiv.org/abs/cond-mat/0008178) · [Alepis, Section 14](https://doi.org/10.5281/zenodo.21871516)

## Reproduce the results

Run the following commands from this directory. The checks use Python 3.10 or newer and its standard library. The recorded computations used Python 3.13.5.

```sh
python -B verify.py
python -B src/check_census.py --data data
python -B src/check_pairs.py --data data
```

The first command compares both full rows with the independent packed-integer calculation and checks every fixed-component table entry. It also enumerates all labelled matchings through order 8 and checks the Catalan row sums through order 42. The second command recomputes 46 layer profiles and compares them with observed layer counts and peaks. The third checks the parity calculation by literal excursions through order 22 and reads four independently computed adjacent-order pairs through 801.

To repeat the complete polynomial computation with a C++17 compiler on a 64-bit system:

```sh
c++ -O2 -std=c++17 src/census_transfer.cpp -o census_transfer
python -B verify.py --native ./census_transfer --orders 8 41 42
```

On Windows, use a Visual Studio x64 Developer Command Prompt:

```bat
cl /nologo /O2 /EHsc /std:c++17 /DNDEBUG src\census_transfer.cpp /Fe:census_transfer.exe
python -B verify.py --native census_transfer.exe --orders 8 41 42
```

The transfer computes the entire polynomial in one pass. At most `(n+1)*4^t` histories reach step $t$, so the two-limb coefficients cover every supported order through 44. The measured order-42 run with preallocated layers used about 5.8 GiB on Windows. The code applies an 8 GiB process limit on Windows. Individual memory limits and timings on other platforms depend on the implementation.

The [native measurements](data/native-benchmark.json) contain the run order, wall times, process peaks and coefficient digests. A uses growable state arrays, B allocates their exact sizes before each layer. To recompute the table of comparisons:

```sh
python -B src/native_report.py --runs data/native-benchmark.json --ref data/native.json --ref42 data/native42.json --out measured-summary.json
```

The result agrees with [the deposited summary](data/native-structure.json). To repeat the actual paired experiment on Windows, build both binaries with `src/native_build.py --help` and run `src/native_bench.py --help`. Only the paired timing driver needs the optional dependency `psutil` (7.2.2 for the recorded run). The separate [two-wall image calculation](src/image_census.py) accepts `--reference data/layer-sizes.json --verify data/image-census.json` to repeat all 3,695 layer counts over 52 orders. This last step is longer than the three checks above.

## Comparison with Howroyd's transfer

The independent full rows at [order 41](data/howroyd-packed-41.json) and [order 42](data/howroyd-packed-42.json) use Andrew Howroyd's 2015 C# implementation. Each history carries a single integer with enough bits per digit for the corresponding coefficient. The archived runs agree with the C++ coefficient arrays at every degree, and give identical transition totals and peak numbers of shapes.

The [comparison directory](reference-check/) contains the drivers written for this experiment. Obtain Howroyd's unmodified source separately and save it as `Howroyd.cs`. Its SHA-256 is `0c6dab2e65c7b3be676153f7a7e739b05afeefbd924539af6706d042361f468f`. Howroyd's source header gives its terms of use, including the option of LGPL 2.1. [Original C# source and terms](https://oeis.org/A005316/a005316.cs.txt)

With the .NET Framework C# compiler on Windows, the following builds the packed comparison and prints the order, transition count, peak state count, process memory, time and all coefficients in increasing degree order. Use order 8 for a quick test.

```bat
csc /nologo /optimize+ /r:System.Numerics.dll /main:Application.PackedCheck /out:PackedCheck.exe Howroyd.cs reference-check\HowroydCheck.cs reference-check\PackedCheck.cs
PackedCheck.exe 8
```

The deposited order-42 run used the capacity-aware driver `SizedPackedCheck.cs` with .NET 8 x64. Its record includes the state count at each layer, runtime version, source digests and checkpoint information. `PackedCheck` implements the same packed evaluation with the default dictionary allocator. For a set-by-set comparison between Howroyd's observed keys and the predicted support, supply the same upstream file, the adaptation driver `HowroydCheck.cs` and the path of the framework compiler to `reference-check/exact_frontier.py --help`.

Both manuscripts are self-contained LaTeX files. They build with Tectonic. The diagram in the main article is drawn by the source. The PDFs, source files and original computation data follow the licenses specified in [NOTICE.md](NOTICE.md).
