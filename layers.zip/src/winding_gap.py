"""Find each starting winding of one marked shape using physical arch partners."""
from argparse import ArgumentParser
from functools import cache
from itertools import product
import json
from pathlib import Path


@cache
def joined(word,gap):
    stack=[]; mate={}
    for i,ch in enumerate(word):
        if ch=="(":
            stack.append(i)
        else:
            j=stack.pop(); mate[j]=i;mate[i]=j
    left,right=gap-1,gap
    old_left,old_right=mate[left],mate[right]
    if old_left!=right:
        mate[old_left]=old_right;mate[old_right]=old_left
    # The surviving linear order is increasing in the old indices.
    return "".join("(" if i<mate[i] else ")" for i in range(len(word)) if i not in (left,right))


def run(history,n,w):
    word="("*w+")"*w;gap=w
    for t,action in enumerate(history,1):
        if action=="U" and gap:
            gap-=1
        elif action=="D" and gap<len(word):
            gap+=1
        elif action=="O":
            word=word[:gap]+"()"+word[gap:];gap+=1
        elif action=="C" and 0<gap<len(word):
            word=joined(word,gap);gap-=1
        else:
            return None
        if max(gap,len(word)-gap)>n-t:
            return None
    return word,gap


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("--out",required=True,type=Path)
    args=cli.parse_args()
    n,t=13,6
    target=("()((()))",7)
    mirror=(target[0][::-1].translate(str.maketrans("()",")(")),len(target[0])-target[1])
    by_w={}
    for w in range(n%2,n+1,2):
        hits={target:[],mirror:[]}
        for letters in product("OUDC",repeat=t):
            state=run(letters,n,w)
            if state in hits:
                hits[state].append("".join(letters))
        by_w[w]=dict(oriented_count=len(hits[target]),reflected_count=len(hits[mirror]),
                     example=hits[target][:1])
    assert {w for w,data in by_w.items() if data["oriented_count"]}=={1,5}
    assert all(d["oriented_count"]==d["reflected_count"] for d in by_w.values())
    report=dict(order=n,processed=t,target_parentheses=target[0],gap=target[1],
                canonical_howroyd_key=20826,histories_examined=len(by_w)*(4**t),
                actions="O introduce adjacent arch; U or D move gap; C remove its two neighbours and reconnect",
                by_winding=by_w)
    args.out.write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
    print(by_w)


if __name__=="__main__":
    main()
