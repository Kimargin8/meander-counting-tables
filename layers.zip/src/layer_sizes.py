"""Count complete semi-meander transfer layers using only bounded Dyck walks."""
from argparse import ArgumentParser
from functools import cache
from pathlib import Path
import json


@cache
def walks(length, ceiling):
    """Counts for each final height of a nonnegative walk starting at zero."""
    if length == 0:
        return (1,) + (0,) * ceiling
    previous = walks(length - 1, ceiling)
    return tuple((previous[h - 1] if h else 0)
                 + (previous[h + 1] if h < ceiling else 0) for h in range(ceiling + 1))


@cache
def bounded(m, gap, ceiling):
    """Oriented and reflection-fixed reduced words of height at most ceiling."""
    if ceiling < 0:
        return 0, 0
    count = walks(2 * m, ceiling)[0]
    if 0 < gap < 2 * m:
        left = walks(gap - 1, ceiling)
        right = walks(2 * m - gap - 1, ceiling)
        count -= sum(left[h] * right[h] for h in range(ceiling))
    fixed = 0
    if gap == m:
        # An invariant word is fixed by its first m steps. For m>0 its
        # central position may not be a peak, hence the last step goes down.
        fixed = sum(walks(m - 1, ceiling)[1:]) if m else 1
    return count, fixed


@cache
def reduced(m, gap, t):
    total, fixed = bounded(m, gap, m)
    ceiling = 2 * m - t - 1
    if ceiling < 0:
        return total, fixed
    low, sym_low = bounded(m, gap, ceiling)
    return total - low, fixed - sym_low


def layer(n, t):
    r = n - t
    oriented = fixed = 0
    for m in range(min(t, r) + 1):
        for gap in range(max(0, 2 * m - r), m + 1):
            larger_shore = 2 * m - gap
            multiplicity = (r - larger_shore) // 2 + 1
            count, symmetric = reduced(m, gap, t)
            oriented += multiplicity * count * (1 if gap == m else 2)
            fixed += multiplicity * symmetric
    if (oriented + fixed) % 2:
        raise ArithmeticError("Reflection orbit parity")
    return (oriented + fixed) // 2


def profile(n):
    sizes = [layer(n, t) for t in range(n + 1)]
    return {"n": n, "layers": sizes, "peak": max(sizes),
            "peak_after_crossings": [t for t, value in enumerate(sizes) if value == max(sizes)]}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("orders", type=int, nargs="+")
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if min(args.orders) < 0:
        parser.error("orders must be nonnegative")
    result = [profile(n) for n in args.orders]
    args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
