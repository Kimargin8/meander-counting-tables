// Native transfer for the complete semi-meander polynomial. The four local
// operations follow Jensen (2000), with Howroyd's convention for shore bits.
// Each shape carries a variable-length coefficient vector. No source code
// from the reference C# implementation is linked into this executable.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <exception>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <psapi.h>
#pragma comment(lib, "Psapi.lib")
#endif

using u64 = std::uint64_t;
using u32 = std::uint32_t;
struct Shape { u64 a, b; };
struct Node { Shape shape; std::size_t offset; unsigned first, last; };
using Nodes = std::vector<Node>;
struct Layer { Nodes nodes; std::vector<u64> lo; std::vector<u32> hi; };
constexpr u32 absent = std::numeric_limits<u32>::max();

u64 mix(u64 x) {
    x ^= x >> 30; x *= UINT64_C(0xbf58476d1ce4e5b9);
    x ^= x >> 27; x *= UINT64_C(0x94d049bb133111eb);
    return x ^ (x >> 31);
}
class Index {
    Nodes& nodes;
    std::vector<u32> slots;
    std::size_t lookup(Shape s) const {
        const auto mask = slots.size()-1;
        auto j = mix(s.a ^ mix(s.b)) & mask;
        while (slots[j] != absent) {
            const Shape here = nodes[slots[j]].shape;
            if (here.a == s.a && here.b == s.b) break;
            j = (j+1) & mask;
        }
        return j;
    }
    void resize(std::size_t size) {
        slots.assign(size, absent);
        for (u32 i=0; i<nodes.size(); ++i) slots[lookup(nodes[i].shape)] = i;
    }
public:
    Index(Nodes& target, std::size_t estimate) : nodes(target) {
        std::size_t size=32;
        while (size < estimate*3/2) size *= 2;
        resize(size);
    }
    u32 insert(Shape s, unsigned first, unsigned last) {
        if (s.a > s.b) std::swap(s.a,s.b);
        if (3*nodes.size() >= 2*slots.size()) resize(2*slots.size());
        auto j=lookup(s);
        if (slots[j] == absent) {
            if (nodes.size() >= (absent>>1)) throw std::runtime_error("too many shapes");
            slots[j] = static_cast<u32>(nodes.size());
            nodes.push_back({s,0,first,last});
        } else {
            auto& n=nodes[slots[j]];
            n.first=std::min(n.first,first); n.last=std::max(n.last,last);
        }
        return slots[j];
    }
};

u64 repair(u64 shore,u64 other) {
    if ((shore & 1) == 0 && (other & 1)) {
        int balance=1;
        u64 flag=1;
        while (balance) {
            flag <<= 1;
            balance += (shore & flag) ? -1 : 1;
        }
        shore ^= flag;
    }
    return shore >> 1;
}

Layer advance(const Layer& cur,unsigned r,unsigned step,unsigned n,u64& transitions) {
    Layer next;
    std::vector<std::array<u32,4>> edges(cur.nodes.size());
    {
        Index index(next.nodes,cur.nodes.size());
        const u64 limit = u64(1) << (r+1);
        for (std::size_t i=0; i<cur.nodes.size(); ++i) {
            const auto& node=cur.nodes[i];
            const auto [a,b]=node.shape;
            auto& out=edges[i]; out.fill(absent);
            auto link=[&](unsigned action,u64 x,u64 y,unsigned close=0) {
                if (std::max(x,y) >= limit) return;
                out[action]=(index.insert({x,y},node.first+close,node.last+close)<<1) | close;
                ++transitions;
            };
            if (a!=1) link(0,a>>1, (b<<1) | (1-(a&1)));
            if (b!=1) link(1,(a<<1) | (1-(b&1)), b>>1);
            link(2,(a<<1)|1,(b<<1)|1);
            if (a!=1 && b!=1) link(3,repair(a,b),repair(b,a),(a&b&1)!=0);
        }
    }
    std::size_t cells=0;
    for (auto& node:next.nodes) {
        node.offset=cells; cells += node.last-node.first+1;
    }
    next.lo.resize(cells);
    // At most (n+1)*4^step partial histories, counting them irrespective
    // of pruning or symmetry. For the supported orders this is below 2^96.
    const bool wide=2*step+6>=64;
    if (wide) next.hi.resize(cells);
    for (std::size_t i=0; i<cur.nodes.size(); ++i) {
        const Node& src=cur.nodes[i];
        const std::size_t len=src.last-src.first+1;
        for (auto e:edges[i]) {
            if (e==absent) continue;
            const auto& dst=next.nodes[e>>1];
            const auto j=dst.offset+src.first+(e&1)-dst.first;
            const u64* in=cur.lo.data()+src.offset;
            u64* out=next.lo.data()+j;
            if (!wide) {
                for (std::size_t k=0;k<len;++k) out[k]+=in[k];
            } else {
                for (std::size_t k=0;k<len;++k) {
                    const u64 old=out[k];
                    out[k]+=in[k];
                    next.hi[j+k]+=(out[k]<old);
                    if (!cur.hi.empty()) next.hi[j+k]+=cur.hi[src.offset+k];
                }
            }
        }
    }
    return next;
}

std::uint64_t peak_bytes() {
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS p{};
    if (GetProcessMemoryInfo(GetCurrentProcess(),&p,sizeof(p))) return p.PeakWorkingSetSize;
#endif
    return 0;
}
double cpu_seconds() {
#ifdef _WIN32
    FILETIME creation,exit,kernel,user;
    if (GetProcessTimes(GetCurrentProcess(),&creation,&exit,&kernel,&user)) {
        const auto ticks=[](FILETIME t) { return (u64(t.dwHighDateTime)<<32) | t.dwLowDateTime; };
        return (ticks(kernel)+ticks(user))*1e-7;
    }
#endif
    return -1;
}
int main(int argc,char** argv) {
    try {
        if (argc!=2) throw std::runtime_error("usage: semi_front n (1..44)");
        const unsigned n=std::stoul(argv[1]);
        if (n<1 || n>44) throw std::runtime_error("order outside certified integer range");
#ifdef _WIN32
        HANDLE job=CreateJobObjectW(nullptr,nullptr);
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION guard{};
        guard.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_PROCESS_MEMORY;
        guard.ProcessMemoryLimit=std::size_t(8)<<30;
        if (!job || !SetInformationJobObject(job,JobObjectExtendedLimitInformation,&guard,sizeof guard)
            || !AssignProcessToJobObject(job,GetCurrentProcess()))
            throw std::runtime_error("cannot apply 8 GiB process limit");
#endif
        const auto start=std::chrono::steady_clock::now();
        Layer cur;
        for (unsigned w=n%2; w<=n; w+=2) {
            const u64 shore=(u64(1)<<(w+1))-1;
            cur.nodes.push_back({{shore,shore},cur.lo.size(),0,0});
            cur.lo.push_back(1);
        }
        u64 transitions=0,peak_nodes=cur.nodes.size(),peak_cells=cur.lo.size();
        for (unsigned step=1;step<=n;++step) {
            cur=advance(cur,n-step,step,n,transitions);
            peak_nodes=std::max<u64>(peak_nodes,cur.nodes.size());
            peak_cells=std::max<u64>(peak_cells,cur.lo.size());
        }
        const auto time=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
        if (cur.nodes.size()!=1 || cur.nodes[0].shape.a!=1 || cur.nodes[0].shape.b!=1)
            throw std::runtime_error("terminal state");
        const auto& end=cur.nodes[0];
        std::cout<<"{\"n\":"<<n<<",\"seconds\":"<<std::setprecision(8)<<time
                 <<",\"cpu_seconds\":"<<cpu_seconds()
                 <<",\"peak_working_set_bytes\":"<<peak_bytes()<<",\"transitions\":"<<transitions
                 <<",\"peak_shapes\":"<<peak_nodes<<",\"peak_cells\":"<<peak_cells
                 <<",\"coeff_hex\":[";
        for (unsigned k=0;k<=n;++k) {
            if (k) std::cout<<',';
            std::cout<<'\"';
            if (k<end.first || k>end.last) std::cout<<'0';
            else {
                const auto i=k-end.first;
                std::cout<<std::hex<<(cur.hi.empty()?0:cur.hi[i])<<std::setw(16)
                         <<std::setfill('0')<<cur.lo[i]<<std::dec;
            }
            std::cout<<'\"';
        }
        std::cout<<"]}\n";
    } catch (const std::exception& ex) {
        std::cerr<<ex.what()<<'\n'; return 1;
    }
}
