"""Build the unmodified baseline and census-sized variant with the same MSVC."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--source", type=Path, required=True)
    cli.add_argument("--out", type=Path, required=True)
    cli.add_argument("--vcvars", type=Path, required=True)
    a = cli.parse_args()
    out = a.out.resolve()
    out.mkdir(exist_ok=True,parents=True)
    src = a.source.read_bytes()
    if sha256(src).hexdigest() != "26fc541a51a9d528886e005c49823fe08c4fa2ebe2469c6679a6923cc468082e":
        raise ValueError("unexpected baseline source revision")
    (out/"baseline.cpp").write_bytes(src)
    variant = src.decode().replace("\r\n","\n")
    edits = [
        ("using u64 =", '#include "native_layers.hpp"\n\nusing u64 ='),
        ("while (size < estimate*3/2)", "nodes.reserve(estimate);\n        while (size < (3*estimate+1)/2)"),
        ("        if (3*nodes.size() >= 2*slots.size()) resize(2*slots.size());\n",""),
        ("unsigned n,u64& transitions)", "unsigned n,u64& transitions,std::size_t predicted)"),
        ("Index index(next.nodes,cur.nodes.size());", "Index index(next.nodes,predicted);"),
        ("    std::size_t cells=0;", '    if (next.nodes.size()!=predicted) throw std::logic_error("census mismatch");\n    std::size_t cells=0;'),
        ("        Layer cur;", "        const auto capacities=census_sizes(n);\n        const auto preprocessed=std::chrono::steady_clock::now();\n        Layer cur;"),
        ("advance(cur,n-step,step,n,transitions)", "advance(cur,n-step,step,n,transitions,capacities[step])"),
        ('                 <<",\\"cpu_seconds\\":"',
         '                 <<",\\"preprocessing_seconds\\":"<<std::chrono::duration<double>(preprocessed-start).count()\n                 <<",\\"cpu_seconds\\":"'),
    ]
    for old,new in edits:
        if variant.count(old)!=1:
            raise ValueError(old)
        variant = variant.replace(old,new)
    (out/"sized.cpp").write_text(variant,encoding="utf8")
    shutil.copy(Path(__file__).with_name("native_layers.hpp"),out/"native_layers.hpp")
    batch=out/"build.cmd"
    batch.write_text('@echo off\ncall "'+str(a.vcvars.resolve())+'" >nul\nif errorlevel 1 exit /b 1\n'
                     'cl /nologo /O2 /EHsc /std:c++17 /DNDEBUG baseline.cpp /Fe:baseline.exe\n'
                     'if errorlevel 1 exit /b 1\n'
                     'cl /nologo /O2 /EHsc /std:c++17 /DNDEBUG sized.cpp /Fe:sized.exe\n',encoding="ascii")
    subprocess.run(["cmd","/c","build.cmd"],cwd=out,check=True)


if __name__ == "__main__":
    main()
