// Exact numbers of reflection-canonical states. Order <=44 implies at most
// 22 reduced pairs. A walk count is at most 2^44, and at most 45^3 marked
// terms are summed per layer, so unsigned 64-bit arithmetic suffices.
#pragma once
#include <cstdint>
#include <utility>
#include <vector>

inline std::vector<std::size_t> census_sizes(unsigned n) {
    using count = std::uint64_t;
    if (n > 44) throw std::invalid_argument("unsupported census order");
    count walks[23][45][23]{};
    for (unsigned H=0; H<=n/2; ++H) {
        walks[H][0][0]=1;
        for (unsigned length=1; length<=n; ++length)
            for (unsigned h=0; h<=H; ++h)
                walks[H][length][h]=(h ? walks[H][length-1][h-1] : 0)
                                  +(h<H ? walks[H][length-1][h+1] : 0);
    }
    auto below=[&](int m,int q,int H) -> std::pair<count,count> {
        if (H<0) return {0,0};
        count oriented=walks[H][2*m][0], fixed=0;
        if (q>0 && q<2*m)
            for (int h=0; h<H; ++h)
                oriented-=walks[H][q-1][h]*walks[H][2*m-q-1][h];
        if (q==m) {
            if (!m) fixed=1;
            else for (int h=1; h<=H; ++h) fixed+=walks[H][m-1][h];
        }
        return {oriented,fixed};
    };
    std::vector<std::size_t> result(n+1);
    for (int t=0; t<=int(n); ++t) {
        const int r=int(n)-t;
        count twice=0;
        for (int m=0; m<=std::min(t,r); ++m) {
            for (int q=std::max(0,2*m-r); q<=m; ++q) {
                const auto full=below(m,q,m), low=below(m,q,2*m-t-1);
                const count multiplicity=1+(r-2*m+q)/2;
                twice+=multiplicity*((2-(q==m))*(full.first-low.first)
                                    +(full.second-low.second));
            }
        }
        if (twice%2) throw std::logic_error("invalid reflection orbit count");
        result[t]=std::size_t(twice/2);
    }
    return result;
}
