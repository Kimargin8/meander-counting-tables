"""Count occupied semi-meander shapes by two-wall images and deletion of a marked peak."""
from argparse import ArgumentParser
from functools import cache
from hashlib import sha256
import json
from math import comb, exp, isclose, log, pi, sqrt
from pathlib import Path
import platform
from time import perf_counter


@cache
def binomial(n, k):
    return comb(n, k) if 0 <= k <= n else 0


@cache
def image_sum(length, index, period):
    """Sum one residue class of a row of Pascal's triangle."""
    return sum(binomial(length, k) for k in range(index % period, length + 1, period))


def strip_walk(length, height, ceiling):
    if height < 0 or height > min(length, ceiling) or (length - height) % 2:
        return 0
    index = (length + height) // 2
    period = ceiling + 2
    return image_sum(length, index, period) - image_sum(length, index + 1, period)


@cache
def high_excursions(m, height):
    if height > m:
        return 0
    total = binomial(2 * m, m) // (m + 1)
    return total if height <= 0 else total - strip_walk(2 * m, 0, height - 1)


@cache
def fixed_below(m, ceiling):
    """A symmetric reduced word finishes its first half with a down step."""
    if ceiling < 0 or m == 0:
        return int(m == 0 and ceiling >= 0)
    length = m - 1
    low = 1 if length % 2 else 2
    high = min(ceiling, length)
    high -= (length - high) % 2
    if low > high:
        return 0
    # Summing the two-wall image difference over positive terminal heights
    # telescopes within each translate of this interval of binomial indices.
    start = (length + low) // 2
    end = (length + high) // 2
    return image_sum(length, start, ceiling + 2) - image_sum(length, end + 1, ceiling + 2)


def counts(m, gap, height):
    oriented = high_excursions(m, height)
    if 0 < gap < 2 * m:
        # Deleting the forbidden peak preserves passage to the threshold,
        # except when that peak was the sole visit to the threshold.
        oriented -= high_excursions(m - 1, height)
        if height > 0:
            wall = height - 1
            oriented -= strip_walk(gap - 1, wall, wall) * strip_walk(2 * m - gap - 1, wall, wall)
    fixed = fixed_below(m, m) - fixed_below(m, height - 1) if gap == m else 0
    assert 0 <= fixed <= oriented
    return oriented, fixed


def layer(n, t):
    remaining = n - t
    total = 0
    for m in range(min(t, remaining) + 1):
        threshold = 2 * m - t
        # Iterate both oriented shores. Apply Burnside only after the sum.
        for gap in range(max(0, 2 * m - remaining), min(2 * m, remaining) + 1):
            larger = max(gap, 2 * m - gap)
            wraps = 1 + (remaining - larger) // 2
            oriented, fixed = counts(m, gap, threshold)
            total += wraps * (oriented + fixed)
    assert total % 2 == 0
    return total // 2


def small_shapes(stop=7):
    """Check the peak-deletion and reflection formulas by listing actual words."""
    def words(word, height, left, right):
        if not left and not right:
            yield word
        if left:
            yield from words(word + (1,), height + 1, left - 1, right)
        if right and height:
            yield from words(word + (-1,), height - 1, left, right - 1)
    entries = 0
    for m in range(stop + 1):
        by_key = {}
        for word in words((), 0, m, m):
            height = maximum = 0
            for step in word:
                height += step
                maximum = max(maximum, height)
            symmetric = word == tuple(-v for v in reversed(word))
            for q in range(2 * m + 1):
                if 0 < q < 2 * m and word[q - 1:q + 1] == (1, -1):
                    continue
                for h in range(-1, maximum + 1):
                    pair = by_key.setdefault((q, h), [0, 0])
                    pair[0] += 1
                    pair[1] += int(symmetric and q == m)
        for q in range(2 * m + 1):
            for h in range(-1, m + 1):
                assert counts(m, q, h) == tuple(by_key.get((q, h), (0, 0))), (m, q, h)
                entries += 1
    return entries


def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def summarize(n, values):
    peak = max(values)
    total = sum(values)
    digest = sha256((' '.join(map(str, values)) + '\n').encode()).hexdigest()
    phi = (1 + sqrt(5)) / 2
    constant = phi * 5**0.25 / sqrt(2 * pi)
    fib = fibonacci(n + 1)
    peak_times = [i for i, x in enumerate(values) if x == peak]
    result = dict(n=n, layers=len(values), peak=str(peak), total=str(total),
                  peak_times=peak_times, profile_sha256=digest,
                  fibonacci_n_plus_one=str(fib), sum_over_half_fibonacci=2 * total / fib,
                  peak_over_leading_form=exp(log(peak) + 0.5 * log(n) - n * log(phi) - log(constant)))
    if n >= 100:
        mode = peak_times[0]
        result['counts_near_peak'] = [[t, str(values[t])] for t in range(max(0, mode - 2), min(n, mode + 2) + 1)]
        moment = sum(t * count for t, count in enumerate(values))
        square = sum(t * t * count for t, count in enumerate(values))
        result['mean_time'] = moment / total
        result['variance_over_asymptotic'] = (total * square - moment * moment) / (n * total * total) * 20 * sqrt(5)
    return result


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--reference', type=Path, help='Earlier strip-walk profiles to compare layer by layer')
    mode = cli.add_mutually_exclusive_group(required=True)
    mode.add_argument('--out', type=Path, help='Write a record after cross-checking the reference profiles')
    mode.add_argument('--verify', type=Path, help='Replay every profile and digest in an existing record')
    cli.add_argument('--orders', nargs='+', type=int, default=[100, 150, 200, 300, 400, 600, 800])
    args = cli.parse_args()
    if not __debug__ or any(n < 1 for n in args.orders):
        cli.error('Use positive orders and enabled assertions')
    if args.out and not args.reference:
        cli.error('Supply --reference when producing a new record')
    started = perf_counter()
    reference = {}
    if args.reference:
        raw = args.reference.read_bytes()
        reference = {r['n']: r['layers'] for r in json.loads(raw)}
        assert set(range(1, 43)) <= reference.keys()
    source_hash = sha256(Path(__file__).read_bytes()).hexdigest()
    if args.verify:
        old = json.loads(args.verify.read_bytes())
        assert old['source_sha256'] == source_hash
        if args.reference:
            assert sha256(raw).hexdigest() == old['reference_sha256'] and sorted(reference) == old['reference_profile_orders']
        orders = [r['n'] for r in old['profiles']]
        assert orders == sorted(set(orders)) and set(old['reference_profile_orders']) <= set(orders)
    else:
        orders = sorted(reference.keys() | set(args.orders))
    small = small_shapes()
    rows = []
    matched = 0
    for n in orders:
        values = [layer(n, t) for t in range(n + 1)]
        if n in reference:
            assert values == reference[n], n
            matched += len(values)
        rows.append(summarize(n, values))
    if args.verify:
        assert old['small_word_parameter_sets'] == small
        if args.reference:assert old['matched_reference_layers'] == matched
        for actual, sealed in zip(rows, old['profiles'], strict=True):
            for key, value in actual.items():
                if isinstance(value, float):assert isclose(value, sealed[key], rel_tol=1e-12)
                else:assert value == sealed[key], (actual['n'], key)
        print('Reproduced', sum(r['layers'] for r in rows), 'layer counts by their full-profile digests,',
              len(rows), 'exact totals and peaks, and', small, 'direct word tests.')
        return
    record = dict(method='Two-wall images, single-peak deletion, telescoping symmetric walks, Burnside',
                  small_word_parameter_sets=small, matched_reference_layers=matched,
                  reference_profile_orders=sorted(reference), reference_sha256=sha256(args.reference.read_bytes()).hexdigest(),
                  source_sha256=source_hash, python=platform.python_version(),
                  profiles=rows, elapsed_seconds=perf_counter() - started)
    if platform.system() == 'Linux':
        import resource
        record['process_peak_rss_bytes'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    args.out.parent.mkdir(exist_ok=True, parents=True)
    args.out.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print('Matched', matched, 'known layers and', small, 'direct word tests.')
    for row in rows:
        if row['n'] in args.orders:
            print(row['n'], row['peak_times'], row['sum_over_half_fibonacci'], row['peak_over_leading_form'])


if __name__ == '__main__':
    main()
