"""Run preset paired full transfers, one logical processor and one fresh process per run."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import platform
from statistics import median
import subprocess
from time import monotonic


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main():
    import psutil
    cli = ArgumentParser(description=__doc__)
    for name in ("bin","ref","ref42","out"):
        cli.add_argument("--"+name,type=Path,required=True)
    cli.add_argument("--cpu",type=int,default=4)
    cli.add_argument("--budget",type=int,default=710)
    a = cli.parse_args()
    process=psutil.Process()
    if a.cpu not in process.cpu_affinity():
        raise OSError("logical processor unavailable")
    process.cpu_affinity([a.cpu])
    assert process.cpu_affinity()==[a.cpu]
    refs = {row["n"]:row for path in (a.ref,a.ref42)
            for row in json.loads(path.read_bytes())["rows"]}
    names={"A":"baseline","B":"sized"}
    binaries={k:a.bin/(name+".exe") for k,name in names.items()}
    # First observe each order in both variants. Reverse the big pairs only as
    # complete pairs, using observed times and remaining budget before starting.
    plan=[(30,"ABBA"),(32,"BAAB"),(36,"ABBA"),(40,"BA"),(42,"AB"),(40,"AB"),(42,"BA")]
    rows=[]
    started=monotonic()
    report={"machine":platform.platform(),"processor":"Intel i9-13980HX",
            "logical_cpu":a.cpu,"address_space_limit_GiB":8,"budget_seconds":a.budget,
            "plan":plan,"reference_sha256":{p.name:digest(p) for p in (a.ref,a.ref42)},
            "binary_sha256":{k:digest(p) for k,p in binaries.items()},
            "timing":"wall includes complete process, native seconds include census generation",
            "runs":rows,"skipped":[],"baseline":"A","census":"B","load_factor_limit":"2/3"}
    def run(n,k):
        free=psutil.virtual_memory().available
        begin=monotonic()
        raw=subprocess.check_output([str(binaries[k].resolve()),str(n)],timeout=a.budget+20-(begin-started))
        wall=monotonic()-begin
        data=json.loads(raw)
        values=[int(v,16) for v in data.pop("coeff_hex")]
        ref=refs[n]
        assert values==ref["coefficients"]
        for key in ("transitions","peak_shapes","peak_cells"):
            assert data[key]==ref[key]
        assert data["peak_working_set_bytes"] < 8*1024**3
        return dict(variant=k,wall_seconds=wall,available_before_bytes=free,
                    coefficients_sha256=sha256(" ".join(map(str,values)).encode()).hexdigest(),
                    **data)
    def save():
        report["elapsed_seconds"]=monotonic()-started
        report["summary"]={}
        for n in sorted({r["n"] for r in rows}):
            both={k:[r for r in rows if r["n"]==n and r["variant"]==k] for k in names}
            if all(both.values()):
                med={k:{key:median(v[key] for v in values) for key in
                        ("wall_seconds","seconds","cpu_seconds","peak_working_set_bytes")}
                     for k,values in both.items()}
                report["summary"][n]={"observations":{k:len(v) for k,v in both.items()},
                    "median":med,"wall_speedup":med["A"]["wall_seconds"]/med["B"]["wall_seconds"],
                    "rss_reduction":1-med["B"]["peak_working_set_bytes"]/med["A"]["peak_working_set_bytes"]}
        a.out.write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
    if not __debug__:
        raise ValueError("Assertions required")
    for n in range(1,15):
        for k in names:
            run(n,k)
    report["preflight_orders"]=list(range(1,15))
    save()
    for index,(n,modes) in enumerate(plan):
        needed=max([v["wall_seconds"] for v in rows if v["n"]==n]
                   or [refs[n]["seconds"]])*len(modes)*1.05
        if needed>a.budget-(monotonic()-started) or psutil.virtual_memory().available<10*1024**3:
            report["skipped"].append({"block":index,"n":n,"reason":"remaining time or free memory",
                "estimated_seconds":needed,"free_bytes":psutil.virtual_memory().available})
            save()
            continue
        for k in modes:
            row=run(n,k)
            rows.append(row)
            print(n,k,round(row["wall_seconds"],3),row["peak_working_set_bytes"],flush=True)
            save()
    report["finished"]=True
    save()


if __name__=="__main__":
    main()
