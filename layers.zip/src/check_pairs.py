"""Check the generating series by literal excursions and read the adjacent-order holdouts."""
import argparse
from math import sqrt, pi
from pathlib import Path
import json


def excursions(n):
    def extend(ups, downs, path):
        if ups == downs == n:
            yield path
        if ups < n:
            yield from extend(ups + 1, downs, path + (path[-1] + 1,))
        if downs < ups:
            yield from extend(ups, downs + 1, path + (path[-1] - 1,))
    yield from extend(0, 0, (0,))


def small(limit):
    ordinary, contact, fixed = ([0] * (limit + 1) for _ in range(3))
    for m in range(limit // 2 + 1):
        for path in excursions(m):
            height = max(path)
            for q, value in enumerate(path):
                degree = 3 * m - height + abs(q - m)
                if degree > limit:
                    continue
                ordinary[degree] += 1
                if value == height:
                    contact[degree] += 1
                if q == m and path == path[::-1] and (m == 0 or path[m] < path[m - 1]):
                    fixed[degree] += 1
    assert all(v == 0 for v in contact[1::2])
    # D=1/((1-x)^2(1-x^2)). Its nth coefficient counts (past excess,
    # number of wraps, half the unused future length) of total size n.
    den = [sum(n - 2 * j + 1 for j in range(n // 2 + 1)) for n in range(limit + 1)]
    get = lambda a, i: a[i] if i >= 0 else 0
    regular_num = [ordinary[i] - get(ordinary, i - 3) + fixed[i] for i in range(limit + 1)]
    exceptional_num = [get(contact, i - 2) - get(contact, i - 3) for i in range(limit + 1)]
    multiply = lambda a, i: sum(a[j] * den[i - j] for j in range(i + 1))
    regular = [multiply(regular_num, i) for i in range(limit + 1)]
    omitted = [multiply(exceptional_num, i) for i in range(limit + 1)]
    assert all(omitted[i] == omitted[i + 1] for i in range(0, limit, 2))
    assert all((x - y) % 2 == 0 for x, y in zip(regular, omitted))
    return [(x - y) // 2 for x, y in zip(regular, omitted)], omitted


def receipt(data):
    def read(name):
        return json.loads((data / name).read_bytes())
    profiles = {x["n"]: x for name in ("image-census.json", "adjacent-profiles.json")
                for x in read(name)["profiles"]}
    totals, omitted = small(22)
    assert totals[0] == 1 and all(int(profiles[n]["total"]) == totals[n] for n in range(1, len(totals)))
    z = (sqrt(5) - 1) / 2
    alpha = (1 + 1 / sqrt(5)) / 4
    k = z**5 / (2 * sqrt(pi * alpha * z*z * (1 - z*z)))
    checks = []
    for n in (200, 400, 600, 800):
        even, odd = profiles[n], profiles[n + 1]
        fe, fo = int(even["fibonacci_n_plus_one"]), int(odd["fibonacci_n_plus_one"])
        te, to = int(even["total"]), int(odd["total"])
        ideal_twice = fo - fe
        actual_twice = 2 * (to - te)
        checks.append(dict(even_order=n, even_scaled_deficit=(fe-2*te)*sqrt(n)/fe,
                           odd_scaled_deficit=(fo-2*to)*sqrt(n+1)/fo,
                           normalized_adjacent_error=(actual_twice-ideal_twice)/ideal_twice,
                           exact_twice_adjacent_error=str(actual_twice-ideal_twice)))
    return dict(exact_small_totals=totals, twice_small_omitted=omitted,
                K_even=k, K_odd=z*k, numerical_checks=checks)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--write", type=Path)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError("Enable Python assertions")
    result = receipt(args.data)
    if args.write:
        args.write.write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
    else:
        expected = json.loads((args.data / "parity-check.json").read_bytes())
        for field in ("exact_small_totals", "twice_small_omitted"):
            assert result[field] == expected[field]
        assert [r["exact_twice_adjacent_error"] for r in result["numerical_checks"]] == [
            r["exact_twice_adjacent_error"] for r in expected["numerical_checks"]]
    print("Compared literal generating-series coefficients through 22 and four exact pairs through 801.")
