"""Recompute the layer census from a clean review archive."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

from layer_sizes import profile


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def validate(data):
    profiles = {entry["n"]: entry for entry in read(data / "layer-sizes.json")}
    for n, record in profiles.items():
        if profile(n) != record:
            raise ValueError(f"Layer mismatch at {n}")
    history = read(data / "exact-language.json")
    for row in history["layers"]:
        if profiles[row["n"]]["layers"][row["t"]] != row["keys"]:
            raise ValueError(f"Disagreement with the reference keys at {row}")
    if sum(r["keys"] for r in history["layers"]) != 48405 or len(history["layers"]) != 252:
        raise ValueError("Incomplete key comparison")
    rows = read(data / "native.json")["rows"] + read(data / "native42.json")["rows"]
    if {r["n"] for r in rows} != set(range(1, 43)):
        raise ValueError("Incomplete full-transfer comparison")
    for r in rows:
        if r["peak_shapes"] != profiles[r["n"]]["peak"]:
            raise ValueError(f"Observed transfer size at {r['n']}")
    with TemporaryDirectory() as work:
        replay = Path(work) / "winding.json"
        subprocess.run([sys.executable, "-B", str(Path(__file__).with_name("winding_gap.py")),
                        "--out", str(replay)], check=True, stdout=subprocess.DEVNULL)
        if read(replay) != read(data / "winding-gap.json"):
            raise ValueError("Winding witness changed")
    return len(profiles), len(history["layers"]), len(rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path(__file__).resolve().parent.parent / "data")
    args = parser.parse_args()
    print("Profiles, full key layers, observed peaks:", *validate(args.data))
