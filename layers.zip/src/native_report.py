"""Validate the paired native runs and model structural relocation of MSVC vectors."""
from hashlib import sha256
import json
from pathlib import Path
from statistics import median

from layer_sizes import profile


def allocations(sizes):
    moved = reserves = rehash_low = rehash_high = 0
    for previous, size in zip(sizes,sizes[1:]):
        cap = 0
        while cap<size:
            moved += cap
            reserves += 1
            cap = max(cap+1,cap+cap//2)
        slots = 32
        while slots<previous*3//2:
            slots *= 2
        while size >= (2*slots+2)//3:
            threshold = (2*slots+2)//3
            rehash_high += threshold
            if size>threshold:
                rehash_low += threshold
            slots *= 2
    return dict(old_node_relocations=moved,old_node_relocation_payload_bytes=32*moved,
                old_node_allocations=reserves,new_node_allocations=len(sizes)-1,
                old_hash_key_reinsertions_interval=[rehash_low,rehash_high],
                new_node_relocations=0,new_hash_key_reinsertions=0)


def summarize(data,refs):
    assert data["finished"] and data["preflight_orders"]==list(range(1,15))
    insights={}
    for n in sorted({r["n"] for r in data["runs"]}):
        records=[r for r in data["runs"] if r["n"]==n]
        modes=[r["variant"] for r in records]
        assert len(records)%2==0
        ref=refs[n]
        digest=sha256(" ".join(map(str,ref["coefficients"])).encode()).hexdigest()
        for row in records:
            assert row["coefficients_sha256"]==digest
            for key in ("transitions","peak_shapes","peak_cells"):
                assert row[key]==ref[key]
        sizes=profile(n)
        assert sizes["peak"]==ref["peak_shapes"]
        ratios=[]
        for i in range(0,len(records),2):
            pair={r["variant"]:r for r in records[i:i+2]}
            assert len(pair)==2
            ratios.append(pair["A"]["wall_seconds"]/pair["B"]["wall_seconds"])
        med=lambda mode,key:median(r[key] for r in records if r["variant"]==mode)
        insights[n]=dict(order="".join(modes),fresh_process_pairs=len(ratios),
            paired_wall_speedups=ratios,wall_median_A=med("A","wall_seconds"),
            wall_median_B=med("B","wall_seconds"),CPU_median_A=med("A","cpu_seconds"),
            CPU_median_B=med("B","cpu_seconds"),rss_mib_A=med("A","peak_working_set_bytes")/2**20,
            rss_mib_B=med("B","peak_working_set_bytes")/2**20,
            preparation_seconds_B=med("B","preprocessing_seconds"),structural=allocations(sizes["layers"]))
    return insights


def main():
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    for k in ("runs","ref","ref42","out"):
        p.add_argument("--"+k,type=Path,required=True)
    a=p.parse_args()
    if not __debug__:
        raise ValueError("Enable assertions")
    refs={r["n"]:r for path in (a.ref,a.ref42)
          for r in json.loads(path.read_bytes())["rows"]}
    data=json.loads(a.runs.read_bytes())
    for path in (a.ref,a.ref42):
        assert sha256(path.read_bytes()).hexdigest()==data["reference_sha256"][path.name]
    obj=summarize(data,refs)
    a.out.write_text(json.dumps(obj,indent=2)+"\n",encoding="utf8")


if __name__=="__main__":
    main()
