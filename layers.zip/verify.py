"""Verify the two semi-meander rows and their projections without downloading data."""
import argparse
import csv
from functools import cache
import json
from math import comb
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"


@cache
def matchings(order):
    """Partners of the first site split a labelled matching into two intervals."""
    if order == 0:
        return ((),)
    words = []
    for inside in range(order):
        partner = 2 * inside + 1
        for left in matchings(inside):
            for right in matchings(order - inside - 1):
                words.append((partner,) + tuple(i + 1 for i in left)
                             + (0,) + tuple(i + partner + 1 for i in right))
    return tuple(words)


def direct_polynomial(n):
    row = [0] * (n + 1)
    for upper in matchings(n):
        untouched = set(range(2 * n))
        components = 0
        while untouched:
            components += 1
            site = next(iter(untouched))
            while site in untouched:
                untouched.remove(site)
                other = upper[site]
                untouched.remove(other)
                site = 2 * n - 1 - other
        row[components] += 1
    return row


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native", type=Path, help="compiled native transfer")
    parser.add_argument("--orders", type=int, nargs="+", default=[1, 4, 8])
    args = parser.parse_args()
    rows = {}
    for filename in ("native.json", "native42.json"):
        rows.update((r["n"], r) for r in json.loads((DATA / filename).read_bytes())["rows"])
    require(set(rows) == set(range(1, 43)), "Incomplete native results")
    for n, item in rows.items():
        row = item["coefficients"]
        require(len(row) == n+1 and row[0] == 0 and row[n] == 1, f"Order {n}: support")
        require(sum(row) == comb(2*n, n)//(n+1), f"Order {n}: Catalan sum")
        if n <= 8:
            require(row == direct_polynomial(n), f"Order {n}: explicit arch enumeration")

    extension = {}
    for line in (DATA / "A046726-additions-821-903.txt").read_text().splitlines():
        i, value = map(int, line.split())
        require(i not in extension, f"Repeated position {i}")
        extension[i] = value
    require(list(extension) == list(range(821, 904)), "Incomplete or unordered OEIS positions")
    for n in (41, 42):
        item = rows[n]
        packed = json.loads((DATA / f"howroyd-packed-{n}.json").read_bytes())
        require(packed["coefficients"] == item["coefficients"], f"Order {n}: packed polynomial")
        require(packed["peak_states"] == item["peak_shapes"]
                and packed["complete_transitions"] == item["transitions"], f"Order {n}: geometry")
        for k in range(1, n + 1):
            require(extension[n*(n+1)//2 + 1 - k] == item["coefficients"][k], f"Order {n}: k={k}")
    with (DATA / "fixed-components.tsv").open(encoding="utf8", newline="") as source:
        columns = list(csv.DictReader(source, delimiter="\t"))
    require(len(columns) == 5, "Expected the five component sequences")
    for k, column in enumerate(columns, start=2):
        require(column["sequence"] == f"A04672{k-1}" and int(column["components"]) == k,
                f"Component column {k}")
        for n in (41, 42):
            require(int(column[f"order_{n}"]) == rows[n]["coefficients"][k], f"Column {k}: n={n}")

    if args.native:
        for n in args.orders:
            if n not in rows:
                parser.error("Use an order in 1..42 for comparison with the deposited data.")
            output = subprocess.check_output([str(args.native.resolve()), str(n)], text=True)
            item = json.loads(output)
            require([int(x, 16) for x in item["coeff_hex"]] == rows[n]["coefficients"],
                    f"Order {n}: new full computation")
            require(item["transitions"] == rows[n]["transitions"]
                    and item["peak_shapes"] == rows[n]["peak_shapes"], f"Order {n}: new geometry")
            print(f"Order {n}: full polynomial, peak states and transitions reproduced.")
    print("Verified 83 positions, five component sequences, both packed reference rows,"
          " 42 Catalan sums, and all explicit arch matchings through order 8.")


if __name__ == "__main__":
    main()
