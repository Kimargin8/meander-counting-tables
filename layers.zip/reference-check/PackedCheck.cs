// Independent numerical representation using the transitions published by
// Andrew Howroyd at https://oeis.org/A005316/a005316.cs.txt (2015).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;

namespace Application
{
    sealed class PackedCheck
    {
        static void Main(string[] args)
        {
            foreach (string arg in args)
            {
                int n = Int32.Parse(arg);
                int digit = 2*n;
                var clock = Stopwatch.StartNew();
                var source = new MeandersByComponents(n);
                var states = source.SemiMeanderInitialStates(null)
                    .ToDictionary(s => s.Item2, s => BigInteger.One);
                long transitions = 0;
                int peak = states.Count;
                for (int remaining=n-1; remaining>=0; --remaining)
                {
                    var layer = new MeandersByComponents(remaining);
                    var next = new Dictionary<BigInteger, BigInteger>();
                    foreach (var node in states)
                    {
                        foreach (var dest in layer.Enumerate(Tuple.Create(0, node.Key)))
                        {
                            BigInteger previous;
                            next.TryGetValue(dest.Item2, out previous);
                            next[dest.Item2] = previous + (node.Value << (digit * dest.Item1));
                            ++transitions;
                        }
                    }
                    states = next;
                    peak = Math.Max(peak, states.Count);
                    if (n >= 40 && remaining % 4 == 0)
                        Console.Error.WriteLine("Remaining {0}, states {1}, seconds {2:F0}", remaining, states.Count, clock.Elapsed.TotalSeconds);
                }
                if (states.Count != 1) throw new Exception("Unexpected final state count.");
                var value = states.Values.First();
                var mask = (BigInteger.One << digit) - 1;
                var row = new BigInteger[n+1];
                for (int i=0; i<=n; ++i)
                {
                    row[i] = value & mask;
                    value >>= digit;
                }
                if (value != 0 || row[n] != 1) throw new Exception("Packed result shape mismatch.");
                clock.Stop();
                Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}", n, transitions, peak,
                    Process.GetCurrentProcess().PeakWorkingSet64,
                    clock.Elapsed.TotalSeconds.ToString("F6", System.Globalization.CultureInfo.InvariantCulture),
                    String.Join(",", row.Select(x => x.ToString()).ToArray()));
            }
        }
    }
}
