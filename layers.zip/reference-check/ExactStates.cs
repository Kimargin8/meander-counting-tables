using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace Application
{
    class ExactStates
    {
        public static void Main(string[] args)
        {
            int maximum=int.Parse(args[0]);
            for (int n=1;n<=maximum;++n) {
                var states=new HashSet<ulong>(new MeandersByComponents(n).SemiMeanderInitialStates(null)
                                              .Select(s=>(ulong)s.Item2));
                for(int t=0;t<=n;++t) {
                    Console.WriteLine("{0} {1} {2}",n,t,
                        string.Join(",",states.OrderBy(x=>x).Select(x=>x.ToString()).ToArray()));
                    if(t==n) break;
                    var next=new HashSet<ulong>();
                    var step=new MeandersByComponents(n-t-1);
                    foreach(ulong s in states)
                        foreach(var dest in step.Enumerate(Tuple.Create(0,(BigInteger)s)))
                            next.Add((ulong)dest.Item2);
                    states=next;
                }
            }
        }
    }
}
