// Calls Howroyd's published transition iterator without modifying its source.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography;

namespace Application {
    static class SizedPackedCheck {
        static long transitions;
        static readonly Func<BigInteger,BigInteger> Big=x=>x;
        static readonly Func<ulong,BigInteger> Unpack=x=>new BigInteger(x);
        static readonly Func<BigInteger,ulong> Pack=x=>(ulong)x;

        static Dictionary<K,BigInteger> Advance<J,K>(Dictionary<J,BigInteger> old, int r, int capacity,
            int digit, Func<J,BigInteger> expand, Func<BigInteger,K> compress) {
            var machine=new MeandersByComponents(r);
            var next=new Dictionary<K,BigInteger>(capacity);
            foreach(var entry in old) {
                foreach(var dest in machine.Enumerate(Tuple.Create(0,expand(entry.Key)))) {
                    K key=compress(dest.Item2);
                    if(dest.Item1!=0 && dest.Item1!=1)throw new InvalidDataException("closure increment");
                    BigInteger weight=dest.Item1==0?entry.Value:entry.Value<<digit;
                    BigInteger prior;
                    if(next.TryGetValue(key,out prior)) next[key]=prior+weight;
                    else {
                        if(next.Count>=capacity)throw new InvalidDataException("extra key beyond census");
                        next.Add(key,weight);
                    }
                    ++transitions;
                }
            }
            if(next.Count!=capacity)throw new InvalidDataException("layer below census");
            return next;
        }

        static string Checksum(string path) {
            using(var stream=File.OpenRead(path))using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","");
        }

        static void Save(string path,string identity,int step,Dictionary<ulong,BigInteger> table) {
            using(var stream=new FileStream(path+".pending",FileMode.Create,FileAccess.Write,FileShare.None,1<<20))
            using(var writer=new BinaryWriter(stream)) {
                writer.Write(identity);writer.Write(step);writer.Write(transitions);writer.Write(table.Count);
                foreach(var entry in table) {
                    byte[] b=entry.Value.ToByteArray();writer.Write(entry.Key);writer.Write(b.Length);writer.Write(b);
                }
                writer.Write(identity);writer.Flush();stream.Flush(true);
            }
            File.WriteAllText(path+".sha256.pending",Checksum(path+".pending"));
            File.Move(path+".pending",path);File.Move(path+".sha256.pending",path+".sha256");
        }

        static Dictionary<ulong,BigInteger> Load(string path,string identity,int step,int count,int digit,int n) {
            if(File.ReadAllText(path+".sha256").Trim()!=Checksum(path))throw new InvalidDataException("checkpoint checksum");
            var table=new Dictionary<ulong,BigInteger>(count);
            using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read,1<<20))
            using(var reader=new BinaryReader(stream)) {
                if(reader.ReadString()!=identity || reader.ReadInt32()!=step)throw new InvalidDataException("checkpoint identity");
                transitions=reader.ReadInt64();if(reader.ReadInt32()!=count)throw new InvalidDataException("checkpoint shape");
                for(int i=0;i<count;++i) {
                    ulong key=reader.ReadUInt64();int size=reader.ReadInt32();
                    if(size<1 || size>(digit*(n+2)+7)/8)throw new InvalidDataException("invalid packed length");
                    byte[] bytes=reader.ReadBytes(size);if(bytes.Length!=size)throw new EndOfStreamException();
                    var value=new BigInteger(bytes);if(value.Sign<=0)throw new InvalidDataException("invalid packed value");
                    table.Add(key,value);
                }
                if(reader.ReadString()!=identity || stream.Position!=stream.Length)throw new InvalidDataException("incomplete checkpoint");
            }
            return table;
        }

        static void Main(string[] args) {
            int n=int.Parse(args[0]),digit=2*n;int[] sizes=File.ReadAllText(args[1]).Trim().Split(',').Select(int.Parse).ToArray();
            int checkpoint=int.Parse(args[2]);string file=args[3],identity=args[4];
            if(sizes.Length!=n+1 || sizes[n]!=1 || n<1 || n>42 || (checkpoint!=0 && n-checkpoint>30))throw new InvalidDataException("arguments");
            var clock=Stopwatch.StartNew();int step=0;
            Dictionary<BigInteger,BigInteger> large=null;Dictionary<ulong,BigInteger> small=null;
            if(checkpoint!=0 && File.Exists(file)) {
                step=checkpoint;small=Load(file,identity,step,sizes[step],digit,n);Console.Error.WriteLine("resumed sealed layer {0}",step);
            } else {
                large=new Dictionary<BigInteger,BigInteger>(sizes[0]);
                foreach(var seed in new MeandersByComponents(n).SemiMeanderInitialStates(null))large.Add(seed.Item2,BigInteger.One);
                if(large.Count!=sizes[0])throw new InvalidDataException("initial census");
            }
            for(++step;step<=n;++step) {
                int r=n-step;
                if(r>30)large=Advance(large,r,sizes[step],digit,Big,Big);
                else if(large!=null){small=Advance(large,r,sizes[step],digit,Big,Pack);large=null;}
                else small=Advance(small,r,sizes[step],digit,Unpack,Pack);
                Console.Error.WriteLine("step={0} remaining={1} states={2} transitions={3} seconds={4:F3}",step,r,sizes[step],transitions,clock.Elapsed.TotalSeconds);
                if(step==checkpoint){Save(file,identity,step,small);Console.Error.WriteLine("sealed checkpoint at step {0}",step);}
            }
            BigInteger polynomial=small.Values.First(),mask=(BigInteger.One<<digit)-1;var row=new BigInteger[n+1];
            for(int k=0;k<=n;++k){row[k]=polynomial&mask;polynomial>>=digit;}
            if(polynomial!=0 || row[n]!=1)throw new InvalidDataException("packed degree");
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}",n,transitions,sizes.Max(),Process.GetCurrentProcess().PeakWorkingSet64,
                clock.Elapsed.TotalSeconds.ToString("F6",CultureInfo.InvariantCulture),String.Join(",",row.Select(x=>x.ToString()).ToArray()));
        }
    }
}
