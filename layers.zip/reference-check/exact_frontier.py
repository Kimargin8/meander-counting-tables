"""Generate the entire proposed all-winding frontier language, then compare packed key sets."""
from argparse import ArgumentParser
from collections import defaultdict
from functools import cache
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import subprocess


@cache
def words(m):
    if m==0:
        return ("",)
    return tuple("("+a+")"+b for k in range(m) for a in words(k) for b in words(m-1-k))


def plane_tree(word):
    neighbours=[[]]; at=0; contour=[0]
    for ch in word:
        if ch=="(":
            child=len(neighbours)
            neighbours.append([at]);neighbours[at].append(child);at=child
        else:
            at=neighbours[at][0]
        contour.append(at)
    eccentricity=[]
    for v in range(len(neighbours)):
        todo=[(v,-1,0)]
        for cur,parent,depth in todo:
            todo.extend((w,cur,depth+1) for w in neighbours[cur] if w!=parent)
        eccentricity.append(max(item[2] for item in todo))
    return contour,eccentricity


def packed(word,gap):
    def shore(outside_first,opening_token):
        mask=1
        for ch in outside_first:
            mask=(mask<<2)|int(ch==opening_token)
        return mask
    a=shore(word[:gap],"(")
    b=shore(word[gap:][::-1],")")
    # The original interleaving places the greater shore in the low lane.
    return max(a,b)|(min(a,b)<<1)


def candidate_layers(stop):
    layers=defaultdict(set)
    for edges in range(stop//2+1):
        for core in words(edges):
            contour,ecc=plane_tree(core)
            wrapped=edges>0 and 0 not in contour[1:-1]
            for gap,v in enumerate(contour):
                if wrapped and 0<gap<2*edges:
                    continue
                cost=2*edges-ecc[v]
                longest=max(gap,2*edges-gap)
                for q in range(stop-cost-longest+1):
                    key=packed("("*q+core+")"*q,gap+q)
                    for r in range(longest+q,stop-cost+1,2):
                        for n in range(max(1,r+cost),stop+1):
                            layers[n,n-r].add(key)
    return layers


def main():
    cli=ArgumentParser(description=__doc__)
    for name in ("source","alias","csc","out"):
        cli.add_argument("--"+name,type=Path,required=True)
    cli.add_argument("--through",type=int,default=18)
    a=cli.parse_args()
    if not __debug__ or not 1<=a.through<=21:
        cli.error("use assertions and an order through 21")
    src=Path(__file__).with_name("ExactStates.cs")
    with TemporaryDirectory() as tmp:
        exe=Path(tmp)/"ExactStates.exe"
        subprocess.run([str(a.csc),"/nologo","/optimize+","/r:System.Numerics.dll",
                        "/main:Application.ExactStates","/out:"+str(exe),
                        str(a.source),str(a.alias),str(src)],check=True)
        actual=subprocess.check_output([str(exe),str(a.through)],text=True)
    sets=candidate_layers(a.through)
    rows=[]
    for line in actual.splitlines():
        ns,ts,keys=line.split()
        n,t=int(ns),int(ts)
        observed=set(map(int,keys.split(",")))
        predicted=sets.pop((n,t))
        if predicted!=observed:
            raise AssertionError((n,t,sorted(predicted-observed)[:5],sorted(observed-predicted)[:5]))
        digest=sha256(b"".join(k.to_bytes(8,"little") for k in sorted(observed))).hexdigest()
        rows.append(dict(n=n,t=t,keys=len(observed),little_endian_u64_sha256=digest))
    assert not sets and len(rows)==sum(n+1 for n in range(1,a.through+1))
    out=dict(through=a.through,total_compared_keys=sum(r["keys"] for r in rows),
             compared_layers=len(rows),criterion="both shore budgets and parities; t >= 2m - ecc(V) after canonical stripping",
             source_url="https://oeis.org/A005316/a005316.cs.txt",
             sha256={p.name:sha256(p.read_bytes()).hexdigest() for p in (a.source,a.alias,a.csc,src)},
             layers=rows)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(out,indent=2)+"\n",encoding="utf8")
    print(out["through"],out["total_compared_keys"],out["compared_layers"])


if __name__=="__main__":
    main()
