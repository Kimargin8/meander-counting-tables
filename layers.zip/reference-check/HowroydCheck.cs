// Application driver for A. Howroyd's unmodified 2015 transfer, published at
// https://oeis.org/A005316/a005316.cs.txt. Compile together with that file.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;

namespace Application
{
    // The posted file refers once to an old class name in its optional disk
    // partitioner. Forward it to the source author's existing implementation.
    // SimpleProcessor, used below, never enters that partitioner.
    static class MeanderState
    {
        public static int Cluster(BigInteger state, int level)
        {
            return MeanderProblem.Cluster(state, level);
        }
    }

    sealed class SemiPolynomial : SimpleProcessor<Tuple<int, BigInteger>>
    {
        public BigInteger[] Row(int n)
        {
            var states = new MeandersByComponents(n).SemiMeanderInitialStates(null)
                .Select(s => new KeyValuePair<Tuple<int, BigInteger>, BigInteger>(s, BigInteger.One)).ToArray();
            for (int remaining=n-1; remaining>=0; --remaining)
                states = Accumulate(new MeandersByComponents(remaining), states);
            var row = new BigInteger[n+1];
            foreach (var kv in states)
                row[kv.Key.Item1] += kv.Value;
            return row;
        }
    }

    class HowroydCheck
    {
        static void Main(string[] args)
        {
            foreach (string arg in args)
            {
                var counter = new SemiPolynomial();
                var timer = Stopwatch.StartNew();
                var row = counter.Row(Int32.Parse(arg));
                timer.Stop();
                Console.WriteLine("{0}\t{1}\t{2}\t{3}", arg, counter.TotalTransitions,
                    timer.Elapsed.TotalSeconds.ToString("F6", System.Globalization.CultureInfo.InvariantCulture),
                    String.Join(",", row.Select(v => v.ToString()).ToArray()));
            }
        }
    }
}
