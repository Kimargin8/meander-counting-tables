# Parity contraction and finite-window bounds for meandric words

Iaroslav Argunov · Version 1.1.0. [Permanent record](https://doi.org/10.5281/zenodo.24516866).

**Iaroslav Argunov · Computational supplement · Version 1.1.0**

Read [the manuscript](manuscript/stack-bound.pdf) for the mathematical argument. The [LaTeX source](manuscript/stack-bound.tex) contains its bibliography. The original width-16 paper and its first computational supplement are available in [version 1.0.0](https://doi.org/10.5281/zenodo.24457226). This version adds the parity contraction paper and its certificates.

The new substitution recovers the growth rate of acyclic meandric words from the rate of words avoiding two patterns at alternate sites. The paper proves convergence of the parity transfer matrices and an explicit upper bound on their relative error. Widths 1 and 2 have the same growth rate. Each increase from width 2 onward strictly improves the limiting spectral estimate. The quantitative improvement at each width involves the number of connected semi-meanders. This also strengthens the strictness theorem for the older direct transfer.

| Window | Earlier direct upper bound | Parity upper bound |
|---:|---:|---:|
| 14 | 12.680913 | 12.674260 |
| 15 | 12.662732 | 12.657631 |
| 16 | 12.648387 | 12.643867 |

Each value has been rounded upward and bounds the **squared** bidirectional word growth rate. This also bounds the growth of connected plane meanders per pair of crossings. The [earlier direct-window paper](https://doi.org/10.5281/zenodo.24457226) provides the direct comparisons.

At width 16 the exact upper bound is \(73041031823405085/5776795637495884\). The folded calculation has 155,134,453 elementary representatives and 620,537,812 coordinate inequalities. There are four previous letters for each representative. The bounded-weight planar Connected Dominating Set and Steiner Tree exponents in the cited framework improve from 8.216 to 8.215 and from 7.999 to 7.998. The two directional acyclic languages have the same growth rate. The identification of its square with the connected closed-meander growth constant remains open. [Bacher's preprint](https://www-fourier.univ-grenoble-alpes.fr/sites/default/files/ref_478.pdf)

## Reproduce the checks

Use the directory containing this README as your working directory after extraction. Python 3.9 or later and a 64-bit Linux environment with GCC 13.3 or a compatible compiler suffice. The unreflected verifiers use C++17 and unsigned 128-bit multiplication. The folded verifiers use C++20 and OpenMP. All checks run offline using the Python standard library. Binary files are built and discarded in a temporary directory.

~~~sh
python3 -B verify.py hashes
python3 -B verify.py smoke
python3 -B verify.py finite
python3 -B verify.py full
python3 -B verify.py folded15
python3 -B verify.py folded16
~~~

| Command | What it checks |
|---|---|
| hashes | SHA-256 for every archived file except the manifest itself. |
| smoke | Checks both unreflected C++ implementations at width 4 and the reflected generator and independent certificate auditor at width 8. It verifies that the auditor rejects a deliberately tightened bound. |
| finite | Checks the archived width-9 vector, closed pairs through order eight, two finite enumerations of words with rays, the height-weight and row-sum checks for the convergence theorem, and rational bounds for the planar graph consequences. |
| full | Runs the finite tests, reconstructs every width-12 and width-14 inequality independently in both C++ programs, and verifies the separate one-letter calculation. Allow several minutes and at least 4 GiB of working memory on a comparable machine. |
| folded15 | Generates the reflected certificate at width 15, rebuilds all transitions with independent code, and verifies every row including a negative control. Approximately 1 GiB of temporary disk space and 2 GiB of memory were used by the recorded runs. |
| folded16 | Regenerates the largest reflected certificate, audits the 620,537,812 inequalities and checks the negative control. The two temporary witness files occupy about 3.47 GiB. Allow at least 9 GiB free memory and 5 GiB free temporary storage. |

The two programs run sequentially. The first full width-14 run used 3,110,024 KiB of peak resident memory and took 108.01 seconds on one CPU thread. The independent run used 1,638,612 KiB and took 132.62 seconds including the comparison wrapper. These are individual run measurements. The time needed to run the whole suite includes compilation, smaller tests, and the one-letter calculation.

To reproduce just the central integer computations with your own executable names, run the following commands.

~~~sh
g++ -O3 -std=c++17 research/review85/capacity/stack_bound.cpp -o /tmp/slot-bits
g++ -O3 -std=c++17 research/review85/frontier-audit/independent.cpp -o /tmp/path-labels
/tmp/slot-bits 14 130 /tmp/width14-result.json
/tmp/path-labels 14 130
~~~

Both programs should return the same maximum row quotient \(21412399356199/2046505627348\). They generate the proof vector from \(2^{52}\) by 130 rounds with integer division by 11. Every comparison that establishes the bound uses integer arithmetic. The two implementations have different state encodings and independently enumerate the admissible local transitions. The audit was performed within the same research project.

## Contents

- [Bit-mask implementation](research/review85/capacity/stack_bound.cpp) and [width-14 receipt](output/research85/capacity/stack-14.json). The same implementation supports the one-letter calculation.
- [Independent ternary encoding and path labels](research/review85/frontier-audit/independent.cpp) and [width-14 receipt](output/research85/frontier-audit/integer-14.json).
- [Generator using bank exchange](research/review85/graphs/parity_folded.cpp), [independent certificate auditor](research/review85/graphs/parity_verify.cpp), and the [width-15](output/research85/graphs/folded-15.json) and [width-16](output/research85/graphs/folded-16.json) runs. The [full width-16 audit](output/research85/graphs/folded-16-check.json) reports one equality, no violations, and SHA-256 hashes of the elementary catalogue and the vector. Generation took 1,135 seconds and the independent pass took 100 seconds. The helper builds the programs and writes temporary vectors. It also checks that decreasing the claimed numerator by one while keeping the denominator fixed fails.
- [Width-9 checker](research/review85/frontier-audit/independent.py), [integer vector](output/research85/capacity/frontier-w9.json), and [exact checks on closed diagrams](output/research85/frontier-audit/w9.json).
- [Two-bank enumeration](research/review85/capacity/check_words.py) and [independent enumeration by disjoint-set connectivity](research/review85/graphs/acyclic_words.py). The second program checks every word of lengths 1 through 11. At length 11 the 1,823,440 bidirectional acyclic words include 750,712 avoiding the two local configurations.
- [Checks for the hierarchy theorems](research/review85/frontier-audit/check_limit.py) and [finite results](output/research85/frontier-audit/limit.json). These verify every height weight through nine sites, the parity separator on pairs of small words, matrix row-sum estimates through width four, the seven-state product for widths 1 and 2, and the counts of semi-meander witnesses through order ten. They also enumerate errors on every complete pair through order seven and on every even word through length ten. The earlier direct certificates at widths [14](output/research77/window/k14q1f.json), [15](output/research77/window/k15q1f.json) and [16](output/research77/window/k16q1f.json) supply the comparison values.
- [Planar graph exponent calculation](research/review85/graphs/consequences.py) and [exact outward-rounding receipt](output/research85/graphs/consequences-folded-16.json). The bounds use the algorithms and hypotheses of [Caroppo, Da Lozzo, Di Battista and Vihrovs, Theorems 8–12](https://arxiv.org/abs/2610.11944).
- [File hashes](SHA256SUMS). Each line contains a lowercase SHA-256 digest followed by its relative filename.

To typeset a fresh PDF, run pdflatex twice on stack-bound.tex from the manuscript directory with standard LaTeX packages installed (amsmath, amssymb, amsthm, lmodern, booktabs, geometry, hyperref, tikz).
