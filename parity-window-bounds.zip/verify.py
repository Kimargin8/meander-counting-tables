"""Offline verification of the internal reading copy; run with Python 3.9+."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
SOURCES = Path("research/review85")
RECEIPTS = Path("output/research85")


def stored(path):
    return json.loads((ROOT / path).read_bytes())


def require(condition, label):
    if not condition:
        raise ValueError(label)


def integrity():
    manifest = ROOT / "SHA256SUMS"
    observed = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and p != manifest}
    listed = set()
    for line in manifest.read_text(encoding="ascii").splitlines():
        digest, name = line.split("  ", 1)
        require(name in observed and name not in listed, f"Unexpected path {name}")
        require(sha256((ROOT / name).read_bytes()).hexdigest() == digest, f"File changed: {name}")
        listed.add(name)
    require(observed == listed, "Files in the directory differ from its manifest")
    audit = stored(RECEIPTS / "graphs/folded-16-check.json")
    generator = stored(RECEIPTS / "graphs/folded-16.json")
    for key in ("width", "rate_numerator", "rate_denominator"):
        require(audit[key] == generator[key], f"Width-16 audit disagrees on {key}")
    require(audit["checked_rows"] == generator["macro_rows"] == 620537812
            and audit["states"] == generator["elementary_orbits"] == 155134453,
            "Width-16 coverage")
    require(audit["equal_rows"] == 1 and audit["failed_rows"] == 0, "Width-16 inequalities")
    rate = Fraction(audit["rate_numerator"], audit["rate_denominator"])
    require(rate * (rate + 1) / (rate - 1) == Fraction(73041031823405085, 5776795637495884),
            "Theorem 1 fraction")
    for name in ("parity_folded.cpp", "parity_verify.cpp"):
        require(sha256((ROOT / SOURCES / "graphs" / name).read_bytes()).hexdigest()
                == audit["sha256"][name], f"Audited source {name}")
    print(f"Verified {len(listed)} file hashes.", flush=True)


def build(source, binary):
    subprocess.run(["g++", "-std=c++17", "-O3", str(ROOT / source), "-o", str(binary)], check=True)


def read_run(binary, args, json_file=None):
    proc = subprocess.run([str(binary), *map(str, args)], check=True, stdout=subprocess.PIPE)
    return json.loads(json_file.read_bytes() if json_file else proc.stdout)


def width_check(tmp, first, second, width, rounds):
    result = tmp / f"stack-{width}.json"
    a = read_run(first, [width, rounds, result], result)
    b = read_run(second, [width, rounds])
    keys = ["width", "rounds", "states", "rate_numerator", "rate_denominator"]
    require(all(a[k] == b[k] for k in keys), f"Implementations disagree at width {width}")
    require(a["macro_states"] == b["macro_rows"], "Macro-row count mismatch")
    rate = Fraction(a["rate_numerator"], a["rate_denominator"])
    value = rate * (rate + 1) / (rate - 1)
    if width in (12, 14):
        aa = stored(RECEIPTS / "capacity" / result.name)
        bb = stored(RECEIPTS / "frontier-audit" / f"integer-{width}.json")
        require(all(a[k] == aa[k] == bb[k] for k in keys), "Mismatch with frozen run")
        require(a["macro_states"] == aa["macro_states"] == bb["macro_rows"], "Frozen macro count")
        require(str(value) == bb["ordinary_upper"], "Frozen growth fraction")
    if width == 14:
        require(value == Fraction(502311441966835295487457853, 39632410494716914762217148),
                "Width-14 fraction")
    print(f"Width {width}: {a['states']} states, {b['macro_rows']} rows, squared base <= {value}.", flush=True)


def finite_checks(tmp):
    working = tmp / "replica"
    shutil.copytree(ROOT / SOURCES, working / SOURCES)
    shutil.copytree(ROOT / RECEIPTS, working / RECEIPTS)
    shutil.copytree(ROOT / "output/research77", working / "output/research77")
    reader = working / SOURCES
    for script, args in [(reader / "graphs/consequences.py", [working / RECEIPTS / "graphs/folded-16.json"]),
                         (reader / "capacity/check_words.py", []),
                         (reader / "graphs/acyclic_words.py", []),
                         (reader / "frontier-audit/check_limit.py", []),
                         (reader / "frontier-audit/independent.py", [])]:
        subprocess.run([sys.executable, "-B", str(script), *map(str, args)], cwd=working,
                       check=True, stdout=subprocess.DEVNULL)
    for entry in ["graphs/consequences-folded-16.json", "capacity/words.json",
                  "graphs/words.json", "frontier-audit/w9.json", "frontier-audit/limit.json"]:
        regenerated = json.loads((working / RECEIPTS / entry).read_bytes())
        frozen = stored(RECEIPTS / entry)
        if entry.endswith("/w9.json"):
            regenerated.pop("python")
            frozen.pop("python")
        require(regenerated == frozen, f"Finite check {entry}")
    print("Finite word counts, width-9 vector, and planar graph consequences reproduced.", flush=True)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("hashes", "smoke", "finite", "full", "folded15", "folded16"))
    mode = parser.parse_args().mode
    integrity()
    if mode == "hashes":
        return
    with tempfile.TemporaryDirectory(prefix="meander-review-") as directory:
        tmp = Path(directory)
        if mode in ("finite", "full"):
            finite_checks(tmp)
        if mode == "finite":
            return
        if mode in ("smoke", "folded15", "folded16"):
            width = {"smoke": 8, "folded15": 15, "folded16": 16}[mode]
            subprocess.run([sys.executable, "-B", str(ROOT / SOURCES / "graphs/replay_folded.py"),
                            "--width", str(width), "--negative-control"], check=True)
            if mode != "smoke":
                return
        primary = tmp / "slot-bits"
        independent = tmp / "path-labels"
        build(SOURCES / "capacity/stack_bound.cpp", primary)
        build(SOURCES / "frontier-audit/independent.cpp", independent)
        widths = [(4, 10)] if mode == "smoke" else [(12, 110), (14, 130)]
        for w, rounds in widths:
            width_check(tmp, primary, independent, w, rounds)
        if mode == "full":
            plain = tmp / "plain-14.json"
            got = read_run(primary, [14, 130, plain, "--plain"], plain)
            require(got == stored(RECEIPTS / "capacity/plain-14.json"), "One-letter width-14 bound")
            print("One-letter bound reproduced.", flush=True)


if __name__ == "__main__":
    main()
