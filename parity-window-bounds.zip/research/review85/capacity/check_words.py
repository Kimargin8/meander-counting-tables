"""Literal bracket matchings and components for the two parity-contraction series."""
from hashlib import sha256
from pathlib import Path
import json
OUT = Path(__file__).resolve().parents[3]/'output'/'research85'/'capacity'


def banks(size):
    for bits in range(1<<size):
        stack=[]
        mates=[-1]*size
        left_rays=0
        for i in range(size):
            if bits>>i & 1:
                stack.append(i)
            elif stack:
                j=stack.pop()
                mates[i]=j
                mates[j]=i
            else:
                left_rays+=1
        left=sum(1<<i for i in range(1,size-1,2) if mates[i]==i-1)
        right=sum(1<<i for i in range(1,size-1,2) if mates[i]==i+1)
        yield mates,left_rays,left,right


def acyclic(a,b):
    # Every component has maximum degree two. All vertices must lie on paths
    # starting at a ray, counting parallel arcs as distinct edges.
    size=len(a)
    seen=0
    for i in range(size):
        if seen>>i&1 or (a[i]>=0 and b[i]>=0):
            continue
        v=i
        step=int(a[v]<0)
        while v>=0 and not seen>>v&1:
            seen|=1<<v
            v=(b if step else a)[v]
            step=1-step
    return seen==(1<<size)-1


def polynomial_product(p,q,size):
    return [sum(p[i]*q[n-i] for i in range(n+1)) for n in range(size)]


def contraction(series):
    length=len(series)
    h=[1]+[2*(-1)**n for n in range(1,length)]
    f=[0]+h[:-1]
    mult=h
    dest=[0]*length
    for number in series:
        dest=[x+number*y for x,y in zip(dest,mult)]
        mult=polynomial_product(mult,f,length)
    return dest


def main():
    table=[]
    for n in range(5):
        size=2*n+1
        catalog=list(banks(size))
        total=clean=right_only=right_clean=0
        for a,ra,la,ha in catalog:
            for b,rb,lb,hb in catalog:
                if not acyclic(a,b):
                    continue
                good=not (la&hb or ha&lb)
                total+=1; clean+=good
                if ra==rb==0:
                    right_only+=1;right_clean+=good
        table.append(dict(sites=size,all_acyclic=total,avoid=clean,right_only=right_only,
                          right_avoid=right_clean))
    for original,avoiding in [('all_acyclic','avoid'),('right_only','right_avoid')]:
        assert contraction([r[original] for r in table])==[r[avoiding] for r in table]
    result={'tested_words':sum(4**r['sites'] for r in table),'rows':table,
            'sha256':sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT/'words.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(result['tested_words'],table)


if __name__=='__main__':main()
