// Exact deterministic certificate for the parity-avoiding meander relaxation.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

using Word = std::uint64_t;
using Wide = unsigned __int128;
using Row = std::array<int,4>;
using Values = std::array<Word,4>;

struct Diagram {
    std::vector<Word> encodings{0};
    std::vector<Row> moves;
    std::unordered_map<Word,int> lookup{{0,0}};
    const int w;
    const int length;
    const Word mask;
    explicit Diagram(int width) : w(width),length(2*w),mask((Word(1)<<length)-1) {}

    void build() {
        for (size_t i=0;i<encodings.size();++i) {
            Word state=encodings[i],starts=state&mask,ends=state>>length;
            std::array<int,32> stack{},partner;
            partner.fill(-1);
            int depth=0;
            for (int a=0;a<length;++a) {
                if (starts&(Word(1)<<a)) stack[depth++]=a;
                if (ends&(Word(1)<<a)) {
                    if (!depth) throw std::logic_error("unbalanced arc");
                    int b=stack[--depth]; partner[a]=b; partner[b]=a;
                }
            }
            if(depth) throw std::logic_error("unbalanced state");
            Row row;
            for (int sign=0;sign<4;++sign) {
                if (sign==0 && partner[w-1]==w) {row[sign]=-1;continue;}
                auto translate=[&](int a) {
                    if(a<0) return -1;
                    int bank=(a>=w);
                    int delta=(sign&(1<<bank)) ? 1 : -1;
                    int b=a+(bank ? delta : -delta);
                    return b>=bank*w && b<(bank+1)*w ? b : -1;
                };
                Word new_starts=0,new_ends=0;
                auto pair=[&](int a,int b) {
                    if(a<0 || b<0) return;
                    new_starts|=Word(1)<<std::min(a,b);
                    new_ends|=Word(1)<<std::max(a,b);
                };
                for (int a=0;a<length;++a) if (partner[a]>a)
                    pair(translate(a),translate(partner[a]));
                pair(sign&1 ? w-1 : translate(partner[w-1]),
                     sign&2 ? w   : translate(partner[w]));
                Word target=new_starts|(new_ends<<length);
                auto entry=lookup.emplace(target,int(encodings.size()));
                row[sign]=entry.first->second;
                if (entry.second) encodings.push_back(target);
            }
            moves.push_back(row);
        }
        lookup.clear(); lookup.rehash(0);
    }
};

void multiply(const std::vector<Row>& moves,const std::vector<Values>& vec,
              std::vector<Values>& tmp,std::vector<Values>& out) {
    for (size_t i=0;i<moves.size();++i) {
        Values a;
        for(int e=0;e<4;++e) a[e]=moves[i][e]<0 ? 0 : vec[moves[i][e]][e];
        tmp[i]={a[0]+a[1]+a[2]+a[3],a[0]+a[2],a[0]+a[1],a[0]};
    }
    for (size_t i=0;i<moves.size();++i) {
        Word sum=0; Values disallowed{};
        for (int o=0;o<4;++o) if(moves[i][o]>=0) {
            const auto& x=tmp[moves[i][o]];
            sum+=x[0]; disallowed[o]=x[o];
        }
        Word a=sum-disallowed[3];
        out[i]={a,a-disallowed[2],a-disallowed[1],
                a-disallowed[0]-disallowed[1]-disallowed[2]};
    }
}

int main(int argc,char**argv) {
    if (argc<4) return 2;
    const int w=std::stoi(argv[1]),rounds=std::stoi(argv[2]);
    if (w<1||w>15||rounds<1) return 2;
    auto start=std::chrono::steady_clock::now();
    Diagram model(w); model.build();
    size_t count=model.moves.size();
    std::cerr<<"width "<<w<<", elementary states "<<count<<"\n";
    if (argc>4 && std::string(argv[4])=="--plain") {
        std::vector<Word> vec(count,Word(1)<<52),out(count);
        Word bound=Word(1)<<52;
        for(int i=0;i<=rounds;++i) {
            if(bound>std::numeric_limits<Word>::max()/8) throw std::overflow_error("plain row bound");
            for(size_t j=0;j<count;++j) {
                out[j]=0;
                for(int dest:model.moves[j]) if(dest>=0) out[j]+=vec[dest];
            }
            if(i==rounds) break;
            bound=0;
            for(size_t j=0;j<count;++j) {
                vec[j]=std::max(Word(1),(2*out[j])/7);
                bound=std::max(bound,vec[j]);
            }
        }
        Word num=0,den=1;
        for (size_t j=0;j<count;++j) if(Wide(out[j])*den>Wide(num)*vec[j]) {
            num=out[j];den=vec[j];
        }
        Word g=std::gcd(num,den); num/=g;den/=g;
        for(size_t j=0;j<count;++j) if(Wide(out[j])*den>Wide(num)*vec[j])
            throw std::logic_error("plain certificate");
        std::ofstream file(argv[3]);
        file<<"{\"width\":"<<w<<",\"rounds\":"<<rounds<<",\"states\":"<<count
            <<",\"per_crossing_numerator\":"<<num<<",\"per_crossing_denominator\":"<<den<<"}\n";
        long double r=(long double)num/den;
        std::cerr.precision(16); std::cerr<<"plain "<<r<<", mu "<<r*r<<"\n";
        return 0;
    }
    std::vector<Values> vec(count),tmp(count),out(count);
    const Word initial=Word(1)<<52;
    std::fill(vec.begin(),vec.end(),Values{initial,initial,initial,initial});
    Word maxv=initial;
    for(int i=0;i<=rounds;++i) {
        if(maxv>std::numeric_limits<Word>::max()/16) throw std::overflow_error("row bound");
        multiply(model.moves,vec,tmp,out);
        if(i==rounds) break;
        maxv=0;
        for(size_t j=0;j<count;++j) for(int p=0;p<4;++p) {
            Word v=std::max(Word(1),out[j][p]/11);
            vec[j][p]=v; maxv=std::max(maxv,v);
        }
    }
    Word num=0,den=1;
    size_t witness=0; int prev=0;
    for (size_t i=0;i<count;++i) for (int p=0;p<4;++p)
        if(Wide(out[i][p])*den>Wide(num)*vec[i][p]) {
            num=out[i][p];den=vec[i][p];witness=i;prev=p;
        }
    Word g=std::gcd(num,den); num/=g;den/=g;
    for (size_t i=0;i<count;++i) for(int p=0;p<4;++p)
        if(Wide(out[i][p])*den>Wide(num)*vec[i][p]) throw std::logic_error("certificate");
    if(argc>4) {
        std::ofstream binary(argv[4],std::ios::binary);
        for(size_t i=0;i<count;++i) {
            binary.write(reinterpret_cast<const char*>(&model.encodings[i]),sizeof(Word));
            binary.write(reinterpret_cast<const char*>(vec[i].data()),4*sizeof(Word));
        }
    }
    const auto seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::ofstream file(argv[3]);
    file<<"{\n  \"width\": "<<w<<",\n  \"rounds\": "<<rounds<<",\n  \"states\": "<<count
        <<",\n  \"macro_states\": "<<4*count<<",\n  \"initial\": "<<initial<<",\n  \"divisor\": 11,"
        <<"\n  \"rate_numerator\": "<<num<<",\n  \"rate_denominator\": "<<den
        <<",\n  \"witness_encoding\": "<<model.encodings[witness]<<",\n  \"witness_previous_even\": "<<prev
        <<",\n  \"seconds\": "<<seconds<<"\n}\n";
    long double r=(long double)num/den;
    std::cerr.precision(16); std::cerr<<"r "<<r<<", mu "<<r*(r+1)/(r-1)<<", "<<seconds<<" seconds\n";
}
