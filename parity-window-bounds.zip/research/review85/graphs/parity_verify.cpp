// Independent finite certificate. Uses path labels and an immutable catalogue.
// The transition code does not import the generator or its hash table.
#define main stage77_weighted_verifier
#ifdef _MSC_VER
// Only the unused single-step entry point in the shared source uses this alias.
#define __uint128_t unsigned long long
#endif
#include "../../review77/window/audit.cpp"
#ifdef _MSC_VER
#undef __uint128_t
#endif
#undef main
#include <numeric>

using Values=std::array<std::uint32_t,4>;
using Moves=std::array<std::uint32_t,4>;
constexpr std::array<int,4> exchange{0,2,1,3};

std::vector<Values> read_values(const std::string& filename,size_t states) {
    std::ifstream in(filename,std::ios::binary|std::ios::ate);
    if(!in || in.tellg()!=std::streamoff(states*sizeof(Values)))
        throw std::runtime_error("vector length");
    std::vector<Values> v(states);
    in.seekg(0);
    in.read(reinterpret_cast<char*>(v.data()),states*sizeof(Values));
    if(!in) throw std::runtime_error("vector read");
    for(const auto& row:v) for(auto x:row)
        if(!x) throw std::runtime_error("nonpositive vector");
    return v;
}

std::vector<Moves> successors(const std::vector<U>& words,const std::vector<Values>& v,int k) {
    const int m=2*k;
    const size_t n=words.size();
    Catalogue lookup(words);
    std::vector<Moves> result(n);
    #pragma omp parallel for schedule(static)
    for(std::int64_t i=0;i<static_cast<std::int64_t>(n);++i) {
        auto base=decode(words[i],m);
        auto rev=base;
        std::reverse(rev.begin()+1,rev.begin()+m+1);
        auto reversed=encode(rev,1,m);
        if(reversed<words[i] || (reversed==words[i] && v[i][1]!=v[i][2]))
            throw std::logic_error("invalid symmetry quotient");
        for(int e=0;e<4;++e) {
            auto labels=base;
            int first=0;
            if(e==3) {
                std::move_backward(labels.begin()+k+1,labels.begin()+m+2,labels.begin()+m+4);
                labels[k+1]=labels[k+2]=m+3;
                first=2;
            } else if(e==1) {
                first=2;
            } else if(e==0) {
                int a=labels[k],b=labels[k+1];
                if(a==b) { result[i][e]=2*n; continue; }
                for(int j=0;j<m+2;++j) if(labels[j]==b) labels[j]=a;
                std::move(labels.begin()+k+2,labels.begin()+m+2,labels.begin()+k);
            }
            U next=encode(labels,first,m);
            std::reverse(labels.begin()+first,labels.begin()+first+m);
            const U opposite=encode(labels,first,m);
            result[i][e]=2*lookup.at(std::min(next,opposite))+(opposite<next);
        }
    }
    return result;
}

int main(int argc,char** argv) {
    if(argc!=5) return 2;
    const std::string prefix=argv[1];
    const int k=std::stoi(argv[2]);
    const U numerator=std::stoull(argv[3]),denominator=std::stoull(argv[4]);
    if(!numerator||!denominator||k<1||k>16) return 2;
    auto words=read(prefix+".states");
    const size_t n=words.size();
    if(words[0]!=0 || n>=UINT32_MAX/2) throw std::runtime_error("invalid catalogue");
    auto v=read_values(prefix+".vector",n);
    U top=0;
    for(const auto& row:v) for(auto x:row) top=std::max<U>(top,x);
    if(top>UINT64_MAX/16/denominator || top>UINT64_MAX/numerator)
        throw std::overflow_error("comparison requires larger integers");
    const auto graph=successors(words,v,k);
    std::vector<U>().swap(words);
    bool allowed[4][4][4]{};
    for(int p=0;p<4;++p) for(int b=0;b<4;++b) for(int e=0;e<4;++e) {
        int peaks=0;
        for(int bank: {1,2}) if(((p&bank)&&!(b&bank))||((b&bank)&&!(e&bank))) ++peaks;
        allowed[p][b][e]=peaks<2;
    }
    U equal=0,fail=0;
    #pragma omp parallel for schedule(static) reduction(+:equal,fail)
    for(std::int64_t i=0;i<static_cast<std::int64_t>(n);++i) {
        std::array<U,4> sums{};
        for(int b=0;b<4;++b) {
            const auto mid=graph[i][b];
            if(mid/2==n) continue;
            for(int e=0;e<4;++e) {
                const int second=mid&1?exchange[e]:e;
                const auto dest=graph[mid/2][second];
                if(dest/2==n) continue;
                const auto value=v[dest/2][dest&1?exchange[second]:second];
                for(int p=0;p<4;++p) if(allowed[p][b][e]) sums[p]+=value;
            }
        }
        for(int p=0;p<4;++p) {
            const U left=sums[p]*denominator,right=U(v[i][p])*numerator;
            fail+=(left>right);
            equal+=(left==right);
        }
    }
    if(fail||!equal) throw std::runtime_error("claimed maximum failed");
    std::cout<<"{\"width\":"<<k<<",\"states\":"<<n<<",\"checked_rows\":"<<4*n
             <<",\"equal_rows\":"<<equal<<",\"failed_rows\":"<<fail
             <<",\"rate_numerator\":"<<numerator<<",\"rate_denominator\":"<<denominator<<"}\n";
}
