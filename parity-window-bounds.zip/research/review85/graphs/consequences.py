"""Upward rounding for Theorems 8--10 of Caroppo et al., arXiv:2610.11944v1."""
from fractions import Fraction as F
from hashlib import sha256
from functools import cache
from math import isqrt,log2,ceil
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[3]


def strict_sqrt(value,den=10**7):
    return F(isqrt(value.numerator*den**2//value.denominator)+1,den)


@cache
def log_upper(x,scale=100000):
    # Floating point seeds the integer search. Its stopping condition uses
    # only integers and proves x < 2^(k/scale).
    k=ceil(scale*log2(float(x)))
    left,right=x.numerator**scale,x.denominator**scale
    while left>=right<<k:
        k+=1
    return F(k,scale)


def ceiling_bound(c1,c2,matrix):
    branch=F(2121321,10**6)
    assert branch**2>F(9,2)
    first=F(343,500) if matrix else F(1)
    boundary=log_upper(c2)
    gamma=branch*max(first*log_upper(F(c1))+boundary/2,boundary)
    return f"{ceil(1000*gamma)/1000:.3f}"


def main():
    path=Path(sys.argv[1])
    source=json.loads(path.read_bytes())
    rate=F(source['rate_numerator'],source['rate_denominator'])
    value=rate*(rate+1)/(rate-1)
    z=strict_sqrt(value)
    assert value<z*z
    bounds={}
    for label,c1,c2 in [('Hamiltonian_cycle_and_TSP',4,2+z),('longest_cycle_or_path',4,3+z),
                        ('connected_dominating_set',6,2+value),('Steiner_tree',5,1+value)]:
        bounds[label]={}
        for name,matrix in [('bounded_weights',True),('unbounded_weights',False)]:
            bounds[label][name]=ceiling_bound(c1,c2,matrix)
    data=dict(source="https://arxiv.org/html/2610.11944v1",theorems=[8,9,10,11,12],
              matrix_multiplication_exponent="2.372",branchwidth_factor="2.121321",
              upper_bound_for_squared_word_base=str(value),z_strict_upper=str(z),exponents=bounds,certificate_file=path.name,
              certificate_hash=sha256(path.read_bytes()).hexdigest(),code_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
    out=ROOT/'output/research85/graphs'/('consequences-'+path.stem+'.json')
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,indent=2)+'\n')
    print(data['exponents'])


if __name__=='__main__':
    main()
