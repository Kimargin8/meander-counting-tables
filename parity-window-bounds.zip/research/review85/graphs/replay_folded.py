"""Recreate a reflected parity certificate in temporary storage and check every row."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'output/research85/graphs'


def run(width,threads,negative):
    saved=json.loads((OUT/f'folded-{width}.json').read_bytes())
    with tempfile.TemporaryDirectory(prefix='meander-parity-') as stage:
        build=Path(stage)
        gen,check=build/'generate',build/'check'
        flags=['-O3','-std=c++20','-fopenmp']
        env=dict(os.environ,OMP_NUM_THREADS=str(threads))
        for source,exe in [('parity_folded.cpp',gen),('parity_verify.cpp',check)]:
            subprocess.run(['g++',*flags,str(HERE/source),'-o',str(exe)],check=True)
        prefix=build/'witness'
        receipt=build/'generated.json'
        subprocess.run([gen,str(width),str(saved['rounds']),receipt,prefix],env=env,check=True,cwd=build)
        got=json.loads(receipt.read_bytes())
        for field in ['width','rounds','elementary_orbits','macro_rows','rate_numerator','rate_denominator']:
            if got[field]!=saved[field]:
                raise ValueError(f'generator disagreement on {field}')
        num,den=got['rate_numerator'],got['rate_denominator']
        audit_command=[check,prefix,str(width),str(num),str(den)]
        verified=json.loads(subprocess.check_output(audit_command,env=env,cwd=build,text=True))
        if verified['failed_rows'] or verified['checked_rows']!=got['macro_rows'] or not verified['equal_rows']:
            raise ValueError('full inequality check')
        if negative:
            tighter=[*audit_command[:-2],str(num-1),str(den)]
            result=subprocess.run(tighter,env=env,cwd=build,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            if not result.returncode:
                raise ValueError('the impossible tighter maximum was accepted')
        r=Fraction(num,den)
        print('Certified upper bound',r*(r+1)/(r-1))
        return dict(checked=verified,negative_control=negative,source_sha256={
            p.name:sha256(p.read_bytes()).hexdigest() for p in
            [HERE/'parity_folded.cpp',HERE/'parity_verify.cpp',ROOT/'research/review77/window/certify.cpp',
             ROOT/'research/review77/window/audit.cpp']})


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--width',type=int,default=8,choices=[8,15,16])
    parser.add_argument('--threads',type=int,default=2)
    parser.add_argument('--negative-control',action='store_true')
    args=parser.parse_args()
    if args.threads<1: parser.error('threads must be positive')
    print(json.dumps(run(args.width,args.threads,args.negative_control),indent=2))
