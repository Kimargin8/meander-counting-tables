// Quotient the parity-sensitive two-step operator by reflection in the river.
// The elementary window, its word encoding and its hash index are from stage 77.
#define WINDOW_GRAPH_ONLY
#ifdef _MSC_VER
#include <cstdlib>
// The imported graph-only code never uses its Wide alias.
#define __uint128_t unsigned long long
#define __builtin_bswap64 _byteswap_uint64
#endif
#include "../../review77/window/certify.cpp"
#ifdef _MSC_VER
#undef __uint128_t
#undef __builtin_bswap64
#endif
#include <numeric>

using Values = std::array<std::uint32_t, 4>;
constexpr std::array<int,4> reflected_letter{0,2,1,3};

struct ParityGraph {
    std::vector<Row> edges;

    ParityGraph(int k,const std::string& prefix) {
        const int width=2*k;
        std::vector<Word> keys{0};
        StateIndex address(keys);
        if(k>=14) {
            const size_t hint=k==14?10500000:(k==15?41000000:156000000);
            keys.reserve(hint);
            edges.reserve(hint);
        }
        for(size_t source=0;source<keys.size();++source) {
            int depth=0;
            std::array<int,32> stack{},mate{};
            mate.fill(-1);
            for(int i=0;i<width;++i) {
                const unsigned digit=(keys[source]>>(2*i))&3;
                if(digit==1) stack[depth++]=i;
                if(digit==2) {
                    if(!depth) throw std::logic_error("unbalanced close");
                    const int j=stack[--depth];
                    mate[j]=i;
                    mate[i]=j;
                }
            }
            if(depth) throw std::logic_error("unbalanced open");
            Row row{};
            for(int e=0;e<4;++e) {
                const int op=3-e;
                if(op==3 && mate[k-1]==k) { row[e]=none; continue; }
                auto relocate=[&](int i) {
                    if(op==1) return i+1;
                    if(op==2) return i-1;
                    if(op==0) return i+(i<k?-1:1);
                    return i==k-1||i==k?-1:i+(i<k?1:-1);
                };
                Word next=0;
                auto arc=[&](int a,int b) {
                    if(a>b) std::swap(a,b);
                    if(a>=0 && b<width) next|=(Word(1)<<(2*a))|(Word(2)<<(2*b));
                };
                for(int i=0;i<width;++i) if(mate[i]>i)
                    arc(relocate(i),relocate(mate[i]));
                if(op==0) arc(k-1,k);
                if(op==3 && mate[k-1]>=0 && mate[k]>=0)
                    arc(relocate(mate[k-1]),relocate(mate[k]));
                const Word mirror=reflect(next,width);
                const bool flipped=mirror<next;
                const Word key=std::min(mirror,next);
                auto [id,added]=address.find_or_add(key);
                if(added) keys.push_back(key);
                if(id>=none/2) throw std::overflow_error("address");
                row[e]=2*id+flipped;
            }
            edges.push_back(row);
        }
        // A missing edge points to a permanent zero row. Its mirror bit is zero.
        for(auto &row:edges) if(row[0]==none) row[0]=static_cast<Index>(2*edges.size());
        if(!prefix.empty()) dump(prefix+".states",keys);
    }
};

int main(int argc,char** argv) {
    if(argc!=4 && argc!=5) return 2;
    const int k=std::stoi(argv[1]),rounds=std::stoi(argv[2]);
    if(k<1 || k>16 || rounds<1 || rounds>1000) return 2;
    auto start=std::chrono::steady_clock::now();
    const std::string prefix=argc==5?argv[4]:"";
    ParityGraph g(k,prefix);
    const size_t n=g.edges.size();
    std::cerr<<"folded elementary states "<<n<<std::endl;
    constexpr std::uint32_t unit=1u<<25;
    std::vector<Values> v(n+1,Values{unit,unit,unit,unit}),partial(n+1);
    v[n]={};
    std::uint32_t maximum=unit;
    Word numerator=0,denominator=1;
    for(int t=0;t<=rounds;++t) {
        if(maximum>UINT32_MAX/16) throw std::overflow_error("two-step row sum");
        #pragma omp parallel for schedule(static)
        for(std::int64_t i=0;i<static_cast<std::int64_t>(n);++i) {
            Values r{};
            for(int e=0;e<4;++e) {
                const Index target=g.edges[i][e];
                r[e]=v[target/2][target&1?reflected_letter[e]:e];
            }
            partial[i]={r[0]+r[1]+r[2]+r[3],r[0]+r[2],r[0]+r[1],r[0]};
        }
        const int shift=maximum>unit?4:3;
        maximum=0;
        #pragma omp parallel
        {
            Word local_num=0,local_den=1;
            std::uint32_t local_max=0;
            #pragma omp for schedule(static)
            for(std::int64_t i=0;i<static_cast<std::int64_t>(n);++i) {
                std::uint32_t total=0;
                Values bad{};
                for(int b=0;b<4;++b) {
                    const Index target=g.edges[i][b];
                    const auto &terms=partial[target/2];
                    total+=terms[0];
                    bad[b]=terms[target&1?reflected_letter[b]:b];
                }
                const auto a=total-bad[3];
                const Values sums{a,a-bad[2],a-bad[1],a-bad[0]-bad[1]-bad[2]};
                for(int p=0;p<4;++p) {
                    if(t==rounds) {
                        if(Word(sums[p])*local_den>local_num*v[i][p]) {
                            local_num=sums[p];
                            local_den=v[i][p];
                        }
                    } else {
                        v[i][p]=std::max(1u,sums[p]>>shift);
                        local_max=std::max(local_max,v[i][p]);
                    }
                }
            }
            #pragma omp critical
            {
                maximum=std::max(maximum,local_max);
                if(local_num*denominator>numerator*local_den) {
                    numerator=local_num;
                    denominator=local_den;
                }
            }
        }
        if((t+1)%40==0) std::cerr<<"round "<<t+1<<std::endl;
    }
    const Word divisor=std::gcd(numerator,denominator);
    numerator/=divisor; denominator/=divisor;
    if(!prefix.empty()) {
        v.pop_back();
        dump(prefix+".vector",v);
    }
    const auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::ofstream output(argv[3]);
    output<<"{\"width\":"<<k<<",\"rounds\":"<<rounds<<",\"elementary_orbits\":"<<n
          <<",\"macro_rows\":"<<4*n<<",\"rate_numerator\":"<<numerator
          <<",\"rate_denominator\":"<<denominator<<",\"seconds\":"<<elapsed<<"}\n";
    if(!output) throw std::runtime_error("write");
}
