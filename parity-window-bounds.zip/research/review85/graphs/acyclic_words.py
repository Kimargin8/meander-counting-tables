"""Check snake contraction on acyclic two-bank words with rightward free ends."""
from hashlib import sha256
from itertools import product
from math import comb
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[3]


def physical(word,rightward):
    n=len(word)
    stacks=[[],[]]
    parent=list(range(n))
    def root(v):
        while parent[v]!=v:
            v=parent[v]
        return v
    for i,letter in enumerate(word):
        for side in (0,1):
            if letter&(1<<side):
                stacks[side].append(i)
                continue
            if not stacks[side]:
                if rightward:
                    return False
                continue
            a,b=root(stacks[side].pop()),root(i)
            if a==b:
                return False
            parent[a]=b
    return True


def avoiding(word):
    for i in range(1,len(word)-1,2):
        if (((word[i-1]&~word[i])|(word[i]&~word[i+1]))&3)==3:
            return False
    return True


def direct(m):
    counts=[[0,0],[0,0]]
    for w in product(range(4),repeat=m):
        if not physical(w,False):
            continue
        clean=int(avoiding(w))
        counts[0][0]+=1
        counts[0][1]+=clean
        if w[0]==3 and physical(w,True):
            counts[1][0]+=1
            counts[1][1]+=clean
    return counts


def main():
    literal={m:direct(m) for m in [1,2,3,4,5,6,7,8,9,10,11]}
    for case in range(2):
        for n in range(6):
            terms=literal[2*n+1][case][0]
            for j in range(1,n+1):
                marked=sum(comb(j-1,b-1)*comb(n-j+1,b)*2**b for b in range(1,min(j,n-j+1)+1))
                terms+=(-1)**j*marked*literal[2*(n-j)+1][case][0]
            assert terms==literal[2*n+1][case][1]
            if n:
                assert literal[2*n][case][0]<=literal[2*n+1][case][0]
    out=ROOT/'output/research85/graphs/words.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(dict(literal=literal,classes=['bidirectional','rightward'],
                   code_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
    print(literal)


if __name__=='__main__':
    main()
