"""Finite checks for height weights, parity separators, and the row-sum estimate."""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE.parent / "graphs"))
from acyclic_words import avoiding, physical
from independent import advance, automaton, bank, no_double_peak, words


def normalized(word):
    converted = list(word)
    final_heights = []
    for flag in [1, 2]:
        stack = []
        for i, letter in enumerate(word):
            if letter & flag:
                stack.append(i)
            elif stack:
                stack.pop()
            else:
                converted[i] |= flag
        final_heights.append(sum(1 if letter & flag else -1 for letter in converted))
    return tuple(converted), (1 + final_heights[0]) * (1 + final_heights[1])


def compare_fibres(sites):
    fibres = Counter()
    weights = {}
    right = set()
    for word in product(range(4), repeat=sites):
        if not (physical(word, False) and avoiding(word)):
            continue
        image, weight = normalized(word)
        assert physical(image, True) and avoiding(image)
        fibres[image] += 1
        weights[image] = weight
        if word == image:
            right.add(word)
    assert set(fibres) == right and fibres == weights
    return right, sum(fibres.values())


def walks(width, macros):
    arrows = automaton(width)
    values = [[1] * 4 for _ in arrows]
    for _ in range(macros):
        dest = []
        for row in arrows:
            totals = []
            for a in range(4):
                total = 0
                for b, i in enumerate(row):
                    if i >= 0:
                        total += sum(values[j][c] for c, j in enumerate(arrows[i])
                                     if j >= 0 and no_double_peak(a, b, c))
                totals.append(total)
            dest.append(totals)
        values = dest
    return max(map(max, values))


def next_pair(graph, state, odd, even):
    i = graph[state][odd]
    return graph[i][even] if i >= 0 else -1


def initial_widths():
    narrow, wide = automaton(1), automaton(2)
    product_states = [(0, 0, 0)]
    rows = []
    for small, large, p in product_states:
        row = []
        for odd, even in product(range(4), repeat=2):
            if not no_double_peak(p, odd, even):
                row.append(-1)
                continue
            i = next_pair(narrow, small, odd, even)
            j = next_pair(wide, large, odd, even)
            assert (i < 0) == (j < 0)
            if i < 0:
                row.append(-1)
                continue
            new = (i, j, even)
            if new not in product_states:
                product_states.append(new)
            row.append(product_states.index(new))
        rows.append(row)
    weighted = []
    for idx, (_, _, p) in enumerate(product_states):
        counts = [0] * 3
        for dest in rows[idx]:
            if dest >= 0:
                e = product_states[dest][2]
                counts[0 if e == 0 else 2 if e == 3 else 1] += 1
        expected = [[3, 8, 4], [2, 7, 4], [0, 4, 3]][0 if p == 0 else 2 if p == 3 else 1]
        assert counts == expected
        weighted.append(counts)
    assert len(rows) == 7 and sum(dest >= 0 for row in rows for dest in row) == 81
    return dict(states=product_states, transitions=rows, quotient_rows=weighted)


def strict_witness(width):
    a = width + 1
    top = [i < a for i in range(2 * a)]
    lower = [i == 0 or 2 <= i <= a for i in range(2 * a)]
    rainbow = [int(u) + 2 * int(l) for u, l in zip(top, lower)]
    reflected = (a % 2 == 0)
    test = [3 - letter for letter in reversed(rainbow)] if reflected else rainbow
    reset = [1] * (2 * width + 1) + [0]

    def apply(g, state, prev, word):
        for odd, even in zip(word[::2], word[1::2]):
            if not no_double_peak(prev, odd, even):
                return -1
            state = next_pair(g, state, odd, even)
            if state < 0:
                return -1
            prev = even
        return state

    small, large = automaton(width), automaton(width + 1)
    assert all(apply(small, i, p, reset) == 0 for i in range(len(small)) for p in range(4))
    assert all(apply(small, i, p, test) == 0 for i in range(len(small)) for p in range(4))
    assert all(apply(large, i, p, test) < 0 for i in range(len(large)) for p in range(4))
    assert test[0] == 3 and test[-1] == 0 and len(test) // 2 == width + 1
    swapped = [((l & 1) << 1) + (l >> 1) for l in test]
    assert swapped != test
    assert all(apply(small, i, p, swapped) == 0 for i in range(len(small)) for p in range(4))
    assert all(apply(large, i, p, swapped) < 0 for i in range(len(large)) for p in range(4))
    return dict(rainbow=test, bank_exchange=swapped, reflected=reflected, block_steps=len(test) // 2)


def rainbow_census(a, prior):
    size = 2 * a
    rainbow = [int(i < a) for i in range(size)]
    completions = {}
    images = set()
    compatible = 0
    for dyck in words(a):
        mate, _ = bank(dyck)
        v = 0
        for length in range(1, a + 1):
            v = size - 1 - mate[v]
            if v == 0:
                break
        if length != a:
            continue
        word = [r + 2 * l for r, l in zip(rainbow, dyck)]
        completions[dyck] = word
        if all(no_double_peak(0 if i == 0 else word[i - 1], word[i], word[i + 1])
               for i in range(0, size, 2)):
            compatible += 1
        elif a >= 2:
            start = a - 2 if a % 2 else a
            assert dyck[start:start + 2] == (1, 0)
            image = dyck[:start] + dyck[start + 2:]
            assert image not in images
            images.add(image)
    if a >= 2:
        assert images == prior
    if 2 <= a <= 6:
        width = a - 1
        graph = automaton(width)
        empty = (0,) * (2 * width)
        states = [empty]
        for i, s in enumerate(states):
            for letter, j in enumerate(graph[i]):
                if j == len(states):
                    states.append(advance(s, width, letter))
        def pairs(s):
            return {(i, j) for i in range(2 * width) for j in range(i + 1, 2 * width)
                    if s[i] != 0 and s[i] == s[j]}
        known = [pairs(s) for s in states]
        bigger = automaton(a)
        for word in completions.values():
            for letters in [word, [((l & 1) << 1) + (l >> 1) for l in word]]:
                for i in range(len(graph)):
                    j = i
                    for symbol in letters:
                        j = graph[j][symbol]
                        assert j >= 0
                    assert known[j] <= known[i]
                j = 0
                for symbol in letters:
                    j = bigger[j][symbol]
                    if j < 0:
                        break
                assert j < 0
    return dict(connected=len(completions), excluded_at_peak=len(completions) - compatible,
                compatible_per_bank=compatible), set(completions)


def complete_failures(a):
    graph = automaton(a - 1)
    direct = parity = 0
    for upper, lower in product(words(a), repeat=2):
        i, prev, peak_ok = 0, 0, True
        for pos in range(0, 2 * a, 2):
            odd = upper[pos] + 2 * lower[pos]
            even = upper[pos + 1] + 2 * lower[pos + 1]
            i = next_pair(graph, i, odd, even)
            if i < 0:
                break
            peak_ok = peak_ok and no_double_peak(prev, odd, even)
            prev = even
        if i >= 0:
            direct += 1
            parity += peak_ok
    return dict(all_pairs=len(words(a)) ** 2, direct=direct, parity=parity)


def word_failures(a):
    """Count all even words, allowing free left and right ends, by independent DPs."""
    def total(physical_width, triple_test):
        graph = automaton(physical_width)
        active = {(0, 0): 1}
        for _ in range(a):
            nxt = Counter()
            for (s, p), count in active.items():
                for o, e in product(range(4), repeat=2):
                    if triple_test and not no_double_peak(p, o, e):
                        continue
                    j = next_pair(graph, s, o, e)
                    if j >= 0:
                        nxt[j, e] += count
            active = nxt
        return sum(active.values())
    exact = [total(a - 1, parity) - total(a, parity) for parity in (False, True)]
    if a <= 5:
        graph = automaton(a - 1)
        direct = parity = 0
        for word in product(range(4), repeat=2 * a):
            s = 0
            for letter in word:
                s = graph[s][letter]
                if s < 0:
                    break
            if s >= 0 and not physical(word, False):
                direct += 1
                parity += all(no_double_peak(0 if j == 0 else word[j - 1], word[j], word[j + 1])
                              for j in range(0, 2 * a, 2))
        assert [direct, parity] == exact
    return exact


def ray_census(a):
    rainbow = [int(i < a) for i in range(2 * a)]
    acyclic = 0
    for bits in product(range(2), repeat=2 * a):
        word = [r + 2 * t for r, t in zip(rainbow, bits)]
        acyclic += physical(word, False)
    return acyclic


def main():
    right = {}
    totals = {}
    for order in range(5):
        right[order], totals[order] = compare_fibres(2 * order + 1)
    for a, b in product(range(3), repeat=2):
        if a + b + 1 <= 4:
            joined = {u + (3,) + v for u in right[a] for v in right[b]}
            assert len(joined) == len(right[a]) * len(right[b])
            assert joined <= right[a + b + 1]
    rows = {}
    for w in range(1, 5):
        count = walks(w, w + 1)
        assert count <= 4 * totals[w]
        rows[w] = [count, 4 * totals[w]]
    compared = {}
    for width in (14, 15, 16):
        path = ROOT / "output/research77/window" / f"k{width}q1f.json"
        rec = json.loads(path.read_bytes())
        compared[width] = str(Fraction(rec["upper"], rec["den"]) ** 2)
    semi = {}
    prior = set()
    for a in range(1, 11):
        semi[a], prior = rainbow_census(a, prior)
    for a in range(2, 11):
        assert semi[a]["excluded_at_peak"] == semi[a - 1]["connected"]
        if a >= 3:
            assert semi[a]["connected"] >= 2 * semi[a - 1]["connected"]
    first_failures = {a: complete_failures(a) for a in range(2, 8)}
    for a, observed in first_failures.items():
        assert observed["direct"] == 2 * semi[a]["connected"]
        assert observed["parity"] == 2 * semi[a]["compatible_per_bank"]
    acyclic_rainbows = [1] + [ray_census(a) for a in range(1, 9)]
    ray_defects = [0] + [4 * acyclic_rainbows[a-1] - acyclic_rainbows[a] for a in range(1, 9)]
    all_failures = {a: word_failures(a) for a in range(2, 8)}
    for a, (direct, parity) in all_failures.items():
        assert direct == 2 * ray_defects[a]
        assert parity == 2 * (ray_defects[a] - ray_defects[a-1])
    output = {
        "fibre_sizes": {w: [len(right[w]), totals[w]] for w in right},
        "matrix_rows_upper": rows,
        "widths_one_two": initial_widths(),
        "strictness_witnesses": {w: strict_witness(w) for w in range(2, 6)},
        "rainbow_census": semi,
        "first_failures_on_complete_inputs": first_failures,
        "fixed_rainbow_acyclic_with_rays": acyclic_rainbows,
        "fixed_rainbow_false_positives": ray_defects,
        "first_failures_on_all_even_words": all_failures,
        "direct_square": compared,
        "sha256": {p.name: sha256(p.read_bytes()).hexdigest()
                   for p in (Path(__file__), HERE / "independent.py", HERE.parent / "graphs/acyclic_words.py")},
    }
    file = ROOT / "output/research85/frontier-audit/limit.json"
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
