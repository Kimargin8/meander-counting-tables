// Independent reconstruction of the integer test vector and every row quotient.
// A path is recorded by two equal labels. A ternary bracket word indexes states.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <vector>

using U = std::uint64_t;
using Wide = unsigned __int128;
using Moves = std::array<int,4>;
using Values = std::array<U,4>;
using Labels = std::array<unsigned char,32>;

struct Index {
    std::vector<U> keys;
    std::vector<int> numbers;
    std::size_t occupied=0;
    Index(): keys(1024,0),numbers(1024) {}
    std::size_t slot(U x) const {
        U h=x;
        h=(h^(h>>30))*0xbf58476d1ce4e5b9ULL;
        h=(h^(h>>27))*0x94d049bb133111ebULL;
        h^=h>>31;
        const auto mask=keys.size()-1;
        auto i=std::size_t(h)&mask;
        while(keys[i] && keys[i]!=x) i=(i+1)&mask;
        return i;
    }
    void grow(){
        auto old_keys=std::move(keys);
        auto old_ids=std::move(numbers);
        keys.assign(old_keys.size()*2,0);
        numbers.resize(keys.size());
        for(std::size_t j=0;j<old_keys.size();++j) if(old_keys[j]){
            const auto i=slot(old_keys[j]);keys[i]=old_keys[j];numbers[i]=old_ids[j];
        }
    }
    int intern(U key,int next) {
        if(occupied*10>=keys.size()*7) grow();
        // Shift by one to reserve zero as an unused slot.
        const auto j=slot(key+1);
        if(!keys[j]) {keys[j]=key+1; numbers[j]=next; ++occupied;}
        return numbers[j];
    }
};

Labels decode(U code,int w) {
    Labels labels{},open{};
    int depth=0;
    for(int i=0;i<2*w;++i){
        int digit=code%3;code/=3;
        if(digit==1) {labels[i]=i+1;open[depth++]=i+1;}
        if(digit==2) {if(!depth) std::abort(); labels[i]=open[--depth];}
    }
    if(depth||code) std::abort();
    return labels;
}

bool join(const Labels& old,int w,int symbol,U& key) {
    const bool up=symbol&1,down=symbol&2;
    const int end1=up?0:old[w-1],end2=down?0:old[w];
    if(end1 && end1==end2) return false;
    // The labels of all path fragments incident with the new crossing coalesce.
    // Label 31 is free for w<=15, since original labels were at most 30.
    Labels next{},freq{};
    for(int i=0;i<2*w;++i){
        int label=0;
        if(i<w){
            if(up) label=(i==w-1)?31:old[i+1];
            else if(i>0) label=old[i-1];
        }else{
            if(down) label=(i==w)?31:old[i-1];
            else if(i+1<2*w) label=old[i+1];
        }
        if(label && (label==end1||label==end2)) label=31;
        next[i]=label;
        ++freq[label];
    }
    key=0;
    Labels nesting{};
    int depth=0;
    // Encode from right to left in base three. Second occurrences are
    // closes. The expected partner must be the most recent open in reverse.
    for(int i=2*w-1;i>=0;--i){
        const int l=next[i];
        key*=3;
        if(!l||freq[l]==1) continue;
        if(freq[l]==2) {key+=2; nesting[depth++]=l;freq[l]=3;}
        else {
            if(freq[l]!=3 || !depth || nesting[--depth]!=l) std::abort();
            ++key;
        }
    }
    if(depth) std::abort();
    return true;
}

std::vector<Moves> rebuild(int width){
    Index dict;
    std::vector<U> words{0};
    std::vector<Moves> graph;
    dict.intern(0,0);
    for(std::size_t i=0;i<words.size();++i){
        const Labels labels=decode(words[i],width);
        Moves neighbours{};
        for(int s=0;s<4;++s){
            U key=0;
            if(!join(labels,width,s,key)){neighbours[s]=-1;continue;}
            if(words.size()>=std::size_t(INT32_MAX)) throw std::overflow_error("state index");
            int j=dict.intern(key,int(words.size()));
            if(j==int(words.size())) words.push_back(key);
            neighbours[s]=j;
        }
        graph.push_back(neighbours);
    }
    return graph;
}

struct Peaks {
    std::array<std::array<int,4>,4> index{};
    std::vector<unsigned> masks;
    Peaks(){
        for(int prev=0;prev<4;++prev) for(int odd=0;odd<4;++odd){
            unsigned mask=0;
            for(int even=0;even<4;++even){
                int ears=0;
                for(int bank=1;bank<=2;bank*=2)
                    ears+=bool(((prev&bank)&&!(odd&bank))||((odd&bank)&&!(even&bank)));
                if(ears<2) mask|=1u<<even;
            }
            const auto pos=std::find(masks.begin(),masks.end(),mask);
            index[prev][odd]=(mask==0)?-1:int(pos-masks.begin());
            if(mask && pos==masks.end()) masks.push_back(mask);
        }
        if(masks.size()!=4) std::abort();
    }
};

int main(int argc,char**argv){
    if(argc!=3) return 2;
    const int width=std::atoi(argv[1]),rounds=std::atoi(argv[2]);
    if(width>15||width<=0||rounds<=0) return 2;
    const auto start=std::chrono::steady_clock::now();
    const auto graph=rebuild(width);
    std::cerr<<"Rebuilt "<<graph.size()<<" states at width "<<width<<"\n";
    Peaks peaks;
    const std::size_t n=graph.size();
    std::vector<Values> v(n),partial(n);
    constexpr U unit=U(1)<<52;
    std::fill(v.begin(),v.end(),Values{unit,unit,unit,unit});
    U highest=unit,num=0,den=1;
    int wit=-1,prev=-1;
    for(int t=0;t<=rounds;++t){
        if(highest>std::numeric_limits<U>::max()/16) throw std::overflow_error("integer macro product");
        for(std::size_t i=0;i<n;++i){
            Values right{};
            for(int c=0;c<4;++c) if(graph[i][c]>=0) right[c]=v[graph[i][c]][c];
            for(std::size_t j=0;j<peaks.masks.size();++j){
                const unsigned m=peaks.masks[j];
                partial[i][j]=((m&1)?right[0]:0)+((m&2)?right[1]:0)
                              +((m&4)?right[2]:0)+((m&8)?right[3]:0);
            }
        }
        highest=0;
        for(std::size_t i=0;i<n;++i){
            Values sums{};
            for(int b=0;b<4;++b) if(int j=graph[i][b];j>=0){
                const auto& tail=partial[j];
                for(int p=0;p<4;++p) if(int idx=peaks.index[p][b];idx>=0) sums[p]+=tail[idx];
            }
            for(int p=0;p<4;++p){
                if(t<rounds) {
                    v[i][p]=std::max<U>(1,sums[p]/11);
                    highest=std::max(highest,v[i][p]);
                } else if(Wide(sums[p])*den>Wide(num)*v[i][p]) {
                    num=sums[p];den=v[i][p];wit=int(i);prev=p;
                }
            }
        }
    }
    const auto g=std::gcd(num,den);
    const double sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::cout<<"{\"width\":"<<width<<",\"rounds\":"<<rounds<<",\"states\":"<<n
             <<",\"macro_rows\":"<<4*n<<",\"rate_numerator\":"<<num/g
             <<",\"rate_denominator\":"<<den/g<<",\"witness_bfs\":"<<wit
             <<",\"witness_previous\":"<<prev<<",\"wall_seconds\":"<<sec<<"}\n";
}
