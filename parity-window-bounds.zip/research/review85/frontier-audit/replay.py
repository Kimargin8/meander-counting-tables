"""Compare the independently reconstructed integer bound with the frozen claim."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]


def main():
    width=int(sys.argv[1])
    source=ROOT/'output/research85/capacity'/f'stack-{width}.json'
    claimed=json.loads(source.read_bytes())
    binary=Path(sys.argv[2]).resolve()
    proc=subprocess.run([str(binary),str(width),str(claimed["rounds"])],capture_output=True,
                        check=True,text=True)
    print(proc.stderr,file=sys.stderr,end='')
    got=json.loads(proc.stdout)
    for key in ('width','rounds','states','rate_numerator','rate_denominator'):
        assert got[key]==claimed[key], (key,got[key],claimed[key])
    assert got["macro_rows"]==claimed["macro_states"]
    u=Fraction(got["rate_numerator"],got["rate_denominator"])
    g=u*(u+1)/(u-1)
    result=dict(**got,ordinary_upper=str(g),approximate=float(g),interpreter=sys.version.split()[0],
                compiler=subprocess.check_output(['g++','-dumpfullversion'],text=True).strip(),
                source_sha256=sha256(source.read_bytes()).hexdigest(),
                generator_sha256=sha256((HERE/'independent.cpp').read_bytes()).hexdigest(),
                replay_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
                executable_sha256=sha256(binary.read_bytes()).hexdigest())
    dest=ROOT/'output/research85/frontier-audit'/f'integer-{width}.json'
    dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(g,float(g),flush=True)


if __name__=="__main__":
    main()
