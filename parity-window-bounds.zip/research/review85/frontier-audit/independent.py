"""Independent verifier for the finite-stack majorant; no project modules imported."""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys

ROOT=Path(__file__).resolve().parents[3]


def advance(word, width, symbol):
    """Two bounded stacks store labels, with both tips of a known path labelled alike."""
    pops=[]
    stacks=[]
    fresh=max(word)+1
    for side in range(2):
        stack=word[side*width:(side+1)*width]
        if symbol & (1<<side):
            stacks.extend((fresh,*stack[:-1]))
        else:
            pops.append(stack[0])
            stacks.extend((*stack[1:],0))
    if len(pops)==2 and pops[0]==pops[1]!=0:
        return None
    # All known paths touched by the current vertex form one path; a
    # singleton end after the move has no surviving certificate of a mate.
    if pops:
        known=set(pops)-{0}
        stacks=[fresh if label in known else label for label in stacks]
    frequencies=Counter(stacks)
    ids={}
    for i,label in enumerate(stacks):
        if label==0 or frequencies[label]!=2:
            stacks[i]=0
        else:
            stacks[i]=ids.setdefault(label,len(ids)+1)
    return tuple(stacks)


def automaton(width):
    blank=(0,)*(2*width)
    states=[blank]
    numbers={blank:0}
    transition=[]
    for s in states:
        row=[]
        for letter in range(4):
            dest=advance(s,width,letter)
            if dest is None:
                row.append(-1)
            else:
                if dest not in numbers:
                    numbers[dest]=len(states)
                    states.append(dest)
                row.append(numbers[dest])
        transition.append(row)
    return transition


def no_double_peak(a,b,c):
    ear=[]
    for flag in [1,2]:
        rising=[bool(x&flag) for x in (a,b,c)]
        ear.append(rising[0] and not rising[1] or rising[1] and not rising[2])
    return not all(ear)


def macro_check(arrows, cert):
    vector=cert["vector"]
    bound=Fraction(cert["rate"])
    assert len(vector)==4*len(arrows) and all(type(v)==int and v>0 for v in vector)
    allowed={a:[(b,c) for b in range(4) for c in range(4) if no_double_peak(a,b,c)]
             for a in range(4)}
    edges=tight=0
    largest_n,largest_d=0,1
    for state,row in enumerate(arrows):
        for a in range(4):
            total=0
            for b,c in allowed[a]:
                after=row[b]
                if after>=0 and (end:=arrows[after][c])>=0:
                    edges+=1
                    total+=vector[4*end+c]
            v=vector[4*state+a]
            slack=bound.numerator*v-bound.denominator*total
            assert slack>=0
            tight+=int(slack==0)
            if total*largest_d>largest_n*v:
                largest_n,largest_d=total,v
    assert Fraction(largest_n,largest_d)==bound and tight>0
    mu=bound*(bound+1)/(bound-1)
    assert mu==Fraction(cert["mu_upper"]) and bound>3
    assert len(arrows)==cert["states"] and len(vector)==cert["macro_states"] and edges==cert["transitions"]
    return dict(states=len(arrows),macro_rows=len(vector),macro_edges=edges,equality_rows=tight,
                minimum_weight=min(vector),maximum_weight=max(vector),
                row_bound=str(bound),ordinary_upper=str(mu))


@lru_cache(None)
def words(n):
    if n==0:
        return ((),)
    return tuple((1,)+inner+(0,)+outer for k in range(n)
                 for inner in words(k) for outer in words(n-1-k))


def bank(word):
    n=len(word)
    mate=[0]*n
    stack=[]
    for j,isopen in enumerate(word):
        if isopen:
            stack.append(j)
        else:
            i=stack.pop()
            mate[i],mate[j]=j,i
    ears=sum(1<<k for k in range(n//2) if mate[2*k+1] in (2*k,(2*k+2)%n))
    return tuple(mate),ears


def directly_closed(n, arrows):
    w=words(n)
    diagrams=[bank(s) for s in w]
    connected=physical=linear=0
    interior=(1<<(n-1))-1
    for i,(u,mask_u) in enumerate(diagrams):
        for j,(l,mask_l) in enumerate(diagrams):
            vertex=0
            for length in range(1,n+1):
                vertex=l[u[vertex]]
                if vertex==0:
                    break
            if length!=n:
                continue
            connected+=1
            if mask_u&mask_l&interior:
                continue
            linear+=1
            physical+=int(not (mask_u&mask_l))
            symbols=tuple(x+2*y for x,y in zip(w[i],w[j]))
            assert symbols[0]==3 and symbols[-1]==0
            state=arrows[0][3]
            for k in range(1,len(symbols)-1,2):
                a,b,c=symbols[k-1:k+2]
                assert no_double_peak(a,b,c)
                after=arrows[state][b]
                assert after>=0
                state=arrows[after][c]
                assert state>=0
    return dict(bank_pairs=len(w)**2,connected=connected,cyclic_connected_avoiders=physical,
                aligned_linear_avoiders_accepted=linear)


def verify_composition(rows):
    n=len(rows)+1
    # Compute f=z(1-z)/(1+z) directly as a signed integer series.
    f=[0,1]+[2*(-1)**(k-1) for k in range(2,n+1)]
    power=[1]+[0]*n
    Z=[0]*(n+1)
    for m in range(1,n+1):
        power=[sum(power[i]*f[k-i] for i in range(k+1)) for k in range(n+1)]
        count=1 if m==1 else rows[str(m)]["connected"]
        Z=[a+count*b for a,b in zip(Z,power)]
    assert all(Z[m]==rows[str(m)]["aligned_linear_avoiders_accepted"] for m in range(2,n+1))


def main():
    source=ROOT/"output/research85/capacity"/sys.argv[1] if len(sys.argv)>1 else (
        ROOT/"output/research85/capacity/frontier-w9.json")
    cert=json.loads(source.read_bytes())
    arrows=automaton(cert["w"])
    result=macro_check(arrows,cert)
    result["literal_checks"]={str(n):directly_closed(n,arrows) for n in range(2,9)}
    verify_composition(result["literal_checks"])
    result["w"]=cert["w"]
    result["source_sha256"]=sha256(source.read_bytes()).hexdigest()
    result["verifier_sha256"]=sha256(Path(__file__).read_bytes()).hexdigest()
    result["python"]=platform.python_version()
    out=ROOT/"output/research85/frontier-audit"/f"w{cert['w']}.json"
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(result,flush=True)


if __name__=="__main__":
    main()
