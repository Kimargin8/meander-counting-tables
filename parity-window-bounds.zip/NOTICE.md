# Sources and licenses

Copyright © 2026 Iaroslav Argunov for the original contributions.

The original verification programs are released under the [MIT License](licenses/MIT.txt). The original manuscript, explanatory text and original verification records are released under [CC BY 4.0](licenses/CC-BY-4.0.txt).

The prior public window computation is [Meandric growth from local connectivity at a cut, version 1.0.0](https://doi.org/10.5281/zenodo.24457226). The finite certificates compare the same window widths. The manuscript cites Caroppo, Da Lozzo, Di Battista and Vihrovs for the underlying planar algorithms.
