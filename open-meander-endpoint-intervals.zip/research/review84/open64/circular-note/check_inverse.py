"""Check the positive inverse-series reconstruction independently of cyclic IE."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import platform

ROOT = Path(__file__).resolve().parents[4]
CIRCLE = ROOT/"output/research84/open64/circle33.json"
CLOSED = ROOT/"references/oeis/2026-11-15/b005315.txt"
OPEN = ROOT/"references/oeis/2026-11-15/b005316.txt"
OPEN60 = ROOT/"output/research80/open-ear/marked-groups-n31/result.json"
OPEN62 = ROOT/"output/research83/open62/result.json"
OUT = ROOT/"output/research84/open64/circular-note/inverse-check.json"


def table(path):
    return dict(tuple(map(int,line.split())) for line in path.read_text().splitlines()
                if line.strip() and not line.startswith("#"))


def product(a,b,n):
    return [sum(a[j]*b[k-j] for j in range(k+1)) for k in range(n+1)]


def main():
    N = 31
    circle = json.loads(CIRCLE.read_bytes())["cyclic_certificates"]
    closed, physical = table(CLOSED), table(OPEN)
    target = {n:physical[2*n] for n in range(1,30)}
    target[30] = int(json.loads(OPEN60.read_bytes())["open_count"])
    target[31] = int(json.loads(OPEN62.read_bytes())["open_count"])
    M = [0]+[closed[k] for k in range(1,N+1)]
    s = [0]*(N+1)
    for n in range(1,N+1):
        s[n] = int(n==1)+s[n-1]+sum(s[j]*s[n-j] for j in range(1,n))
    inv = [1]+[0]*N
    for n in range(1,N+1):
        inv[n] = sum(s[j]*inv[n-j] for j in range(1,n+1))
    known = product(M,inv,N)
    actual = known.copy()
    upper = known.copy()
    power = [1]+[0]*N
    for row in circle:
        k = row["N"]
        if k > N+1:
            break
        power = product(power,s,N)
        kernel = [a+b for a,b in zip(power,product(s,power,N))]
        actual = [a+b*row["X_N"] for a,b in zip(actual,kernel)]
        upper = [a+b*F(row["A_N"],4) for a,b in zip(upper,kernel)]
    assert all(actual[n] == target[n] <= upper[n] for n in range(1,N+1))
    cert = {"python": platform.python_version(),
            "sha256":{p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest()
                      for p in (CIRCLE,CLOSED,OPEN,OPEN60,OPEN62,Path(__file__).resolve())},
            "reconstruction": "E(t)=1+M(t)/(1-s)+(1+s) X(s)/s, s=t+ts+s^2.",
            "full_integer_coefficients_checked":list(range(1,N+1)),
            "even_open_order_31":str(actual[31]),
            "last_ceiling_from_circular_quarter_bound":str(upper[31])}
    OUT.parent.mkdir(exist_ok=True,parents=True)
    OUT.write_text(json.dumps(cert,indent=2)+"\n",encoding="utf-8")


if __name__ == "__main__":
    main()
