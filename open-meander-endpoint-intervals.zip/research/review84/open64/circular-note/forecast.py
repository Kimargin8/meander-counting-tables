"""Integer enclosures for later even open terms using no later open inputs."""
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import json
import platform

from check_inverse import ROOT, CLOSED, OPEN, OPEN60, OPEN62, product, table

OUT = ROOT/"output/research84/open64/circular-note/later-terms.json"
CAPS = ROOT/"output/research84/open64/cyclic-cap-orders.json"


def inverse_and_avoiders(closed,n):
    # Inputs M_1..M_(n+1). All operations are formal coefficient extraction.
    s = [0]*(n+1)
    inverse = [1]+[0]*n
    kernel = []
    for k in range(1,n+1):
        s[k] = int(k==1)+s[k-1]+sum(s[j]*s[k-j] for j in range(1,k))
        inverse[k] = sum(s[j]*inverse[k-j] for j in range(1,k+1))
    power = [1]+[0]*n
    for j in range(2,n+2):
        power = product(power,s,n)
        kernel.append([a+b for a,b in zip(power,product(power,s,n))])
        assert kernel[-1][j-1] == 1 and all(x>=0 for x in kernel[-1])
    base = product([0]+[closed[k] for k in range(1,n+1)],inverse,n)
    size=n+1
    # f=z(1-z)/(1+z), A=(1-2z/(1-z^2))M(f)-2z/(1+z)+z
    f = [0,1]+[2*(-1)**(k-1) for k in range(2,size+1)]
    power = [1]+[0]*size
    composed=[0]*(size+1)
    for k in range(1,size+1):
        power = product(power,f,size)
        composed = [a+closed[k]*b for a,b in zip(composed,power)]
    avoiding = product(composed,[1]+[-2 if i%2 else 0 for i in range(1,size+1)],size)
    for k in range(1,size+1):
        avoiding[k]+=2*(-1)**k+int(k==1)
    assert all(a>=0 for a in avoiding)
    return kernel,base,avoiding


def enclose(closed, earlier, last, caps=None):
    n0 = max(earlier)
    assert set(earlier) == set(range(1,n0+1))
    kernels, base, avoiding = inverse_and_avoiders(closed,last)
    xs = {}
    rows = []
    for n in range(1,last+1):
        N = n+1
        a = avoiding[N]
        xlow,xhigh = (a+N-1)//N,a//4
        if caps is not None and str(N) in caps:
            cap = caps[str(N)]
            assert int(cap["A_N"]) == a
            xlow,xhigh = max(xlow,int(cap["X_lower"])),min(xhigh,int(cap["X_upper"]))
            assert xlow <= xhigh
        known = base[n]
        lo = hi = known
        for j,(l,h) in xs.items():
            coef = kernels[j-2][n]
            lo += coef*l
            hi += coef*h
        if n <= n0:
            assert lo == hi
            value = earlier[n] - lo
            assert xlow <= value <= xhigh
            xs[N]=(value,value)
        else:
            xs[N]=(xlow,xhigh)
            lo += xlow
            hi += xhigh
            rows.append({"crossings":2*n,"lower":str(lo),"upper":str(hi),"width":str(hi-lo),
                         "relative_width_over_lower":str(Q(hi-lo,lo)),
                         "A_at_next_order":str(a)})
    return rows


def main():
    closed = table(CLOSED)
    physical = table(OPEN)
    earlier = {j:physical[2*j] for j in range(1,30)}
    earlier[30] = int(json.loads(OPEN60.read_bytes())["open_count"])
    earlier[31] = int(json.loads(OPEN62.read_bytes())["open_count"])
    validations = []
    for end in range(3,31):
        rows = enclose(closed,{i:v for i,v in earlier.items() if i<=end},min(end+6,31))
        for row in rows:
            actual=earlier[row["crossings"]//2]
            assert int(row["lower"]) <= actual <= int(row["upper"])
        validations.append({"last_open_input":2*end,"withheld":[r["crossings"] for r in rows]})
    rows = enclose(closed,earlier,max(closed)-1)
    caps = json.loads(CAPS.read_bytes())["by_order"]
    improved = enclose(closed,earlier,max(closed)-1,caps)
    assert all(int(a["lower"]) <= int(b["lower"]) <= int(b["upper"]) <= int(a["upper"])
               for a,b in zip(rows,improved))
    data = {"python":platform.python_version(),"sha256":{
        p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in
        (CLOSED,OPEN,OPEN60,OPEN62,CAPS,Path(__file__).resolve(),Path(__file__).with_name("check_inverse.py"))},
        "models":"Cyclic labelled closed banks; even ordinary open paths with two upper rays.",
        "largest_closed_input":max(closed),"largest_even_open_input":2*max(earlier),
        "future_values_are_integer_intervals":True,"holdout_windows":validations,
        "elementary_forecasts":rows,"forecasts":improved}
    OUT.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":
    main()
