"""Circular irreducible capacities with weights on physical short arches.

Use the labelled gap substitution derived in README.md. Only exact integer
series and polynomial interpolation at integer arguments are used.
"""
from collections import Counter
from hashlib import sha256
from math import factorial
from pathlib import Path
import json
import platform
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(HERE.parent / "cyclic-cap"))
import check as marked


def compressed(n, totals, width):
    mask = (1 << width) - 1
    out = Counter()
    for key, multiplicity in totals.items():
        s, t, j = key & mask, (key >> width) & mask, key >> (2*width)
        out[s+t,j] += multiplicity * marked.catalan(n-s-j) * marked.catalan(n-t-j)
    return out


def moments(nmax):
    width = (nmax+1).bit_length()
    step = marked.joint_steps(width)
    linear = [{}]
    state = {(0,0): {0: 1}}
    for n in range(1,nmax+1):
        state = marked.advance(state,step)
        totals = Counter()
        for current, row in state.items():
            if 2 not in current:
                totals.update(row)
        linear.append(compressed(n,totals,width))
    cyclic = [Counter() for _ in range(nmax+1)]
    for start in marked.JOINT:
        state = {start:{step[start]:1}}
        for n in range(1,nmax+1):
            if n>=2:
                totals = Counter()
                for current,row in state.items():
                    if start in marked.JOINT_NEXT[current]:
                        totals.update(row)
                cyclic[n].update(compressed(n,totals,width))
            if n<nmax:
                state=marked.advance(state,step)
    # The two cyclic neighbours coincide at order one.
    cyclic[1] = linear[1]
    return linear, cyclic


def evaluate_marks(moments,x):
    rows=[[]]
    for n,terms in enumerate(moments[1:],1):
        row=Counter()
        for (single,double), count in terms.items():
            row[2*n-single-2*double] += count*(x-1)**single*(1-2*x)**double
        rows.append([(degree,coef) for degree,coef in row.items() if coef])
    return rows


def evaluated_irreducibles(linear,cyclic,x):
    nmax=len(linear)-1
    powers=[[1]+[0]*nmax for _ in range(2*nmax+1)]
    F=[1]+[0]*nmax
    target=[0]*(nmax+1)
    lrows,crows=evaluate_marks(linear,x),evaluate_marks(cyclic,x)
    for n in range(1,nmax+1):
        def substitute(rows):
            return sum(coef*powers[d][n-k] for k in range(1,n+1) for d,coef in rows[k])
        F[n]=substitute(lrows)
        # Remove the special root block of two vertices. Its substituted
        # contribution is z*(2*(1-2x)*F + 6x-4 + 2*(1-x)/F).
        target[n]=substitute(crows)-(2*(1-2*x)*F[n-1]+(6*x-4)*int(n==1)
                                       +2*(1-x)*powers[1][n-1])
        powers[1][n]=-sum(F[i]*powers[1][n-i] for i in range(1,n+1))
        for d in range(2,len(powers)):
            powers[d][n]=sum(powers[1][i]*powers[d-1][n-i] for i in range(n+1))
    return target


def interpolate(values):
    # The forward differences at zero are integer multiples of k! for Z[x].
    degree=len(values)-1
    result=[0]*(degree+1)
    basis=[1]
    for k in range(degree+1):
        scale,remainder=divmod(values[0],factorial(k))
        assert remainder==0
        for i,coef in enumerate(basis):
            result[i]+=scale*coef
        values=[b-a for a,b in zip(values,values[1:])]
        basis=[a-k*b for a,b in zip([0]+basis,basis+[0])]
    return result


def main():
    nmax=int(sys.argv[1]) if len(sys.argv)>1 else 38
    assert 2 <= nmax <= 38
    linear,cyclic=moments(nmax)
    samples=[evaluated_irreducibles(linear,cyclic,x) for x in range(nmax+2)]
    caps={}
    for n in range(2,nmax+1):
        cap=interpolate([row[n] for row in samples[:n+1]])
        assert min(cap)>=0 and sum(v*(nmax+1)**j for j,v in enumerate(cap))==samples[-1][n]
        caps[n]=cap
    old_path=ROOT/'output/research84/open64/cyclic-cap-orders.json'
    previous=json.loads(old_path.read_bytes())['by_order']
    bounds={}
    for n,cap in caps.items():
        if str(n) not in previous:
            continue
        old=previous[str(n)]
        total=int(old['A_N'])
        assert all(a<=b-c-d for a,b,c,d in zip(cap,old['unrestricted_capacities'],
                   old['proper_prefix_excluded'],old['interval_across_seam_excluded']))
        low,_=marked.extreme(total,cap,False)
        high,_=marked.extreme(total,cap,True)
        bounds[n]=dict(A_N=total,X_lower=(low+4*n-1)//(4*n),X_upper=high//(4*n))
        assert old['X_lower']<=bounds[n]['X_lower']<=bounds[n]['X_upper']<=old['X_upper']
    sources=[Path(__file__),Path(marked.__file__),old_path]
    data=dict(histograms=caps, by_order=bounds, python=platform.python_version(),
              sha256={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in sources})
    out=ROOT/f'output/research84/open64/nc-join/order-{nmax}.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
    print('orders:',nmax,'bound at 33:',bounds.get(33))


if __name__=='__main__':
    main()
