"""Capacity of snake-free connected pairs by exact enumeration of their local relaxation."""

from collections import Counter, defaultdict
from fractions import Fraction
from functools import cache
from hashlib import sha256
import json
from math import comb
from pathlib import Path
import platform


ROOT = Path(__file__).resolve().parents[4]
KNOWN = ROOT / "references/oeis/2026-11-15/b005315.txt"
OUT = ROOT / "output/research84/open64/cyclic-cap.json"
MULTI = ROOT / "output/research84/open64/cyclic-cap-orders.json"
STATES = ((0, 0), (1, 0), (2, 0), (1, 1), (1, 2), (2, 1), (2, 2))
NEXT = {a: [b for b in STATES if all(x != 2 or y != 1 for x, y in zip(a, b))]
        for a in STATES}


def catalan(n):
    return comb(2 * n, n) // (n + 1)


def capacity(n):
    # The left/right marks force a boundary edge. A 2 -> 1 transition would
    # force two edges on the same intervening even site of that bank.
    totals = Counter()
    for start in STATES:
        dp = {start: {(int(bool(start[0])), int(bool(start[1]))): 1}}
        for _ in range(n - 1):
            new = defaultdict(Counter)
            for current, counts in dp.items():
                for nxt in NEXT[current]:
                    x, y = int(bool(nxt[0])), int(bool(nxt[1]))
                    output = new[nxt]
                    for (s, t), count in counts.items():
                        output[s+x, t+y] += count
            dp = new
        for current, counts in dp.items():
            if start in NEXT[current]:
                totals.update(counts)
    result = [0] * (n + 1)
    for (s, t), value in totals.items():
        factor = catalan(n-s) * catalan(n-t) * value
        for e in range(t, s + 1):
            result[e] += (-1)**(t+s-e) * comb(s-t, e-t) * factor
    assert all(v >= 0 for v in result)
    return result


JOINT = [(a,b) for a in range(3) for b in range(3)]
JOINT_NEXT = {a:[b for b in JOINT if all(v != 2 or w != 1 for v,w in zip(a,b))] for a in JOINT}


def joint_steps(width):
    return {(a,b): (1 if a and not b else (1 << width) if b and not a else
                    (1 << (2*width)) if a and b else 0) for a,b in JOINT}


def advance(table, step):
    new = defaultdict(Counter)
    for current, row in table.items():
        for target in JOINT_NEXT[current]:
            buf = new[target]
            delta = step[target]
            for key, v in row.items():
                buf[key+delta] += v
    return new


def marked_polynomial(n, totals, width):
    mask = (1 << width)-1
    marks = Counter()
    for key,v in totals.items():
        s,t,j = key&mask, (key>>width)&mask, key>>(2*width)
        marks[s+t,j] += v*catalan(n-s-j)*catalan(n-t-j)
    result = [0]*(n+1)
    for (p,j),v in marks.items():
        # (x-1)^p (1-2x)^j
        for i in range(p+1):
            a = (-1)**(p-i)*comb(p,i)*v
            for k in range(j+1):
                result[i+k] += a*(-2)**k*comb(j,k)
    assert all(v >= 0 for v in result)
    return result


def total_capacity(n):
    return total_capacity_orders([n])[n]


def total_capacity_orders(orders):
    wanted = set(orders)
    max_n = max(wanted)
    width = (max_n+1).bit_length()
    step = joint_steps(width)
    totals = {n: Counter() for n in wanted}
    for start in JOINT:
        table = {start: {step[start]: 1}}
        for n in range(1, max_n+1):
            if n in wanted:
                for current, row in table.items():
                    if start in JOINT_NEXT[current]:
                        totals[n].update(row)
            if n < max_n:
                table = advance(table, step)
    return {n:marked_polynomial(n, v, width) for n,v in totals.items()}


def linear_rows(max_n):
    # All lengths in one pass. At the final odd site an outgoing edge is absent.
    width = (max_n+1).bit_length()
    step = joint_steps(width)
    table = {(0,0): {0: 1}}
    full = [[1]]
    proper = [[0]]
    primitive = [[0]]
    for n in range(1, max_n+1):
        table = advance(table, step)
        totals = Counter()
        for state, row in table.items():
            if 2 not in state:
                totals.update(row)
        f = marked_polynomial(n, totals, width)
        split = [0] * (n+1)
        for i in range(1, n):
            for a, va in enumerate(primitive[i]):
                for b, vb in enumerate(full[n-i]):
                    split[a+b] += va*vb
        ind = [x-y for x,y in zip(f, split)]
        assert min(ind) >= 0
        full.append(f)
        primitive.append(ind)
        proper.append(split)
    return full, proper


def avoid_count(n, closed):
    # Requiring an oriented three-site path gives one orientation per run.
    ans = closed[n] + (-1)**n * 2
    for j in range(1, n):
        placements = sum(Fraction(n, h) * comb(j-1, h-1) * comb(n-j-1, h-1) * 2**h
                         for h in range(1, min(j, n-j) + 1))
        assert placements.denominator == 1
        ans += (-1)**j * int(placements) * closed[n-j]
    return ans


@cache
def matchings(n):
    if not n:
        return ((),)
    out = []
    for m in range(n):
        for inside in matchings(m):
            for outside in matchings(n-1-m):
                offset = 2*m + 2
                out.append((2*m+1,) + tuple(i+1 for i in inside) + (0,)
                           + tuple(i+offset for i in outside))
    return tuple(out)


def brute(n):
    cap, good = [0]*(n+1), [0]*(n+1)
    both, connected_both, proper, across = ([0]*(n+1) for _ in range(4))
    masks = {}
    for partner in matchings(n):
        mask = sum(1 << k for k in range(n)
                   if partner[2*k+1] in (2*k, (2*k+2) % (2*n)))
        masks[partner] = mask
    anchored = 0
    for lo, a in masks.items():
        for up, b in masks.items():
            if a & b:
                continue
            e = a.bit_count()
            cap[e] += 1
            h = e+b.bit_count()
            both[h] += 1
            has_cut = any(max(lo[:k]) < k and max(up[:k]) < k for k in range(2,2*n,2))
            if has_cut:
                proper[h] += 1
            v = 0
            for j in range(1, n+1):
                v = up[lo[v]]
                if v == 0:
                    break
            if j == n:
                good[e] += 1
                connected_both[h] += 1
                anchored += int(lo[0] == 1)
            elif j <= 9:
                component = set()
                v = 0
                for _ in range(j):
                    component.update((v,lo[v]))
                    v = up[lo[v]]
                if 2*n-1 in component and sum((i+1)%(2*n) not in component for i in component) == 1:
                    assert not has_cut
                    across[h] += 1
    return cap, good, anchored, both, connected_both, proper, across


def connected_linear(n):
    banks = matchings(n)
    masks = [(p, sum(1 << k for k in range(n) if abs(p[2*k+1]-(2*k+1)) == 1)) for p in banks]
    counts = [0]*(n+1)
    for lower, lm in masks:
        for upper, um in masks:
            if lm & um:
                continue
            v = 0
            for j in range(1,n+1):
                v = upper[lower[v]]
                if not v:
                    break
            if j == n:
                counts[(lm|um).bit_count()] += 1
    return counts


def through_cut(n, motifs, linear):
    # Connected components of a graph are disjoint. At most one can contain
    # the two physical sites of the prescribed seam in a proper cyclic interval.
    result = [0]*(n+1)
    for m, coefficients in motifs.items():
        if m >= n:
            continue
        for i, a in enumerate(coefficients):
            for j, b in enumerate(linear[n-m]):
                result[i+j] += (2*m-1)*a*b
    return result


def extreme(total, cap, reverse):
    left = total
    occupied = {}
    for index in sorted(range(2, len(cap)), reverse=reverse):
        take = min(left, cap[index])
        if take:
            occupied[index] = take
            left -= take
        if not left:
            break
    assert left == 0
    return sum(e*a for e, a in occupied.items()), occupied


def main():
    M = {int(pair[0]): int(pair[1]) for line in KNOWN.read_text().splitlines()
         if len(pair := line.split()) == 2 and pair[0].isdigit()}
    exact = {}
    high_orders = range(33,39)
    linear, split = linear_rows(max(high_orders))
    motifs = {i:connected_linear(i) for i in range(1,10)}
    hist = total_capacity_orders([*range(2,8), *high_orders])
    for n in range(2, 8):
        cap, good, anchored, both, connected_both, proper, across = brute(n)
        assert cap == capacity(n)
        assert both == hist[n]
        assert proper == split[n]
        assert across == through_cut(n, motifs, linear)
        assert sum(good) == avoid_count(n, M)
        assert 2*n*anchored == sum(e*a for e,a in enumerate(good))
        assert 4*n*anchored == sum(e*a for e,a in enumerate(connected_both))
        assert all(a <= bound for a, bound in zip(good, cap))
        exact[n] = dict(capacity=cap, connected=good, anchored=anchored,
                        capacity_total=both, connected_total=connected_both, common_prefix=proper,
                        interval_component_across_seam=across)
    n = 33
    total = avoid_count(n, M)
    cap = capacity(n)
    cap_both = hist[n]
    assert sum(cap_both) == sum(cap)
    assert sum(i*v for i,v in enumerate(cap_both)) == 2*sum(i*v for i,v in enumerate(cap))
    low, left = extreme(total, cap, False)
    high, right = extreme(total, cap, True)
    assert cap[:2] == [0,0]
    data = dict(python=platform.python_version(), code_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
                closed_table_sha256=sha256(KNOWN.read_bytes()).hexdigest(), small_checks=exact, order=n,
                avoidance_mass=total, capacities=cap, lower_allocation=left, upper_allocation=right,
                anchor_lower=(low+2*n-1)//(2*n), anchor_upper=high//(2*n),
                coarse_anchor_lower=(2*total+2*n-1)//(2*n), coarse_anchor_upper=total//2)
    low_both, alloc_l = extreme(total, cap_both, False)
    high_both, alloc_u = extreme(total, cap_both, True)
    data["total_ears"] = dict(capacities=cap_both, minimum_allocation=alloc_l, maximum_allocation=alloc_u,
                              anchor_lower=(low_both+4*n-1)//(4*n), anchor_upper=high_both//(4*n),
                              complement_to_symmetry_cap=(total//4-high_both//(4*n)))
    across = through_cut(n, motifs, linear)
    remaining = [v-c-d for v,c,d in zip(cap_both, split[n], across)]
    assert all(v>=0 for v in remaining)
    p_low, p_lalloc = extreme(total, remaining, False)
    p_high, p_ualloc = extreme(total, remaining, True)
    data["no_common_prefix"] = dict(removed=split[n], removed_across_seam=across, capacities=remaining, minimum_allocation=p_lalloc,
                                    maximum_allocation=p_ualloc, anchor_lower=(p_low+4*n-1)//(4*n),
                                    anchor_upper=p_high//(4*n))
    circle_path = ROOT / "output/research84/open64/circle33.json"
    circle = json.loads(circle_path.read_bytes())["open64"]
    shift = int(circle["X_N_minus_E_N_minus_1"])
    assert int(circle["A_N"]) == total
    data["open64"] = dict(offset_X_minus_E=shift, reference_sha256=sha256(circle_path.read_bytes()).hexdigest(),
                          lower=max(data["anchor_lower"], data["no_common_prefix"]["anchor_lower"])-shift,
                          upper=min(data["anchor_upper"], data["no_common_prefix"]["anchor_upper"])-shift)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data,indent=2)+"\n", encoding="utf-8")
    orders = {}
    for i in high_orders:
        total = avoid_count(i, M)
        across = through_cut(i, motifs, linear)
        remaining = [v-c-d for v,c,d in zip(hist[i],split[i],across)]
        assert min(remaining) >= 0
        minimum, lo = extreme(total, remaining, False)
        maximum, hi = extreme(total, remaining, True)
        orders[i] = dict(A_N=total, X_lower=(minimum+4*i-1)//(4*i), X_upper=maximum//(4*i),
                         unrestricted_capacities=hist[i], proper_prefix_excluded=split[i], interval_across_seam_excluded=across,
                         minimum_allocation=lo, maximum_allocation=hi)
    assert orders[33]["X_lower"] == data["no_common_prefix"]["anchor_lower"]
    assert orders[33]["X_upper"] == data["no_common_prefix"]["anchor_upper"]
    MULTI.write_text(json.dumps(dict(by_order=orders, connected_linear_motifs=motifs, python=data["python"], code_sha256=data["code_sha256"],
                                     closed_table_sha256=data["closed_table_sha256"]),indent=2)+"\n",encoding="utf-8")
    print("order 33:", data["avoidance_mass"], data["open64"])


if __name__ == "__main__":
    main()
