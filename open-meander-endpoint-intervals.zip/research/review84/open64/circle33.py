"""Exact cyclic avoidance bounds on ordinary even open meanders."""

from functools import cache
from hashlib import sha256
from itertools import combinations
import json
from math import comb, gcd, prod
from pathlib import Path
import platform


ROOT = Path(__file__).resolve().parents[3]
SOURCES = [
    ROOT / "references/oeis/2026-11-15/b005315.txt",
    ROOT / "references/oeis/2026-11-15/b005316.txt",
    ROOT / "output/research80/open-ear/marked-groups-n31/result.json",
    ROOT / "output/research83/open62/result.json",
]
OUT = ROOT / "output/research84/open64/circle33.json"


def table(path):
    return dict(tuple(map(int, line.split())) for line in path.read_text().splitlines()
                if line.strip() and not line.startswith("#"))


def exact_quotient(a, b):
    z, r = divmod(a,b)
    assert r == 0
    return z


def cyclic(n, M, E):
    # A_n avoids the two alternating orientations at every odd crossing.
    # X_n counts the avoiders with specified lower gap {0,1} occupied.
    avoiding = M[n] + 2*(-1)**n
    offset = (-1)**n
    for j in range(1,n):
        for k in range(1,min(j,n-j)+1):
            runs = exact_quotient(n*comb(j-1,k-1)*comb(n-j-1,k-1),k)
            first = exact_quotient(runs*j,n)
            previous_only = exact_quotient(runs*k,n)
            neither = runs-first-previous_only
            signs = (-1)**j * 2**(k-1)
            avoiding += signs*2*runs*M[n-j]
            offset += signs*(first*M[n-j] + (previous_only+2*neither)*E[n-j-1])
    lower = -offset + (avoiding+n-1)//n
    upper = -offset + avoiding//4
    assert 0 <= lower <= upper
    return {"N":n, "A_N":avoiding, "X_N_minus_E_N_minus_1":offset,
            "lower":lower, "upper":upper, "width":upper-lower}


@cache
def banks(n):
    if n == 0:
        return ((),)
    out = []
    for k in range(n):
        partner = 2*k+1
        for inside in banks(k):
            for outside in banks(n-k-1):
                out.append((partner, *(v+1 for v in inside), 0,
                            *(v+partner+1 for v in outside)))
    return tuple(out)


def literal(n):
    size = 2*n
    rows = []
    for bank in banks(n):
        left = sum(1 << i for i in range(n) if bank[2*i+1] == 2*i)
        right = sum(1 << i for i in range(n) if bank[2*i+1] == (2*i+2)%size)
        rows.append((bank,left,right))
    count = fixed = 0
    for top, a, b in rows:
        for bot, c, d in rows:
            if a & d or b & c:
                continue
            i, steps = 0, 0
            while True:
                i = top[bot[i]]
                steps += 1
                if i == 0:
                    break
            if steps == n:
                count += 1
                fixed += bot[0] == 1
    return count, fixed


def linear_residual(N, degree, sequence):
    total = sequence[degree]
    for j in range(1,N+1):
        sets = sum(2**k*comb(j-1,k-1)*comb(N-j+1,k)
                   for k in range(1,min(j,N-j+1)+1))
        total += (-1)**j * sets * sequence[degree-j]
    return total


def main():
    M = table(SOURCES[0])
    E = {m//2:v for m,v in table(SOURCES[1]).items() if m%2==0}
    E[30], E[31] = (int(json.loads(p.read_bytes())["open_count"]) for p in SOURCES[2:])
    records = {n:cyclic(n,M,E) for n in range(2,34)}
    linear = {n:linear_residual(n-1,n,M) for n in range(1,34)}
    for n,row in records.items():
        a, offset = row["A_N"], row["X_N_minus_E_N_minus_1"]
        assert a == linear[n]-2*sum(linear[n-j] for j in range(1,n,2))+2*(-1)**n
        if n-1 in E:
            x = E[n-1]+offset
            assert a <= n*x and 4*x <= a
            row["X_N"] = x
        if n <= 8:
            assert literal(n) == (a, row["X_N"])
    last = records[33]
    moduli = (2**30-1,2**30-3,2**30-5)
    assert all(gcd(p,q)==1 for p,q in combinations(moduli,2))
    assert all(gcd(p,64)==1 for p in moduli)
    assert prod(moduli)>last["width"] and max(p*q for p,q in combinations(moduli,2))<last["width"]
    out = {
        "python":platform.python_version(), "conventions":"labelled, distinguished banks, odd centers",
        "sources_sha256":{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest()
                          for p in [Path(__file__),*SOURCES]},
        "literal_pair_enumeration_orders":[2,3,4,5,6,7,8],
        "generating_series_coefficient_checks_through":33,
        "known_open_values_contained_through_crossings":62,
        "cyclic_certificates":list(records.values()), "open64":last,
        "crt_example":{"moduli":moduli, "product":prod(moduli),
                       "width_bits":last["width"].bit_length(),
                       "residues_computed":False},
    }
    OUT.write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(last,indent=2))


if __name__ == "__main__":
    main()
