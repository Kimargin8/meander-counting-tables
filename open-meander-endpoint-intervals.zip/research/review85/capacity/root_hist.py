"""Two-parameter circular irreducible root histogram over physical odd sites."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / 'research/review84/open64'
OUT = ROOT / 'output/research85/capacity'
sys.path.insert(0, str(OLD/'nc-join'))
import capacities


def eval_rows(rows, x, b):
    result = [[]]
    for n, row in enumerate(rows[1:], 1):
        coefficients = Counter()
        for (single, double), count in row.items():
            coefficients[2*n-single-2*double] += count*(x-1)**single*(1+b-2*x)**double
        result.append([(d,c) for d,c in coefficients.items() if c])
    return result


def evaluate(line, circle, x, b):
    nmax=len(line)-1
    linear=eval_rows(line,x,b)
    cyclic=eval_rows(circle,x,b)
    powers=[[1]+[0]*nmax for _ in range(2*nmax+1)]
    F=[1]+[0]*nmax
    target=[0]*(nmax+1)
    for n in range(1,nmax+1):
        def subs(rows):
            return sum(v*powers[d][n-k] for k in range(1,n+1) for d,v in rows[k])
        F[n]=subs(linear)
        target[n]=subs(cyclic)-2*(1+b-2*x)*F[n-1]-(6*x-4-b)*int(n==1)-2*(1-x)*powers[1][n-1]
        powers[1][n]=-sum(F[i]*powers[1][n-i] for i in range(1,n+1))
        for d in range(2,len(powers)):
            powers[d][n]=sum(powers[1][i]*powers[d-1][n-i] for i in range(n+1))
    return target


def make(maximum=38):
    line,circle=capacities.moments(maximum)
    # Evaluate a polynomial in b in a base exceeding the even unrestricted
    # Catalan-square bound, including the x weights for interpolation.
    width=(16**maximum*(maximum+1)**maximum).bit_length()+1
    mask=(1<<width)-1
    samples=[evaluate(line,circle,x,1<<width) for x in range(maximum+1)]
    out={}
    for n in range(2,maximum+1):
        hist={}
        for double in range(n+1):
            v=[(q[n] >> (width*double)) & mask for q in samples[:n-double+1]]
            coefficients=capacities.interpolate(v)
            assert min(coefficients)>=0
            hist[double]=coefficients
        assert (samples[0][n] >> (width*(n+1)))==0
        out[n]=hist
    prior=ROOT/'output/research84/open64/nc-join/order-38.json'
    known=json.loads(prior.read_bytes())['histograms']
    assert all(h[0]==known[str(n)] for n,h in out.items())
    outputs={'root_histograms':out, 'numeral_width':width,
             'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest()
                        for p in (Path(__file__), Path(capacities.__file__),prior)}}
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/f'roots-{maximum}.json').write_text(json.dumps(outputs,separators=(',',':'))+'\n',encoding='utf8')


if __name__=='__main__':
    make(int(sys.argv[1]) if len(sys.argv)>1 else 38)
