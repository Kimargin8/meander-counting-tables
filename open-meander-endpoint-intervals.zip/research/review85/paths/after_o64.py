"""Verify the frozen prediction and propagate the new exact input."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from predict import ROOT, inputs, enclose, catalogue_from_inputs


def main():
    proof = ROOT / "output/research85/pilot/progress.json"
    audit = ROOT / "output/research85/capacity/open-receipts.json"
    frozen = ROOT / "output/research85/paths/filtered.json"
    residues = ROOT / "output/research85/pilot/mod4-19.json"
    def read(path):
        return json.loads(path.read_bytes())
    left, right = read(proof), read(audit)
    assert left["complete"] and right["complete"]
    exact = int(left["open_count"])
    assert int(right["open_count"]) == exact
    assert int(left["certified_partial_numerator"]) == 64 * exact
    data = read(frozen)
    earlier = {r["crossings"]: r for r in data["forecasts"]}
    before = earlier[64]
    assert before["lower"] <= exact <= before["upper"]
    mod = {row["crossings"]: row["residue"] for row in read(residues)["rows"] + read(residues)["odd_rows"]}
    assert mod[64] == exact % 4
    closed, opened = inputs()
    assert len(opened) == 32
    opened.append(exact)
    tiles, short_edges = catalogue_from_inputs(closed, opened, 33)
    caps = {int(k): v for k, v in data["histograms"].items()}
    current, _ = enclose(closed, opened, tiles, short_edges, 37, caps)
    rows = []
    for row in current:
        q = row["crossings"]
        old = earlier[q]
        low = max(row["lower"], old["lower"])
        high = min(row["upper"], old["upper"])
        low += (mod[q] - low) % 4
        high -= (high - mod[q]) % 4
        assert 0 < low <= high and high-low <= old["width"]
        rows.append(dict(crossings=q, lower=low, upper=high, modulus=4, residue=mod[q],
                         width_over_previous=str(Fraction(high-low,old["width"])),
                         relative_width=str(Fraction(high-low,low))))
    result = dict(observed_crossings=64, observed_count=str(exact),
                  prospective_lower=before["lower"], prospective_upper=before["upper"],
                  position_within_original_interval=str(Fraction(exact-before["lower"],before["width"])),
                  updated_with_open_counts_through=64, catalogue_through=33, forecasts=rows,
                  sources={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest()
                           for p in [proof,audit,frozen,residues,Path(__file__)]})
    out = frozen.with_name("after-o64.json")
    out.write_text(json.dumps(result, indent=2)+"\n")
    print("O64",exact,"position",float(Fraction(result["position_within_original_interval"])))
    print([(r["crossings"],round(100*float(Fraction(r["relative_width"])),7)) for r in rows])


if __name__ == "__main__":
    main()
