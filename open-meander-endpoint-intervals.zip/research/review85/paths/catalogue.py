"""Minimal aligned end-to-end intervals in one oriented meander path."""
from collections import Counter
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/"research/review84/open64"))
from circle33 import banks


def walk(top, bottom):
    v=0
    order=[v]
    while True:
        v=(bottom if len(order)%2 else top)[v]
        if v<0:
            return order
        order.append(v)


def short_block(positions, left, right):
    a,b=sorted((positions[left],positions[right]))
    return b-a==right-left and all(a<p<b for p in positions[left+1:right])


def primitive_catalogue(n):
    total=ears=0
    by_ears=Counter()
    tops=[(-1,)+tuple(p+1 for p in matching) for matching in banks(n)]
    for matching in banks(n):
        bot=matching+(-1,)
        for top in tops:
            order=walk(top,bot)
            if len(order)!=2*n+1:
                continue
            total+=1
            e=sum(abs(a-b)==1 for a,b in zip(order,order[1:]))
            ears+=e
            pos=[0]*(2*n+1)
            for i,v in enumerate(order):
                pos[v]=i
            if any(short_block(pos,l,r) for l in range(0,2*n,2)
                   for r in range(l+2,2*n+1,2) if r-l<2*n):
                continue
            by_ears[e]+=1
    return total,ears,by_ears


if __name__=="__main__":
    for k in range(1,int(sys.argv[1])+1):
        print(k, primitive_catalogue(k),flush=True)
