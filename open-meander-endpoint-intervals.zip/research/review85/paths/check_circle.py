"""Independent literal crossing test on every pair of two closed banks."""
from pathlib import Path
from hashlib import sha256
import json

from catalogue import ROOT,banks
from predict import inputs,catalogue_from_inputs,model


def direct(n):
    size=2*n
    sides=[]
    for matching in banks(n):
        left=right=0
        for k in range(1,n):
            for start in range(n):
                labels=[(2*start+j)%size for j in range(2*k+1)]
                inside=set(labels)
                out=[v for v in labels if matching[v] not in inside]
                bit=1<<((k-1)*n+start)
                if out==[labels[0]]:
                    left|=bit
                if out==[labels[-1]]:
                    right|=bit
        sides.append((matching,left,right))
    totals=[[0,0] for _ in range(n)]
    for lower,lo_l,lo_r in sides:
        for upper,hi_l,hi_r in sides:
            v=0
            for steps in range(1,n+1):
                v=upper[lower[v]]
                if v==0:
                    break
            if steps!=n:
                continue
            matches=(lo_l&hi_r)|(lo_r&hi_l)
            shortest=1+((matches&-matches).bit_length()-1)//n if matches else n
            for k in range(shortest):
                totals[k][0]+=1
                totals[k][1]+=int(lower[0]==1)
    return totals


def main():
    M,E=inputs()
    T,U=catalogue_from_inputs(M,E,8)
    comparisons=[]
    for n in range(2,9):
        brute=direct(n)
        for k in range(1,n):
            A,base,kernels=model(M,T[:k+1],U[:k+1],n)
            xs={}
            for m in range(n):
                xs[m+1]=E[m]-base[m]-sum(kernels[j][m]*v for j,v in xs.items())
            assert brute[k]==[A[n],xs[n]],(n,k,brute[k],A[n],xs[n])
            comparisons.append(dict(n=n,k=k,avoidance=A[n],marked=xs[n]))
    out=ROOT/'output/research85/paths/direct-circle.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(dict(checks=comparisons,closed_pairs_examined=sum(len(banks(n))**2 for n in range(2,9)),
                                  source_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
    print('direct counts:',len(comparisons))


if __name__=='__main__':
    main()
