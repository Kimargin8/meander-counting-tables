"""Build or check the offline reading copy for the interval paper."""
from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile
from zipfile import ZIP_DEFLATED,ZipFile

ROOT=Path(__file__).resolve().parents[3]
CODE='research/review85/paths/'
OUT='output/research85/paths/'
OLD='output/research84/open64/'
OLD_CODE='research/review84/open64/'
BASE=['input-provenance.json','references/oeis/2026-11-15/b005315.txt','references/oeis/2026-11-15/b005316.txt',
      'output/research80/open-ear/marked-groups-n31/result.json','output/research83/open62/result.json',
      OLD+'circular-note/later-terms.json',OLD+'nc-join/forecasts.json',OLD+'nc-join/order-38.json',
      OLD_CODE+'circle33.py',OLD_CODE+'circular-note/check_inverse.py',OLD_CODE+'circular-note/forecast.py',
      OLD_CODE+'cyclic-cap/check.py',OLD_CODE+'nc-join/capacities.py']
RUNS=[
    (CODE+'predict.py',OUT+'intervals.json'),
    (CODE+'check_circle.py',OUT+'direct-circle.json'),
    ('research/review85/capacity/root_hist.py','output/research85/capacity/roots-38.json'),
    (CODE+'filtered.py',OUT+'filtered.json'),
    (CODE+'check_hist.py',OUT+'direct-hist.json'),
    (CODE+'horizon.py',OUT+'horizon.json'),
    (CODE+'after_o64.py',OUT+'after-o64.json')]
EXTRA=[CODE+'paths.tex',OUT+'paths.pdf',CODE+'catalogue.py',CODE+'reading.py',CODE+'reading-guide.md',
       'output/research85/capacity/stack-14.json','output/research77/window/k16q1f.json',
       'output/research85/graphs/folded-16-check.json',
       'output/research85/pilot/progress.json','output/research85/capacity/open-receipts.json',
       'output/research85/pilot/mod4-19.json']


def math_only(record):
    if isinstance(record,dict):
        return {k:math_only(v) for k,v in record.items()
                if k!='python' and 'sha256' not in k and k not in ('inputs','sources')}
    if isinstance(record,list):
        return [math_only(v) for v in record]
    return record


def run(base):
    for script,receipt in RUNS:
        expected=math_only(json.loads((base/receipt).read_bytes()))
        subprocess.run([sys.executable,'-B',script],cwd=base,check=True,stdout=subprocess.PIPE)
        actual=math_only(json.loads((base/receipt).read_bytes()))
        if actual!=expected:
            raise ValueError(f'Disagreement in {receipt}')
        print('verified',script,flush=True)


def verify():
    hashes=json.loads((ROOT/'SHA256SUMS.json').read_bytes())
    with tempfile.TemporaryDirectory() as tmp:
        stage=Path(tmp)
        for name,digest in hashes.items():
            if sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
                raise ValueError(name)
            new=stage/name
            new.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/name,new)
        run(stage)


if __name__=='__main__':
    verify()
