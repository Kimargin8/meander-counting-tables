"""Compare weighted contractions with literal NC joins and actual interval paths."""
from pathlib import Path
from hashlib import sha256
import json
import sys

from filtered import ROOT,histogram
from catalogue import banks,primitive_catalogue


def direct_hist(n,cutoffs):
    size=2*n
    # Stable even intervals, and odd intervals with one exposed site at an end.
    intervals=[tuple(range(i,i+m)) for m in range(2,size,2) for i in range(size-m+1)]
    paths=[[(2*i+j)%size for j in range(2*k+1)] for k in range(1,max(cutoffs)+1) for i in range(n)]
    sides=[]
    for p in banks(n):
        stable=sum(1<<i for i,I in enumerate(intervals) if all(p[v] in I for v in I))
        left=right=0
        for i,I in enumerate(paths):
            out=[v for v in I if p[v] not in I]
            if out==[I[0]]:
                left|=1<<i
            if out==[I[-1]]:
                right|=1<<i
        ears=sum((p[v]-v)%size in (1,size-1) for v in range(1,size,2))
        sides.append((p,stable,left,right,ears))
    hist={k:[0]*(n+1) for k in cutoffs}
    for top,a,left,right,e in sides:
        for bot,b,otherleft,otherright,g in sides:
            if a&b:
                continue
            candidates=(left&otherright)|(right&otherleft)
            if candidates&((1<<n)-1):
                continue
            shortest=n
            while candidates:
                bit=candidates&-candidates
                candidates^=bit
                i=bit.bit_length()-1
                I=paths[i]
                v=I[0]
                for j in range(1,len(I)):
                    upper_first=not(left&bit)
                    v=(top if bool(j%2)==upper_first else bot)[v]
                    if v==I[-1]:
                        if j==len(I)-1:
                            shortest=1+i//n
                        break
                if shortest<n:
                    break
            for k in cutoffs:
                if k<shortest:
                    hist[k][e+g]+=1
    return hist


def main():
    root_file=ROOT/'output/research85/capacity/roots-38.json'
    roots=json.loads(root_file.read_bytes())['root_histograms']
    roots={n:{str(i):row[str(i)] for i in range(int(n)+1)} for n,row in roots.items()}
    tiles=[primitive_catalogue(i)[2] for i in range(1,9)]
    theoretical={k:histogram(roots,tiles[:k],9) for k in range(1,9)}
    records={}
    for n in range(2,10):
        direct=direct_hist(n,list(range(1,n)))
        assert all(h==theoretical[k][n] for k,h in direct.items()),(n,direct)
        records[n]=direct
    outfile=ROOT/'output/research85/paths/direct-hist.json'
    outfile.write_text(json.dumps(dict(checked=records,pairs_examined=sum(len(banks(n))**2 for n in range(2,10)),
                         code_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
    print('validated',sum(len(t) for t in records.values()),'literal histograms')


if __name__=='__main__':
    main()
