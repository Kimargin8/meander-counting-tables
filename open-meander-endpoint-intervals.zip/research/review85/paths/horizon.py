"""Rational bracketing for the sufficient proportion of known even open orders."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
from predict import ROOT,comp,inputs,main_f,times


def certificate(coeff,upper_mu,alpha):
    def functions(r):
        t=sum(a*r**i for i,a in enumerate(coeff))
        rd=sum(i*a*r**i for i,a in enumerate(coeff))
        return r*(1-t)/(1+t),1-2*rd/(1-t*t),t
    floor,ceiling=F(9,100),F(117,1000)
    assert functions(floor)[0]<1/upper_mu and functions(ceiling)[0]>1/F('11.38')
    assert functions(ceiling)[1]>0 and functions(ceiling)[2]<1
    for _ in range(32):
        mid=(floor+ceiling)/2
        if functions(mid)[0]<1/upper_mu:
            floor=mid
        else:
            ceiling=mid
    # kappa is decreasing in r while T>=0 and T<1.
    assert functions(floor)[1]<alpha
    return dict(upper_growth=str(upper_mu),lower_growth="569/50",r_at_upper_bracket=[str(floor),str(ceiling)],
                kappa_upper_decimal=float(functions(floor)[1]),certified_sufficient_alpha=str(alpha))


def main():
    p=ROOT/'output/research85/paths/intervals.json'
    t=json.loads(p.read_bytes())['tile_counts_per_orientation']
    result={label:certificate(t[:n+1],F(mu),F(bound)) for label,n,mu,bound in [
        ('six_types_of_sizes',6,'12.901','0.75'),('size_32_albert_paterson',32,'12.901','0.746'),
        ('size_32_caroppo_et_al',32,'12.806','0.7422'),
        ('size_32_stack_certificate',32,'12.674260','0.7365'),
        ('size_32_published_width16',32,'12.648387','0.7354')]}
    stack=ROOT/'output/research85/capacity/stack-14.json'
    witness=json.loads(stack.read_bytes())
    rate=F(witness['rate_numerator'],witness['rate_denominator'])
    assert rate*(rate+1)/(rate-1)<F('12.674260')
    previous=ROOT/'output/research77/window/k16q1f.json'
    prior=json.loads(previous.read_bytes())
    assert F(prior['upper'],prior['den'])**2 < F('12.648387')
    # The unmarked catalogue needs closed counts only. These six extra sizes
    # are available for the asymptotic statement before their open weights.
    closed,_=inputs()
    for k in range(len(t),39):
        trial=t+[0]
        f,_,_=main_f(trial)
        t.append(comp(closed[:k+1],f)[k]+times(trial,trial)[k])
    result['size_38_published_width16']=certificate(t,F('12.648387'),F('0.7353'))
    graph=ROOT/'output/research85/graphs/folded-16-check.json'
    verified=json.loads(graph.read_bytes())
    assert verified['failed_rows']==0 and verified['checked_rows']==620537812 and verified['equal_rows']>0
    r=F(verified['rate_numerator'],verified['rate_denominator'])
    growth=r*(r+1)/(r-1)
    result['size_32_parity_width16']=certificate(t[:33],growth,F('0.7352'))
    result['size_38_parity_width16']=certificate(t,growth,F('0.7351'))
    for label,row in result.items():
        print(label,row['kappa_upper_decimal'],row['certified_sufficient_alpha'])
    out=p.with_name('horizon.json')
    out.write_text(json.dumps(dict(bounds=result,input_sha256=sha256(p.read_bytes()).hexdigest(),
                        stack_sha256=sha256(stack.read_bytes()).hexdigest(),published_width16_sha256=sha256(previous.read_bytes()).hexdigest(),
                        parity_width16_sha256=sha256(graph.read_bytes()).hexdigest(),
                        code_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')


if __name__=='__main__':
    main()
