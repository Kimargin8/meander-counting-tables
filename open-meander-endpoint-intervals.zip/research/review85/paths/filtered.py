"""Exclude connected interval paths in the irreducible capacity histogram."""
from fractions import Fraction
from hashlib import sha256
from math import lcm
from pathlib import Path
import json
import sys

from catalogue import ROOT,primitive_catalogue
from predict import inputs,enclose,catalogue_from_inputs,plus,scale,times,inv,diff,shift,padded
sys.path.insert(0,str(ROOT/'research/review85/capacity'))
from root_hist import capacities


def weighted_cap(roots,tiles,y,L):
    # Signed tile weights for one orientation.
    B=[0]+[-sum(v*y**i for i,v in row.items()) for row in tiles]
    B=padded(B,L)
    unit=padded([1],L)
    seq=inv(plus(unit,scale(B,-1)))
    run=times(B,seq)
    h0=plus(unit,scale(run,2))
    h1=plus(scale(unit,y),scale(run,1+y))
    h2=plus(scale(unit,y*y),scale(run,1+y*y))
    # All three are affine in R=B/(1-B). Expand the product in powers
    # of R using a recurrence for a product of three linear polynomials.
    powers=[unit]
    for _ in range(L):
        powers.append(times(powers[-1],run))
    common=lcm(*range(1,L+1))
    before=scale(shift(h0),common*y*y)
    for m in range(2,L+1):
        top=L-m
        coeff=[0]*(top+1)
        for d,row in enumerate(roots[str(m)].values()):
            for s,count in enumerate(row):
                if not count:
                    continue
                # Factor by the number of unoccupied, single, and double sites.
                p=[1]
                for num,constant,slope in [(m-s-d,1,2),(s,y,1+y),(d,y*y,1+y*y)]:
                    for _ in range(num):
                        p=([constant*p[0]]+[constant*p[j]+slope*p[j-1] for j in range(1,len(p))]
                           +[slope*p[-1]])[:top+1]
                for i,v in enumerate(p):
                    coeff[i]+=count*v
        for i,v in enumerate(coeff):
            if v:
                for j in range(i,top+1):
                    before[m+j]+=(common//m)*v*powers[i][j]
    packed=scale(shift(times(diff(B),seq)),2)
    ans=[]
    for n,v in enumerate(before):
        a,r=divmod(n*v,common)
        ans.append(Fraction(n*v,common)+packed[n] if r else a+packed[n])
    return ans


def histogram(roots,tiles,maximum):
    sample=[weighted_cap(roots,tiles,i,maximum) for i in range(maximum+2)]
    rows={}
    for n in range(len(tiles)+1,maximum+1):
        values=[sample[i][n] for i in range(n+1)]
        assert all(isinstance(i,int) for i in values)
        h=capacities.interpolate(values)
        assert min(h)>=0 and sum(v*(maximum+1)**i for i,v in enumerate(h))==sample[-1][n]
        rows[n]=h
    return rows


def main():
    M,E=inputs()
    root_file=ROOT/'output/research85/capacity/roots-38.json'
    roots=json.loads(root_file.read_bytes())['root_histograms']
    # JSON object ordering is immaterial to the class with d double sites.
    roots={n:{str(i):row[str(i)] for i in range(int(n)+1)} for n,row in roots.items()}
    tiles=[primitive_catalogue(i)[2] for i in range(1,9)]
    T,U=catalogue_from_inputs(M,E,32)
    assert all(sum(hist.values())==T[i] and sum(j*v for j,v in hist.items())==U[i]
               for i,hist in enumerate(tiles,1))
    caps=histogram(roots,tiles,38)
    old_file=ROOT/'output/research84/open64/nc-join/order-38.json'
    old=json.loads(old_file.read_bytes())['histograms']
    assert all(all(a<=b for a,b in zip(row,old[str(n)])) for n,row in caps.items())
    rows,_=enclose(M,E,T,U,37,caps)
    holdouts=0
    for end in range(3,31):
        k=end+1
        subT,subU=catalogue_from_inputs(M,E[:end+1],k)
        forecasts,_=enclose(M,E[:end+1],subT,subU,min(end+6,31),caps if k>=len(tiles) else {})
        for r in forecasts:
            assert r['lower']<=E[r['crossings']//2]<=r['upper']
            holdouts+=1
    assert holdouts==153
    for r in rows:
        r['relative_width']=str(Fraction(r['width'],r['lower']))
        print(r['crossings'],r['lower'],r['upper'],float(Fraction(r['relative_width']))*100)
    sources=[Path(__file__),root_file,old_file,Path(__file__).with_name('predict.py'),
             Path(__file__).with_name('catalogue.py')]
    out=ROOT/'output/research85/paths/filtered.json'
    out.write_text(json.dumps(dict(holdouts=holdouts,histograms=caps,forecasts=rows,
        tile_histograms=tiles,sha256={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest()
                                     for p in sources}),indent=2)+'\n')


if __name__=='__main__':
    main()
