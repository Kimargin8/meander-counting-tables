"""Formal contractions of aligned, end-to-end minimal paths. Exact arithmetic."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import platform
import sys

from catalogue import ROOT, primitive_catalogue
sys.path.insert(0,str(ROOT/"research/review84/open64/circular-note"))
import forecast


def times(a,b):
    return [sum(a[i]*b[k-i] for i in range(k+1)) for k in range(len(a))]


def plus(a,b):
    return [x+y for x,y in zip(a,b)]


def scale(a,v):
    return [v*x for x in a]


def inv(a):
    assert a[0]==1
    b=[1]
    for k in range(1,len(a)):
        b.append(-sum(a[i]*b[k-i] for i in range(1,k+1)))
    return b


def comp(a,b):
    assert b[0]==0
    result=[0]*len(b)
    for v in reversed(a):
        result=times(result,b)
        result[0]+=v
    return result


def diff(a):
    return [k*a[k] for k in range(1,len(a))]+[0]


def shift(a):
    return [0]+a[:-1]


def padded(a,n):
    return (list(a)+[0]*(n+1))[:n+1]


def main_f(t):
    one=padded([1],len(t)-1)
    hb=inv(plus(one,t))
    h=times(plus(one,scale(t,-1)),hb)
    return shift(h),h,hb


def catalogue_from_inputs(M,E,kmax):
    # The complete linear path class has no nonempty object which avoids
    # every minimal tile, including the whole path itself when it is minimal.
    T=[0]
    for k in range(1,kmax+1):
        trial=T+[0]
        f,_,_=main_f(trial)
        T.append(comp(M[:k+1],f)[k]+times(trial,trial)[k])
    f,h,hb=main_f(T)
    n=kmax
    one=padded([1],n)
    J=inv(plus(one,scale(times(T,T),-1)))
    Mlin=comp(M[:n+1],f)
    assert Mlin==plus(T,scale(times(T,T),-1))
    # Negative derivative with respect to marked internal ears.
    Hb2=times(hb,hb)
    W=plus(Hb2,plus(scale(times(times(T,times(J,J)),Mlin),-2),
                     scale(shift(times(times(J,Hb2),comp(diff(M[:n+1]),f))),2)))
    Ea=padded(E,n)
    ext=scale(shift(times(Hb2,plus(comp(Ea,f),
                     shift(times(plus(one,h),comp(diff(Ea),f)))))),2)
    U=times(ext,inv(W))
    assert all(v>=0 and v%2==0 for v in U)
    return T,U


def inverse_series(t,n):
    # s=y*(1+T(s))/(1-T(s)). Coefficients determined triangularly.
    one=padded([1],n)
    t=padded(t,n)
    phi=times(plus(one,t),inv(plus(one,scale(t,-1))))
    # Explicit powers of s also give the Lagrange triangular coefficients.
    powers=[[0]*(n+1) for _ in range(n+1)]
    powers[0][0]=1
    s=[0]*(n+1)
    for k in range(1,n+1):
        s[k]=sum(phi[i]*powers[i][k-1] for i in range(k))
        powers[1][k]=s[k]
        for j in range(2,k+1):
            powers[j][k]=sum(s[i]*powers[j-1][k-i] for i in range(1,k-j+2))
    return s,phi,powers


def model(M,T,U,n):
    one=padded([1],n)
    t=padded(T,n)
    f,h,hb=main_f(t)
    # A_N: configurations with a hole plus fully tiled circles.
    A=plus(times(plus(one,shift(times(diff(h),inv(h)))),comp(M,f)),
           scale(shift(times(diff(t),hb)),-2))
    s,phi,powers=inverse_series(T,n)
    factor=plus(one,comp(t,s))
    # Divide U(s) by s in coefficient space before composition.
    eover=comp(padded([v//2 for v in U[1:]],n),s)
    base=plus(eover,times(times(eover,inv(plus(one,scale(comp(t,s),-1)))),padded(M,n)))
    kernels={j:times(factor,powers[j-1]) for j in range(1,n+1)}
    assert all(v>=0 for row in kernels.values() for v in row)
    return A,base,kernels


def enclose(M,known,T,U,last,caps=None):
    A,base,kernels=model(M,T,U,last+1)
    xs={}
    rows=[]
    for m in range(last+1):
        N=m+1
        l=h=base[m]
        for j,(a,b) in xs.items():
            l+=a*kernels[j][m]
            h+=b*kernels[j][m]
        if m<len(known):
            assert l==h
            x=known[m]-l
            if N>=len(T):
                assert A[N]<=N*x and 4*x<=A[N]
            xs[N]=(x,x)
        else:
            assert N>=len(T)
            a,b=(A[N]+N-1)//N,A[N]//4
            if caps is not None and N in caps:
                def extreme(indices):
                    remain=A[N]
                    total=0
                    for idx in indices:
                        take=min(remain,caps[N][idx])
                        remain-=take
                        total+=take*idx
                    assert remain==0
                    return total
                a=max(a,(extreme(range(N+1))+4*N-1)//(4*N))
                b=min(b,extreme(reversed(range(N+1)))//(4*N))
            xs[N]=(a,b)
            l+=xs[N][0]
            h+=xs[N][1]
            assert 0<l<=h
            rows.append(dict(crossings=2*m,lower=l,upper=h,width=h-l,
                             avoidance=A[N],X_lower=xs[N][0],X_upper=xs[N][1]))
    return rows,xs


def inputs():
    closed=forecast.table(forecast.CLOSED)
    M=[0]+[closed[k] for k in range(1,max(closed)+1)]
    earlier=forecast.table(forecast.OPEN)
    E=[1]+[earlier[2*j] for j in range(1,30)]
    E.extend(int(json.loads(p.read_bytes())['open_count']) for p in (forecast.OPEN60,forecast.OPEN62))
    return M,E


def main():
    M,E=inputs()
    T,U=catalogue_from_inputs(M,E,32)
    direct={}
    for k in range(1,7):
        total,ears,hist=primitive_catalogue(k)
        assert (total,ears)==(M[k],(4*k-2)*E[k-1])
        assert (T[k],U[k])==(sum(hist.values()),sum(j*v for j,v in hist.items()))
        direct[k]=dict(all=total,ear_sum=ears,primitive_histogram=hist)
    baseline=json.loads((ROOT/'output/research84/open64/nc-join/forecasts.json').read_bytes())['forecasts']
    elementary=json.loads(forecast.OUT.read_bytes())['elementary_forecasts']
    models={}
    for k in (1,2,3,4,6,8,12,16,24,32):
        rows,_=enclose(M,E,T[:k+1],U[:k+1],37)
        for row,old in zip(rows,baseline):
            row['relative_width']=str(Fraction(row['width'],row['lower']))
            row['width_over_stage84_best']=str(Fraction(row['width'],int(old['width'])))
        models[k]=rows
    assert all(r['lower']==int(s['lower']) and r['upper']==int(s['upper'])
               for r,s in zip(models[1],elementary))
    holdouts=0
    for end in range(3,31):
        k=end+1
        # Tile weights use only closed inputs and strictly earlier open values.
        subT,subU=catalogue_from_inputs(M[:min(end+7,32)+1],E[:end+1],k)
        rows,_=enclose(M[:min(end+6,31)+2],E[:end+1],subT,subU,min(end+6,31))
        for row in rows:
            assert row['lower']<=E[row['crossings']//2]<=row['upper']
            holdouts+=1
    assert holdouts==153
    outfile=ROOT/'output/research85/paths/intervals.json'
    outfile.parent.mkdir(parents=True,exist_ok=True)
    sources=[Path(__file__),Path(__file__).with_name('catalogue.py'),forecast.CLOSED,forecast.OPEN,
             forecast.OPEN60,forecast.OPEN62]
    result=dict(tile_counts_per_orientation=T,short_arch_sums_per_orientation=U,
                tested_withheld=holdouts,literal_catalogues=direct,models=models,
                python=platform.python_version(),
                sha256={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in sources})
    outfile.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    for k,rows in models.items():
        print(k,[(row['crossings'],round(float(Fraction(row['width_over_stage84_best'])),6)) for row in rows])
    print('O64:',models[32][0])


if __name__=='__main__':
    main()
