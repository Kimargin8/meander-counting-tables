# Endpoint intervals and the prediction of open meander numbers

Iaroslav Argunov · Version 1.0.0. [Permanent record](https://doi.org/10.5281/zenodo.24516884).

Iaroslav Argunov. Computational supplement, November 2026.

The manuscript is in `output/research85/paths/paths.pdf`. The table of six integer intervals is in `output/research85/paths/filtered.json`. All percentages in the manuscript use the lower endpoint as denominator.

Extract the ZIP and run the following command from its root with a standard Python 3.12 or 3.13 installation.

~~~sh
python -B research/review85/paths/reading.py
~~~

The program verifies every file against its SHA-256 digest, repeats seven calculations in a temporary directory and compares their mathematical outputs. The package includes earlier closed and open numbers with their sources, the code for the two-variable histograms of noncrossing joins, and the radius bounds used in the theorem. At catalogue size 38 the direct width-16 certificate gives 73.53%. The companion paper on parity contraction improves the sufficient fraction to 73.51%. The 74.6% conclusion uses the Albert--Paterson bounds alone. [Published direct certificate and source](https://doi.org/10.5281/zenodo.24457226)

The first direct check tests circular marked and unmarked counts through eight. The second tests all 36 histograms for sizes two through nine, covering every ordered pair of noncrossing matchings at those sizes. The 153 withholding tests truncate the earlier open table before each predicted term. The original endpoints for 64 crossings are preserved in `filtered.json`. Two separate assemblies of the full count subsequently gave 411162873752534667276292731379. The final check uses this new input and the independently established residues to narrow the five later intervals, saved in `after-o64.json`.
