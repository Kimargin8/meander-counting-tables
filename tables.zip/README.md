# Enumeration tables for meandric systems

Iaroslav Argunov, 23 November 2026.

Each text file contains one pair of decimal integers per line giving the index and its value. The nine numbered files extend the tables in *The On-Line Encyclopedia of Integer Sequences* (OEIS) as retrieved on 23 November 2026. The final column identifies which positions were added in this release.

| File | Objects counted | Published prefix and source | Added positions |
| --- | --- | --- | --- |
| [b046726.txt](b046726.txt) | Semi-meanders by number of components | [A046726](https://oeis.org/A046726), 1–820, Andrew Howroyd | 821–903 |
| [b046721.txt](b046721.txt) | Semi-meanders with 2 components | [A046721](https://oeis.org/A046721), 2–40, Andrew Howroyd | 41–42 |
| [b046722.txt](b046722.txt) | Semi-meanders with 3 components | [A046722](https://oeis.org/A046722), 3–40, Andrew Howroyd | 41–42 |
| [b046723.txt](b046723.txt) | Semi-meanders with 4 components | [A046723](https://oeis.org/A046723), 4–40, Andrew Howroyd | 41–42 |
| [b046724.txt](b046724.txt) | Semi-meanders with 5 components | [A046724](https://oeis.org/A046724), 5–40, Andrew Howroyd | 41–42 |
| [b046725.txt](b046725.txt) | Semi-meanders with 6 components | [A046725](https://oeis.org/A046725), 6–40, Andrew Howroyd | 41–42 |
| [b060089.txt](b060089.txt) | Unidirectional open meandric systems | [A060089](https://oeis.org/A060089), 0–28, B. Bobier and J. Sawada, and 29–40, Andrew Howroyd | 41–43 |
| [b060111.txt](b060111.txt) | Bidirectional open meandric systems | [A060111](https://oeis.org/A060111), 0–27, B. Bobier and J. Sawada, and 28–40, Andrew Howroyd | 41–44 |
| [b301940.txt](b301940.txt) | Closed meanders with six digons and 2n crossings | [A301940](https://oeis.org/A301940), 3–35, Vincent Delecroix | 36–60 |

For a semi-meander of order n with k components, the index in the triangle is n(n+1)/2 + 1 − k. Orders 41 and 42 contribute 83 entries to the triangle. The ten additions to the five fixed-component tables are among those 83 entries. Unidirectional and bidirectional open systems can have several paths.

The nine numbered tables are distributed under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Each combines the credited OEIS prefix with the additional positions shown. The new portions were computed by Iaroslav Argunov. The source entries give the full histories of the sequences and their mathematics. [OEIS data license](https://oeis.org/wiki/The_OEIS_End-User_License_Agreement)

## Meandric systems without cluster cycles

[Terms 0–38](meandric-systems-without-cluster-cycles.txt) count ordered pairs of noncrossing perfect matchings on 2n linearly ordered sites in which the support of every connected component has a gap. The two banks are distinguished. The empty pair contributes one system at order zero.

Kargin defines a cluster cycle as one whose vertices are consecutive on the line (Definition 2.6). He derives occurrence probabilities for a fixed shape and joint occurrence probabilities at two positions for a prescribed cycle length (equations 7 and 8). This table counts systems avoiding cluster cycles of every shape and length simultaneously. Its coefficients use the published closed meander numbers and are independently checked by direct enumeration through order eight. [Kargin](https://arxiv.org/abs/2011.13449) · [Closed meander numbers](https://oeis.org/A005315)

The original cluster-cycle avoidance table is by Iaroslav Argunov and is distributed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

[SHA256SUMS](SHA256SUMS) gives the SHA-256 digest of the distribution files.
