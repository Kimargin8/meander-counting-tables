#define WINDOW_GRAPH_ONLY
#include "certify.cpp"

std::string decimal(Wide x) {
    std::string s;
    do {s.push_back(char('0'+x%10));x/=10;} while(x);
    std::reverse(s.begin(),s.end());
    return s;
}

int main(int argc,char**argv) {
    if(argc!=2) throw std::invalid_argument("k");
    int k=std::stoi(argv[1]);
    if(k<1||k>16) throw std::invalid_argument("k outside 1..16");
    Graph g(k,true);
    size_t n=g.rows.size();
    // Up to length 33 the number of words is at most 4^33 < 2^128.
    std::vector<Wide> v(n+1,1),w(n+1);v[n]=0;
    std::cout<<"{\"k\":"<<k<<",\"states\":"<<n<<",\"exact\":[\"1\"";
    for(int t=1;t<=2*k+1;++t) {
        for(size_t i=0;i<n;++i) {
            auto a=g.rows[i];w[i]=v[a[0]]+v[a[1]]+v[a[2]]+v[a[3]];
        }
        v.swap(w);
        std::cout<<",\""<<decimal(v[0])<<"\"";
    }
    std::cout<<"]}\n";
}
