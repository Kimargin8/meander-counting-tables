"""Verify the small certificate by default. Larger windows regenerate on request."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import tempfile

from horizon import count


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def run_json(command):
    return json.loads(subprocess.check_output([str(x) for x in command], text=True))


def binary(source, target):
    subprocess.run(["g++", "-std=c++20", "-O3", str(source), "-o", str(target)], check=True)


def exact_corollaries(radius, marked):
    r = Fraction(radius["upper"], radius["den"])
    q = Fraction(marked["p"], marked["q"])
    rq = Fraction(marked["upper"], marked["den"])
    lower = Fraction(12401248195833, 1058038773811)
    assert (rq**2/lower)**13 < q**7 and q**3 > 4
    assert r**2 < Fraction(12805332, 1000000)
    return str(r**2)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--width", type=int, default=9, choices=(9, 10, 12, 14, 15, 16))
    p.add_argument("--data", type=Path, default=Path(__file__).resolve().parent/"results")
    p.add_argument("--witness", type=Path, help="prefix of a supplied .states/.vector pair")
    args = p.parse_args()
    if not __debug__:
        raise RuntimeError("Run with normal Python assertions enabled.")
    source = Path(__file__).resolve().parent
    k = args.width
    tag = f'k{k}q159f' if k == 12 else f'k{k}q1f'
    metadata = read(args.data/(tag+".json"))
    audit_receipt = read(args.data/(tag+"-audit.json"))
    with tempfile.TemporaryDirectory() as scratch:
        work = Path(scratch)
        prefix = args.witness or work/"certificate"
        if args.witness is None:
            binary(source/"certify.cpp", work/"certify")
            regenerated = run_json([work/"certify", k, metadata["p"], metadata["q"],
                                    metadata["rounds"], metadata["den"], prefix, "--fold"])
            for label in ("upper", "den", "states", "v_empty", "v_min", "p", "q", "rounds", "folded"):
                assert regenerated[label] == metadata[label], label
        binary(source/"audit.cpp", work/"audit")
        checked = run_json([work/"audit", prefix, k, metadata["p"], metadata["q"],
                            metadata["upper"], metadata["den"], "--fold"])
        assert checked == audit_receipt
        if k == 16:
            for receipt in read(args.data/"k16-hashes.json"):
                filename = Path(str(prefix)+Path(receipt["file"]).suffix)
                digest = sha256()
                with filename.open("rb") as stream:
                    for block in iter(lambda: stream.read(1<<20), b""):
                        digest.update(block)
                assert digest.hexdigest() == receipt["sha256"]
        # A zero row must be rejected even if the remaining entries are unchanged.
        if k == 9:
            tightened = subprocess.run([work/"audit", prefix.resolve(), "9", "1", "1",
                                        str(metadata["upper"]-1), str(metadata["den"]), "--fold"],
                                       cwd=work, capture_output=True)
            assert tightened.returncode != 0 and b'failed upper comparison' in tightened.stderr
            damaged = work/"damaged"
            Path(str(damaged)+".states").write_bytes(Path(str(prefix)+".states").read_bytes())
            vector = bytearray(Path(str(prefix)+".vector").read_bytes())
            vector[:8] = bytes(8)
            Path(str(damaged)+".vector").write_bytes(vector)
            rejection = subprocess.run([work/"audit", damaged, "9", "1", "1", str(metadata["upper"]),
                                        str(metadata["den"]), "--fold"], cwd=work, capture_output=True)
            assert rejection.returncode != 0 and b'zero' in rejection.stderr
    for filename in ("horizon-two.json", "horizon-one.json", "horizon-closed.json"):
        known = read(args.data/filename)
        for index, number in enumerate(known["counts"][:13], known["offset"]):
            length = 2*index-1 if known["kind"] == "closed" else index
            assert count(length, known["kind"]) == number
    bound = exact_corollaries(read(args.data/"k9q1f.json"), read(args.data/"k12q159f.json"))
    print(json.dumps({"certificate": tag, "rows_verified": checked["states"],
                      "small_window_upper_exact": bound, "small_counts_pass": True,
                      "marked_inequalities_pass": True}))


if __name__ == "__main__":
    main()
