"""Validate the forgetting rule against cycles traced on the sites of literal words."""
from functools import cache
from itertools import product
from pathlib import Path
import json
import argparse
from automaton import graph

def contains_cycle(word):
    parent=list(range(len(word)))
    def root(i):
        while parent[i]!=i:
            i=parent[i]
        return i
    for bit in (1,2):
        opened=[]
        for i,letter in enumerate(word):
            if not letter&bit:
                opened.append(i)
            elif opened:
                a,b=root(i),root(opened.pop())
                if a==b:
                    return True
                parent[a]=b
    return False


def accepted(rows,word):
    state=0
    for c in word:
        state=rows[state][c]
        if state<0:
            return False
    return True


@cache
def dyck(n):
    if n==0:
        return ((),)
    return tuple((0,)+a+(1,)+b for i in range(n)
                 for a in dyck(i) for b in dyck(n-i-1))


def literals(destination, reference):
    ks=[1,2,3,4,8]
    graphs=[graph(k) for k in ks]
    unrestricted=[]
    for m in range(9):
        row=[0]*len(ks);exact=0
        for word in product(range(4),repeat=m):
            ok=not contains_cycle(word)
            flags=[accepted(g,word) for g in graphs]
            if sorted(flags,reverse=True)!=flags or flags[-1]!=ok:
                raise ValueError((word,flags,ok))
            row=[a+b for a,b in zip(row,flags)];exact+=ok
        unrestricted.append({"sites":m,"accepted":row,"without_cycle":exact})
    oeis={n:v for n,v in enumerate((1,1,2,8,42,262,1828,13820))}
    if reference is not None:
        oeis={int(k):int(v) for line in reference.read_text().splitlines()
              if line.strip() and not line.startswith("#") for k,v in [line.split()]}
    meanders=[]
    for n in range(1,8):
        total=0
        for a,b in product(dyck(n),repeat=2):
            w=tuple(2*i+j for i,j in zip(a,b))
            # A full double Dyck word ends in a simultaneous close. If the word
            # excluding that site has a cycle, the whole system is disconnected.
            if contains_cycle(w[:-1]):continue
            if any(not accepted(g,w[:-1]) for g in graphs):
                raise ValueError(("lost connected word",n,w))
            total+=1
        if total!=oeis[n]:raise ValueError((n,total,oeis[n]))
        meanders.append(total)
    out={"window_per_bank":ks,"arbitrary_words_by_length":unrestricted,
         "all_connected_through_order_7":meanders}
    destination.write_text(json.dumps(out,indent=2)+"\n",encoding="utf8")
    print(meanders,unrestricted[-1])


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--out",type=Path,default=Path("literal-check.json"))
    cli.add_argument("--connected-ref",type=Path)
    options=cli.parse_args()
    literals(options.out,options.connected_ref)
