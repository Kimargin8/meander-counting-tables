"""Finite window for the parity-restricted internal cycles of Caroppo et al., Sect. 5."""
from collections import deque
from fractions import Fraction
from itertools import product
import argparse
import gzip
import json
from pathlib import Path


def move(paths, letter, odd, k):
    # Entries are ordered by their oldest sites. The flag records that site's parity.
    remaining = []
    ends = {}
    for i,(a,b,parity) in enumerate(paths):
        if letter == 0:
            a += -1 if a < 0 else 1
            b += -1 if b < 0 else 1
        elif letter in (1,2):
            shift = 1 if letter == 1 else -1
            a,b = a+shift,b+shift
        elif a == -1 and b == 0:
            if odd and not parity:
                return None
            continue
        elif a in (-1,0) or b in (-1,0):
            near,other = (a,b) if a in (-1,0) else (b,a)
            ends[near] = (i, other+(1 if other < 0 else -1), parity)
            continue
        else:
            a += 1 if a < 0 else -1
            b += 1 if b < 0 else -1
        if -k <= a and b < k:
            remaining.append((i,a,b,parity))
    if letter == 0:
        remaining.append((len(paths),-1,0,odd))
    if len(ends) == 2:
        first,second = sorted(ends.values())
        a,b = sorted((first[1],second[1]))
        remaining.append((first[0],a,b,first[2]))
        remaining.sort()
    return tuple((a,b,p) for _,a,b,p in remaining)


def graph(k, maximum):
    states = {(True, ()): 0}
    pending = deque(states)
    rows, odd_phases = [], []
    while pending:
        odd, paths = pending.popleft()
        row = []
        for letter in range(4):
            result = move(paths, letter, odd, k)
            if result is None:
                row.append(-1)
                continue
            mirror = tuple((-1-b,-1-a,p) for a,b,p in result)
            nxt = (not odd, min(result,mirror))
            if nxt not in states:
                if len(states) >= maximum:
                    raise ValueError("state cap reached")
                states[nxt] = len(states)
                pending.append(nxt)
            row.append(states[nxt])
        rows.append(tuple(row)); odd_phases.append(odd)
    return rows,odd_phases,states


def bound(rows, odd_phases):
    v = [1 << 48]*len(rows) + [0]
    def apply(values):
        return [sum(values[i] for i in row) for row in rows] + [0]
    for _ in range(72):
        w = apply(apply(v))
        shift = max(0, max(w).bit_length() - 49)
        v = [x >> shift for x in w]
    w = apply(apply(v))
    if not min(v[:-1]):
        raise ValueError("zero weight")
    upper = max(Fraction(w[i],v[i]) for i,odd in enumerate(odd_phases) if odd)
    return upper,v[:-1]


def forbidden(word):
    # Physical graph on sites. Parities below refer to one-based site indices.
    adjacent = [[] for _ in word]
    for bit in (1,2):
        stack = []
        for i,letter in enumerate(word):
            if not letter & bit:
                stack.append(i)
            elif stack:
                j=stack.pop()
                adjacent[i].append(j); adjacent[j].append(i)
    todo = set(range(len(word)))
    while todo:
        part = [todo.pop()]
        for x in part:
            for y in adjacent[x]:
                if y in todo:
                    todo.remove(y);part.append(y)
        if (all(len(adjacent[x])==2 for x in part) and
                min(part)%2==1 and max(part)%2==0):
            return True
    return False


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("width", type=int)
    cli.add_argument("--max-states", type=int, default=250000)
    cli.add_argument("--literal", type=int, default=0)
    cli.add_argument("--witness", type=Path, help="write the compressed final state and vector rows")
    opt = cli.parse_args()
    rows, phases, catalogue = graph(opt.width, opt.max_states)
    for n in range(1,opt.literal+1):
        for word in product(range(4),repeat=n):
            paths = ()
            for i,letter in enumerate(word):
                paths=move(paths,letter,i%2==0,opt.width)
                if paths is None:
                    break
            has = forbidden(word)
            if (paths is None and not has) or (n<=2*opt.width+1 and (paths is None)!=has):
                raise ValueError(word)
    upper, vector = bound(rows, phases)
    if opt.witness:
        with gzip.GzipFile(str(opt.witness), "wb", mtime=0) as stream:
            for (odd,paths),i in catalogue.items():
                stream.write((json.dumps([odd,paths,vector[i]],separators=(",",":"))+"\n").encode("ascii"))
    print(json.dumps({"k":opt.width,"states":len(rows),"literal_through":opt.literal,
                      "two_steps_upper":str(upper),"per_site_display":float(upper)**0.5}))
