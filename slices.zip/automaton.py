"""A finite relaxation of the two-bank cut. Unknown exterior partners are forgotten."""
from collections import deque


def step(state, letter):
    size = len(state)
    k = size//2
    next_state = [-1]*size
    if letter in (1, 2):
        move = 1 if letter==1 else -1
        for i, p in enumerate(state):
            if p>i and 0<=i+move<size and 0<=p+move<size:
                next_state[i+move] = p+move
                next_state[p+move] = i+move
    elif letter==0:
        next_state[k-1],next_state[k] = k,k-1
        for i,p in enumerate(state):
            if p>i and i>0 and p<size-1:
                a,b = i+(-1 if i<k else 1),p+(-1 if p<k else 1)
                next_state[a],next_state[b] = b,a
    elif letter==3:
        left,right=state[k-1:k+1]
        if left==k:
            return None
        def after(i):
            return i+1 if i<k-1 else i-1
        for i,p in enumerate(state):
            if p>i and i not in (k-1,k) and p not in (k-1,k):
                a,b=after(i),after(p)
                next_state[a],next_state[b]=b,a
        if left>=0 and right>=0:
            a,b=after(left),after(right)
            next_state[a],next_state[b]=b,a
    else:
        raise ValueError(letter)
    return tuple(next_state)


def graph(k):
    if k<1:
        raise ValueError(k)
    empty=(-1,)*(2*k)
    ids={empty:0}
    pending=deque([empty])
    rows=[]
    while pending:
        row=[]
        state=pending.popleft()
        for letter in range(4):
            nxt=step(state,letter)
            if nxt is None:
                row.append(-1)
            else:
                if nxt not in ids:
                    ids[nxt]=len(ids)
                    pending.append(nxt)
                row.append(ids[nxt])
        rows.append(row)
    return rows
