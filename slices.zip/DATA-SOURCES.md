# Sequence data and attribution

The reference tables in results and two-sided/reference are earlier OEIS snapshots. The complete files one-sided/b060089.txt and two-sided/b060111.txt extend their range with the author’s independently computed values. The added terms begin at index 41.

- The On-Line Encyclopedia of Integer Sequences, [A060089](https://oeis.org/A060089), [b-file](https://oeis.org/A060089/b060089.txt).
- The On-Line Encyclopedia of Integer Sequences, [A060111](https://oeis.org/A060111), [b-file](https://oeis.org/A060111/b060111.txt).

The OEIS Foundation Inc. and the individual contributors named in the linked entries provide the reference tables. OEIS content and the extended b-files here are available under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). See the [OEIS End-User License Agreement](https://oeis.org/wiki/The_OEIS_End-User_License_Agreement). The sequence tables have separate terms from the manuscript and programs.
