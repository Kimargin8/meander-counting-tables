"""Check the explicit shortest missed cycle at each positive window radius."""
import json
from automaton import step
from literal import contains_cycle


def shifted_rainbows(k):
    size = 2*(k+1)
    upper = [size-1-i for i in range(size)]
    lower = [(1-i) % size for i in range(size)]
    return [int(i > upper[i]) + 2*int(i > lower[i]) for i in range(size)]


def accepts(k, word):
    state = (-1,)*(2*k)
    for letter in word:
        state = step(state, letter)
        if state is None:
            return False
    return True


if __name__ == "__main__":
    for k in range(1, 101):
        word = shifted_rainbows(k)
        if not (accepts(k, word) and not accepts(k+1, word) and contains_cycle(word)):
            raise ValueError(k)
    print(json.dumps({"radius_min": 1, "radius_max": 100, "shortest_missed_length": "2k+2"}))
