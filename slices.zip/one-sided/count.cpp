// Fixed-horizon dynamic program for two nonnegative bracket banks.
#define SLICE_RULE_ONLY
#include "../two-sided/finite.cpp"
#include <memory>
#include <unordered_map>
#include <sys/resource.h>

using Half=std::uint32_t;
struct __attribute__((packed)) Encoded {Mask key;Index low;};
static_assert(sizeof(Encoded)==12);
constexpr std::size_t block_size=1u<<16;

class Records {
    std::vector<std::unique_ptr<Encoded[]>> blocks;
public:
    size_t size=0;
    std::unordered_map<Index,Mask> high;
    Encoded& at(Index i) {return blocks[i/block_size][i%block_size];}
    void release_processed(Index i) {
        if((i+1)%block_size==0 || i+1==size)blocks[i/block_size].reset();
    }
    void add(Mask key,Count value) {
        if(size%block_size==0)blocks.push_back(std::make_unique_for_overwrite<Encoded[]>(block_size));
        auto i=Index(size++);at(i)={key,Index(value)};
        if(value>>32)high.emplace(i,Mask(value>>32));
    }
    void sum(Index i,Count v) {
        auto& cell=at(i);Index old=cell.low;cell.low+=Index(v);
        auto bump=Mask(v>>32)+(cell.low<old);
        if(bump)high[i]+=bump;
    }
    Count value(Index i) {
        if(high.empty())return at(i).low;
        auto it=high.find(i);
        return at(i).low+(it==high.end()?0:Count(it->second)<<32);
    }
};

class Accumulator {
    std::vector<Index> table;
    Index& slot(Mask key) {
        size_t i=mix(key)&(table.size()-1);
        while(table[i]!=empty&&data.at(table[i]).key!=key) i=(i+1)&(table.size()-1);
        return table[i];
    }
public:
    Records data;
    Count total=0;
    explicit Accumulator(size_t expected) {
        table.assign(std::bit_ceil(std::max<size_t>(16,expected)),empty);
    }
    void add(Mask key,Count value) {
        total+=value;
        if(data.size*5>table.size()*4){
            size_t n=table.size()*2;std::vector<Index>().swap(table);table.assign(n,empty);
            for(Index i=0;i<data.size;++i)slot(data.at(i).key)=i;
        }
        auto& index=slot(key);
        if(index==empty){index=Index(data.size);data.add(key,value);}
        else data.sum(index,value);
    }
};

#ifndef COUNTER_STORAGE_ONLY
Half flip(Half a,int k) {return k?Half(reverse(a)>>(64-k)):0;}
Half code(Half o,Half c,Half mask) {
    Half parity=~(o|c);
    parity^=parity<<1;parity^=parity<<2;parity^=parity<<4;
    parity^=parity<<8;parity^=parity<<16;
    return (o^(parity<<1))&mask;
}
struct HalfParts {Half o,c,mo,mc;};
class Table {
public:
    std::vector<HalfParts> parts;
    explicit Table(int k):parts(1u<<k){
        for(Half w=0;w<parts.size();++w){
            int h=0;Half o=0,c=0;
            for(int i=0;i<k;++i){
                bool up=(w>>i)&1;int next=h+(up?1:-1);
                if((h>=0)==(next>=0)){
                    if(up==(h>=0))o|=1u<<i;else c|=1u<<i;
                }
                h=next;
            }
            parts[w]={o,c,flip(o,k),flip(c,k)};
        }
    }
};
struct Sink {
    Accumulator& dst;int l,r,k,op=0;Half mask;
    void add(State s,Count value) {
        static constexpr int dl[]={1,-1,1,-1},dr[]={1,1,-1,-1};
        int h=std::min(l+dl[op],k),g=std::min(r+dr[op++],k);
        if(h<0||g<0)return;
        Half a=code(s.opens&mask,s.closes&mask,mask);
        Half b=code(flip(Half(s.closes>>k),k),flip(Half(s.opens>>k),k),mask);
        a|=Half(h)<<k;b|=Half(g)<<k;
        if(a>b)std::swap(a,b);
        dst.add((Mask(a)<<(k+6))|b,value);
    }
};

int main(int argc,char**argv){
    if(argc!=2)return 2;
    const int m=std::stoi(argv[1]);
    if(m<0||m>43)return 2;
    Records current;current.add(0,1);
    std::vector<Count> totals{1};
    std::cout<<"{\"m\":"<<m<<",\"states\":[1"<<std::flush;
    auto started=std::chrono::steady_clock::now();
    for(int t=0;t<m;++t){
        const int k=std::min(t,m-t),next=std::min(t+1,m-t-1);
        const Half mask=(1u<<k)-1,next_mask=(1u<<next)-1;
        Movement movement(k,next);
        Table decoder(k);
        Accumulator dst(current.size);
        for(Index i=0;i<current.size;++i){
            Mask key=current.at(i).key;
            Half l=Half(key>>(k+6)),r=Half(key&((Mask(1)<<(k+6))-1));
            const auto& a=decoder.parts[l&mask];const auto& b=decoder.parts[r&mask];
            State state{a.o|(Mask(b.mc)<<k),a.c|(Mask(b.mo)<<k)};
            Sink sink{dst,int(l>>k),int(r>>k),next,0,next_mask};
            movement.propagate({state,current.value(i)},sink,false);
            current.release_processed(i);
        }
        current=std::move(dst.data);
        totals.push_back(dst.total);
        std::cout<<','<<current.size<<std::flush;
    }
    if(current.size!=1)throw std::logic_error("root");
    struct rusage usage;getrusage(RUSAGE_SELF,&usage);
    std::cout<<"],\"prefix_counts\":[";
    for(int i=0;i<=m;++i)std::cout<<(i?",":"")<<'\"'<<decimal(totals[i])<<'\"';
    std::cout<<"],\"count\":\""<<decimal(current.value(0))<<"\",\"rss_kib\":"<<usage.ru_maxrss
             <<",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()<<"}\n";
}
#endif
