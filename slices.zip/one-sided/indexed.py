"""Exact open-slice counts with ballot ranks as addresses and no dictionary of geometries."""
import argparse
from bisect import bisect_right
from functools import cache
from hashlib import sha256
from math import comb
from pathlib import Path
from time import monotonic
import json
import sys

from reachability import ballot, criterion, layers

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from horizon import successor


@cache
def continuations(steps, height, target):
    if height < 0 or target < 0 or (steps+target-height) % 2:
        return 0
    p = (steps+target-height)//2
    reflected = p+height+1
    return ((comb(steps, p) if 0 <= p <= steps else 0)
            - (comb(steps, reflected) if 0 <= reflected <= steps else 0))


def half_rank(points, partners, left):
    rank = height = singles = 0
    increments = []
    for p in points:
        partner = partners.get(p)
        if partner is None:
            singles += 1
        same_bank = partner is not None and (partner < 0) == left
        down = same_bank and (partner < p if left else partner > p)
        increments.append(-1 if down else 1)
    target = sum(increments)
    for i, change in enumerate(increments):
        if change == -1:
            rank += continuations(len(increments)-i-1, height+1, target)
        height += change
    return (len(increments), singles, rank)


def half_unrank(points, singles, spanning, rank):
    height = 0
    pending, pairs = [], []
    target = singles+spanning
    for i, p in enumerate(points):
        opens = continuations(len(points)-i-1, height+1, target)
        if rank < opens:
            pending.append(p)
            height += 1
        else:
            rank -= opens
            pairs.append(tuple(sorted((pending.pop(), p))))
            height -= 1
    assert rank == 0 and height == target
    return pairs, pending[singles:]


def tri_start(i, size):
    return i*size-i*(i-1)//2


class Catalog:
    def __init__(self, t, length):
        budget = length-t
        k = min(t, budget)
        self.blocks = []
        self.starts = []
        self.offset = {}
        self.size = 0
        for j in range(k+1):
            halves = [(a, x) for a in range(j, k+1) for x in range((a-j)%2, a-j+1, 2)]
            for h, (a, x) in enumerate(halves):
                count_a = ballot(a, j+x)
                for b, y in halves[h:]:
                    if not criterion(t, budget, a, b, x, y, j):
                        continue
                    count_b = ballot(b, j+y)
                    key = (j, a, x, b, y)
                    self.starts.append(self.size)
                    self.offset[key] = self.size
                    self.blocks.append(key)
                    self.size += count_a*count_b if (a,x)!=(b,y) else count_a*(count_a+1)//2

    def address(self, arcs, a, b):
        partners = {p:q for edge in arcs for p, q in (edge, edge[::-1])}
        j = sum(p<0<=q for p,q in arcs)
        left = half_rank(range(-a, 0), partners, True)
        right = half_rank(range(b-1, -1, -1), partners, False)
        (a,x,i),(b,y,l) = sorted((left,right))
        size_b = ballot(b, y+j)
        start = self.offset[j,a,x,b,y]
        return start+(i*size_b+l if (a,x)!=(b,y) else tri_start(i,size_b)+l-i)

    def geometry(self, idx):
        group = bisect_right(self.starts, idx)-1
        j,a,x,b,y = self.blocks[group]
        local = idx-self.starts[group]
        size = ballot(b,y+j)
        if (a,x)!=(b,y):
            i,l = divmod(local,size)
        else:
            lo,hi = 0,size
            while lo+1 < hi:
                mid = (lo+hi)//2
                if tri_start(mid,size)<=local:
                    lo=mid
                else:
                    hi=mid
            i=lo
            l=i+local-tri_start(i,size)
        first, span_a = half_unrank(range(-a,0),x,j,i)
        second, span_b = half_unrank(range(b-1,-1,-1),y,j,l)
        return tuple(sorted(first+second+list(zip(span_a,span_b)))), a, b


def run(length):
    catalog = Catalog(0, length)
    values = [1]
    totals, sizes = [1], [1]
    for t in range(length):
        future = Catalog(t+1, length)
        remaining = length-t-1
        next_values = [0]*future.size
        for index, count in enumerate(values):
            arcs,a,b = catalog.geometry(index)
            assert count > 0 and catalog.address(arcs,a,b)==index
            for op,(dh,dg) in enumerate(((1,1),(-1,1),(1,-1),(-1,-1))):
                if a+dh<0 or b+dg<0:
                    continue
                new = successor(arcs,op,remaining)
                if new is not None:
                    dest = future.address(new,min(a+dh,remaining),min(b+dg,remaining))
                    next_values[dest] += count
        values = next_values
        catalog = future
        sizes.append(catalog.size)
        totals.append(sum(values))
    assert sizes==[r["folded"] for r in layers(length)] and catalog.size==1
    return sizes,totals


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--sites", type=int, default=19)
    cli.add_argument("--table", type=Path, required=True)
    cli.add_argument("--out", type=Path)
    opt = cli.parse_args()
    if not __debug__ or not 0<=opt.sites<=43:
        raise ValueError("Use ordinary Python and a valid horizon.")
    started = monotonic()
    sizes,totals = run(opt.sites)
    reference = dict(map(int,line.split()) for line in opt.table.read_text().splitlines()
                     if line.strip() and not line.startswith("#"))
    assert all(n==reference[i] for i,n in enumerate(totals))
    result={"sites":opt.sites, "counts":totals, "folded_layer_sizes":sizes,
            "inverse_checks":sum(sizes[:-1]), "all_prefixes_match":True,
            "wall_seconds":monotonic()-started,"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest()}
    if opt.out:
        opt.out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(json.dumps({k:result[k] for k in ("sites","inverse_checks","wall_seconds")}))
