// Second scan. Each end is at a fixed signed coordinate; locate partners by a
// local bracket-depth search. The dictionary and exact accumulators are shared.
#define COUNTER_STORAGE_ONLY
#include "count.cpp"
#include <fstream>
namespace physical {
#define main old_two_sided_main
#pragma GCC diagnostic push
// The included standalone entry point is never called here. Renaming main
// removes its implicit zero return, while all used transition routines remain
// identical to the independently written two-sided checker.
#pragma GCC diagnostic ignored "-Wreturn-type"
#include "../two-sided/audit.cpp"
#pragma GCC diagnostic pop
#undef main
}
using physical::Pair;

class HalfCatalogue {
    int k;
public:
    std::vector<std::array<Half,4>> decoded;
    explicit HalfCatalogue(int radius):k(radius),decoded(1u<<k) {
        for(Half w=0;w<decoded.size();++w){
            Half o=0,c=0;int h=0;
            for(int i=0;i<k;++i){
                int old=h<0?~h:h;h+=((w>>i)&1)?-1:1;
                int next=h<0?~h:h;
                if(next>old)o|=1u<<(32-k+i);
                if(next<old)c|=1u<<(32-k+i);
            }
            decoded[w]={o,c,physical::mirror(c),physical::mirror(o)};
        }
    }
};

unsigned encode_half(Half o,Half c,int k){
    if(!k)return 0;
    o>>=32-k;c>>=32-k;
    Half bits=0;bool neg=false;
    for(int j=0;j<k;j+=8){
        Half a=(o>>j)&255,b=(c>>j)&255;
        Half part=physical::byte_signed[a][b]^(neg?0:255);
        neg^=(std::popcount(a|b)&1);bits|=part<<j;
    }
    return bits&((1u<<k)-1);
}

struct Auditor {
    int k;Mask allowed;Accumulator& dst;
    void emit(Pair w,int l,int r,Count n){
        if(l<0 || r<0)return;
        w=physical::crop(w,allowed);
        auto a=(encode_half(w.open,w.close,k)<<5)+std::min(k,l);
        auto b=(encode_half(physical::mirror(w.close>>32),physical::mirror(w.open>>32),k)<<5)+std::min(k,r);
        if(a<b)std::swap(a,b);
        dst.add((Mask(a)<<(k+5))+b,n);
    }
    void step(Pair w,int l,int r,Count n){
        auto d=w;
        if(l && r && physical::close(d))emit(d,l-1,r-1,n);
        if(r)emit({w.open>>1,w.close>>1},l+1,r-1,n);
        if(l)emit({w.open<<1,w.close<<1},l-1,r+1,n);
        auto push=[](Mask x){return ((x&physical::west)>>1)|((x&~physical::west)<<1);};
        emit({push(w.open)|physical::bit(31),push(w.close)|physical::bit(32)},l+1,r+1,n);
    }
};
int main(int argc,char**argv){
    if(argc!=2)return 2;
    int n=std::stoi(argv[1]);if(n<0||n>43)return 2;
    physical::make_bytes();
    Records states;states.add(0,1);std::vector<Count> totals{1};
    auto start=std::chrono::steady_clock::now();
    std::cout<<"{\"m\":"<<n<<",\"states\":[1"<<std::flush;
    for(int t=0;t<n;++t){
        int k=std::min(t,n-t),next=std::min(t+1,n-t-1);
        HalfCatalogue cat(k);Accumulator dest(states.size);
        Auditor audit{next,((Mask(1)<<(2*next))-1)<<(32-next),dest};
        for(Index i=0;i<states.size;++i){
            auto key=states.at(i).key;
            Half left=key>>(k+5),right=key&((Mask(1)<<(k+5))-1);
            auto a=cat.decoded[left>>5],b=cat.decoded[right>>5];
            audit.step({a[0]|(Mask(b[2])<<32),a[1]|(Mask(b[3])<<32)},left&31,right&31,states.value(i));
            states.release_processed(i);
        }
        totals.push_back(dest.total);states=std::move(dest.data);
        std::cout<<','<<states.size<<std::flush;
    }
    if(states.size!=1 || totals.back()!=states.value(0))throw std::logic_error("root");
    struct rusage usage;getrusage(RUSAGE_SELF,&usage);
    std::cout<<"],\"prefix_counts\":[";
    for(int i=0;i<=n;++i)std::cout<<(i?",":"")<<'\"'<<decimal(totals[i])<<'\"';
    std::cout<<"],\"count\":\""<<decimal(totals.back())<<"\",\"rss_kib\":"<<usage.ru_maxrss
             <<",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"}\n";
}
