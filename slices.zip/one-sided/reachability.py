"""Count reachable capped one-sided geometries, without generating their words."""
from collections import Counter
from functools import cache
from itertools import product
from hashlib import sha256
from math import comb
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent/"data"


@cache
def ballot(a,h):
    if h<0 or h>a or (a-h)%2:return 0
    p=(a-h)//2
    return comb(a,p)-(comb(a,p-1) if p else 0)


def criterion(t,budget,a,b,x,y,j):
    if t==0 or budget==0:return not any((a,b,x,y,j))
    if a+b==0:return False
    n=x+y
    for left in (0,n):
        right=n-left
        if (left and a!=budget) or (right and b!=budget):continue
        flip=(a+left-t)%2
        if flip and (a!=budget or b!=budget):continue
        minimum=a+b+n-j-abs(left-x)+flip
        if minimum<=t:return True
    return False


def layers(m):
    records=[]
    for t in range(m+1):
        budget=m-t;k=min(t,budget)
        oriented=fixed=0
        for j in range(k+1):
            for a in range(j,k+1):
                for b in range(a,k+1):
                    for x in range((a-j)%2,a-j+1,2):
                        ways=ballot(a,j+x)
                        for y in range((b-j)%2,b-j+1,2):
                            if not criterion(t,budget,a,b,x,y,j): continue
                            oriented+=(1+(a!=b))*ways*ballot(b,j+y)
                            if (a,x)==(b,y):fixed+=ways
        assert (oriented+fixed)%2==0
        records.append({"t":t,"oriented":oriented,"fixed":fixed,
                        "folded":(oriented+fixed)//2})
    return records


def literal(text):
    n=len(text);adj=[[] for _ in text];st=[[],[]]
    for s,letter in enumerate(text):
        for bank,op in enumerate(((1,1),(0,1),(1,0),(0,0))[letter]):
            if op:st[bank].append(s)
            elif st[bank]:
                i=st[bank].pop();adj[s].append(i);adj[i].append(s)
            else:return None
    endpoints={}
    for b,sticks in enumerate(st):
        for d,i in enumerate(reversed(sticks)):
            endpoints.setdefault(i,[]).append(d if b else -d-1)
    pairs=[];seen=set()
    for i in range(n):
        if i in seen:continue
        todo=[i];seen.add(i);ends=[]
        while todo:
            v=todo.pop();ends.extend(endpoints.get(v,()))
            for w in adj[v]:
                if w not in seen:seen.add(w);todo.append(w)
        if len(ends)!=2:return None
        pairs.append(tuple(sorted(ends)))
    return len(st[0]),len(st[1]),tuple(sorted(pairs))


def literal_compare(max_t):
    probes=0;classes=0
    for t in range(max_t+1):
        full={obj for w in product(range(4),repeat=t) if (obj:=literal(w)) is not None}
        for budget in range(0,6):
            k=min(t,budget)
            observed=set()
            for true_a,true_b,pairs in full:
                a=min(true_a,budget);b=min(true_b,budget)
                kept=tuple((i,j) for i,j in pairs if -k<=i and j<k)
                observed.add((a,b,kept))
            types=Counter()
            for a,b,kept in observed:
                ends={v for pair in kept for v in pair}
                x=a-sum(i<0 for i in ends);y=b-sum(i>=0 for i in ends)
                j=sum(i<0<=h for i,h in kept)
                types[a,b,x,y,j]+=1
            for a,b,j in product(range(k+1),repeat=3):
                for x in range(a+1):
                    for y in range(b+1):
                        count=ballot(a,j+x)*ballot(b,j+y)
                        if not criterion(t,budget,a,b,x,y,j):count=0
                        assert count==types[a,b,x,y,j],(t,budget,a,b,x,y,j)
                        probes+=1
            classes+=len(observed)
    return probes,classes


def main():
    small,classes=literal_compare(8)
    rows=layers(41)
    canonical=json.loads((OUT/"compact41.json").read_bytes())
    audit=json.loads((OUT/"audit41.json").read_bytes())
    assert [r["folded"] for r in rows]==canonical["states"]==audit["states"]
    examples={}
    for m in (40,41,42):
        s=m//2
        a=max(range((2*s+2)//3,s+1),key=lambda k:ballot(k,3*k-2*s))
        p=s-a;j=a-2*p;t=a+2*p
        n=ballot(a,j)
        examples[m]={"height":a,"cross":j,"t":t,"full_witnesses":n*n,"folded_witnesses":n*(n+1)//2}
    report={"scope":"exact sizes of reachable projected one-sided layers, not their multiplicities",
            "m":41,"layers":rows,"literal_full_times_through":8,"literal_remaining_budgets_through":5,
            "small_parameter_cases":small,"small_oriented_states_over_all_cases":classes,
            "balanced_sector_examples":examples,"code_sha256":sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT/"projected-reachability.json").write_text(json.dumps(report,indent=2)+"\n")
    print(small,classes,max(r["folded"] for r in rows))


if __name__=="__main__":main()
