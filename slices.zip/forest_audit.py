"""Check the forest certificate by joining component labels on a padded boundary."""
import argparse
from fractions import Fraction
import gzip
import json
from pathlib import Path


def next_state(k, odd, paths, op):
    # Each fresh exterior position has its own label and occurs only once.
    positions = list(range(2*k+2))
    ages = {}
    for age,(a,b,tag) in enumerate(paths):
        label = 2*k+2+age
        positions[k+1+a] = positions[k+1+b] = label
        ages[label] = tag
    if op == 0:
        label = 2*k+2+len(paths)
        ages[label] = odd
        positions[k+1:k+1] = [label,label]
        positions = positions[2:-2]
    elif op == 1:
        positions = positions[:-2]
    elif op == 2:
        positions = positions[2:]
    else:
        a,b = positions[k:k+2]
        if a == b and odd and not ages[a]:
            return None
        small,large = sorted((a,b))
        del positions[k:k+2]
        if a != b:
            positions = [small if label == large else label for label in positions]
    ends = {}
    for x,label in enumerate(positions,-k):
        ends.setdefault(label,[]).append(x)
    paths = [(x,y,ages[label]) for label,sites in sorted(ends.items()) if len(sites)==2
             for x,y in [sites]]
    direct = tuple(paths)
    reverse = tuple((-1-y,-1-x,tag) for x,y,tag in paths)
    return not odd, min(direct,reverse)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("metadata", type=Path)
    cli.add_argument("witness", type=Path)
    args = cli.parse_args()
    report = json.loads(args.metadata.read_text(encoding="utf-8-sig"))
    k, upper = report["k"], Fraction(report["two_steps_upper"])
    states = {}
    with gzip.open(args.witness, "rt", encoding="ascii") as stream:
        for line in stream:
            odd,entries,weight=json.loads(line)
            state = (odd, tuple(map(tuple,entries)))
            if state in states or type(weight)!=int or weight<=0:
                raise ValueError("repeated state or nonpositive weight")
            states[state] = weight
    if len(states)!=report["states"] or (True,()) not in states:
        raise ValueError("state catalogue")
    even_sums = {}
    neighbours = closures = 0
    for first, table in ((False,states),(True,even_sums)):
        for (odd, entries), weight in states.items():
            if odd != first:
                continue
            total = 0
            for op in range(4):
                target = next_state(k,odd,entries,op)
                if target is None:
                    closures += 1
                else:
                    neighbours += 1
                    total += table[target]
            if first:
                if total*upper.denominator > weight*upper.numerator:
                    raise ValueError("failed two-step inequality")
            else:
                even_sums[odd,entries]=total
    print(json.dumps({"k": k, "states":len(states), "admitted_labels":neighbours,
                      "forbidden_closures":closures,"all_rows_pass":True}))


if __name__ == "__main__":
    main()
