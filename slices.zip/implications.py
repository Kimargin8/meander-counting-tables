"""Cross-check integer comparisons and the planar-graph exponents without floating point."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("data", type=Path)
    cli.add_argument("--width", type=int, default=15)
    args = cli.parse_args()
    root = args.data
    def read(f):
        return json.loads((root/f).read_text(encoding="utf-8-sig"))
    def require(condition):
        if not condition:
            raise ValueError("an exact comparison failed")
    def bound(tag):
        data = read(tag+".json")
        audit = read(tag+"-audit.json")
        require(audit["all_rows_pass"] and data["states"] == audit["states"] and
                data["v_min"] == audit["v_min"] and data["v_empty"] == audit["v_empty"])
        return F(data["upper"], data["den"])
    r = bound(f"k{args.width}q1f")
    rq = bound("k12q159f")
    q, lower = F(159, 100), F(12401248195833, 1058038773811)
    require((rq**2/lower)**13 < q**7 and q**3 > 4)
    # Caroppo et al., Thms 5, 8--10. Use their upper bound on omega.
    sqrt_bound = F(2121321, 1000000)
    require(sqrt_bound**2 > F(9,2))
    exponents = {}
    forest = read("forest8.json")
    forest_audit = read("forest8-audit.json")
    require(forest_audit["states"]==forest["states"] and forest_audit["all_rows_pass"])
    f2 = F(forest["two_steps_upper"])
    require(f2 < F(3792585,1000000)**2)
    comparisons = (("Hamiltonian cycle and bounded-weight TSP",4,r+2),
                   ("bounded-weight longest cycle/path",4,r+3),
                   ("bounded-weight connected dominating set",6,r*r+2),
                   ("bounded-weight Steiner tree",5,r*r+1),
                   ("bounded-weight feedback vertex set",5,f2+1))
    for name, c1, c2 in comparisons:
        second_term = c1!=4
        require((c2**250 > c1**343) == second_term)
        # Bound log2(c2) using integer powers only.
        units = 100000
        low, high = 0, 4*units
        numerator = c2.numerator**units
        denominator = c2.denominator**units
        while high-low > 1:
            mid = (low+high)//2
            if numerator <= denominator << mid:
                high = mid
            else:
                low = mid
        log_upper = F(high,units)
        exponent = sqrt_bound*(log_upper if second_term else F(343,250)+log_upper/2)
        ceiling = -(-exponent.numerator*1000//exponent.denominator)
        exponents[name] = {"log2_frontier_upper": str(log_upper),
                           "sqrt_n_exponent_upper": f"{ceiling}/1000"}
    reference = {}
    for tag, ref in (("two","b060111-reference.txt"),("one","b060089-reference.txt")):
        known = {int(i): int(v) for line in (root/ref).read_text().splitlines()
                 if line.strip() and not line.startswith("#") for i,v in [line.split()]}
        data = read(f"horizon-{tag}.json")
        require(all(known[i] == v for i,v in enumerate(data["counts"])))
        if tag == "two":
            for name in ("slices12.json","slices15.json"):
                values = read(name)["exact"]
                require(all(known[i] == int(v) for i,v in enumerate(values)))
        reference[tag] = len(data["counts"])
    print(json.dumps({"width":args.width,"mu_upper_exact":str(r*r),"r":str(r),
                      "marked_alpha":"7/13","marked_epsilon_exponent":"3/2",
                      "graph_exponents":exponents, "reference_counts_checked":reference},indent=2))


if __name__ == "__main__":
    main()
