"""Compute both acyclic slice counts from the one-sided transfer (Bacher, Rem. 3.9)."""
import argparse
import json
from functools import lru_cache
from itertools import product
from pathlib import Path

from horizon import successor


DELTAS = ((1, 1), (-1, 1), (1, -1), (-1, -1))


def slice_counts(length):
    # Aggregated moments of 1, h+1, g+1, and (h+1)(g+1) in canonical orientation.
    layer = {((), 0, 0): [1, 1, 1, 1]}
    data = [{"sites": 0, "one_sided": 1, "two_sided": 1}]
    for t in range(1, length + 1):
        radius = length - t
        after = {}

        @lru_cache(maxsize=None)
        def connections(arcs, op):
            pairs = successor(arcs, op, radius)
            if pairs is None:
                return None
            mirror = tuple(sorted((-1-b, -1-a) for a, b in pairs))
            return pairs, mirror

        for (arcs, h, g), (w, x, y, z) in layer.items():
            for op, (dh, dg) in enumerate(DELTAS):
                if h + dh < 0 or g + dg < 0:
                    continue
                options = connections(arcs, op)
                if options is None:
                    continue
                ch, cg = min(h + dh, radius), min(g + dg, radius)
                direct, reflected = (options[0], ch, cg), (options[1], cg, ch)
                nx, ny, nz = x + dh*w, y + dg*w, z + dh*y + dg*x + dh*dg*w
                if reflected < direct:
                    direct = reflected
                    nx, ny = ny, nx
                accum = after.setdefault(direct, [0, 0, 0, 0])
                accum[0] += w
                accum[1] += nx
                accum[2] += ny
                accum[3] += nz
        layer = after
        connections.cache_clear()
        data.append({"sites": t, "one_sided": sum(v[0] for v in layer.values()),
                     "two_sided": sum(v[3] for v in layer.values())})
    return data


def bracket_data(word):
    stack, pairs, missing = [], [], []
    for i, opening in enumerate(word):
        if opening:
            stack.append(i)
        elif stack:
            pairs.append((stack.pop(), i))
        else:
            missing.append(i)
    return tuple(pairs), missing, stack


def check_fibres(length):
    # No transfer states here. Test the two inverse maps for every single-bank word.
    fibres = {}
    for word in product((0, 1), repeat=length):
        pairs, missing, _ = bracket_data(word)
        positive = list(word)
        for i in missing:
            positive[i] = 1
        new_pairs, failures, final = bracket_data(positive)
        assert new_pairs == pairs and not failures
        inverse = positive.copy()
        for i in final[:len(missing)]:
            inverse[i] = 0
        assert tuple(inverse) == word
        key = tuple(positive)
        fibres[key] = fibres.get(key, 0) + 1
    for word, size in fibres.items():
        assert size == 1 + len(bracket_data(word)[2])
    return len(fibres)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--sites", type=int, default=23)
    cli.add_argument("--data", type=Path, default=Path(__file__).resolve().parent/"results")
    cli.add_argument("--out", type=Path)
    opt = cli.parse_args()
    if not __debug__ or not 1 <= opt.sites <= 40:
        raise ValueError("Use ordinary Python and a horizon from 1 to 40.")
    rows = slice_counts(opt.sites)
    for name, field in (("b060111-reference.txt", "two_sided"), ("b060089-reference.txt", "one_sided")):
        table = [s.split() for s in (opt.data/name).read_text().splitlines() if s.strip() and not s.startswith("#")]
        for index, value in table:
            if int(index) <= opt.sites:
                assert rows[int(index)][field] == int(value)
    receipt = {"through": opt.sites, "fibres_by_length": [check_fibres(n) for n in range(14)],
               "both_sequences_verified": True, "counts": rows}
    if opt.out:
        opt.out.write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf8")
    print(json.dumps({"through": opt.sites, **rows[-1]}))


if __name__ == "__main__":
    main()
