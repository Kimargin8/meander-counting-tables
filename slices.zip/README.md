# Meandric growth from local connectivity at a cut

Iaroslav Argunov, November 22, 2026. Preprint and computational supplement.

Start with **window-bounds.pdf**. It treats connected closed meanders on ordered sites, acyclic slices, and the parity condition used for forest meandric systems. The requirements for the verification programs are Python 3.10 or later and a little-endian Linux host with a C++20 compiler supporting unsigned 128-bit integers. No external Python package is required.

## Fast independent checks

From the directory containing this file in the extracted archive, run:

    python3 reproduce.py --witness witnesses/k9q1f
    python3 reproduce.py
    python3 strict.py
    python3 literal.py --out literal-check.json
    python3 forest_audit.py results/forest6.json witnesses/forest6.gz
    python3 forest_audit.py results/forest8.json witnesses/forest8.gz
    python3 implications.py results --width 16
    python3 moments.py --sites 25

The first command checks every row of the supplied witness for the bound 12.801108. The second rebuilds it before checking. Both also test rejection of a corrupted witness and of an upper numerator tightened by a single unit. The literal check traces cycles in the physical graph of each word. The forest checker tracks component labels and their oldest sites, independently of its generator. The implications command verifies outward rounding for the graph exponents by integer powers. The moments command recovers both sequences from a single one-sided transfer, using the two true terminal heights as weights. The files in **results** include the two open-sequence reference tables from OEIS, the finite checks and the final numerical receipts.

## Larger certificates

    python3 reproduce.py --width 12
    python3 reproduce.py --width 15
    python3 reproduce.py --width 16

Width 12 reproduces the marked comparison for relative approximation. Widths 15 and 16 give the strongest unweighted comparisons in the paper. The programs build the graph and integer vector in a temporary directory, check the vector, and automatically release their temporary files. At width 16 allow at least 7 GiB of free RAM and 3 GiB of temporary disk. The generator and independent checker run sequentially. The supplied width-9 witness and both compact forest witnesses can be checked without running the large computation.

To regenerate the second forest witness, run:

    python3 forest.py 8 --literal 6 --witness forest8-new.gz
    python3 forest_audit.py results/forest8.json forest8-new.gz

For direct small counts use the following examples. In the closed case the argument is the order, giving one additional compulsory final crossing after the computed prefix.

    python3 horizon.py two-sided 23
    python3 horizon.py one-sided 23
    python3 horizon.py closed 13

The [one-sided](one-sided) and [two-sided](two-sided) directories contain the programs and certificates for the larger terms. A060111 extends the bidirectional table through 44. A060089 extends the unidirectional table through 43. Two integer transfers agree on every prefix and every layer. A separate ballot completion criterion predicts the exact size of each layer, and a dense addressing algorithm independently verifies the counts through 29 sites. The growth certificates here bound the number of configurations.

## Reproducing the one-sided counts

The complete table is in [one-sided/b060089.txt](one-sided/b060089.txt). From this directory run:

    g++ -O3 -std=c++20 one-sided/count.cpp -o one-forward
    g++ -O3 -std=c++20 one-sided/audit.cpp -o one-check
    ./one-forward 43
    ./one-check 43
    python3 one-sided/indexed.py --sites 19 --table one-sided/b060089.txt

The two C++ programs retain all coefficients through 43 in unsigned 128-bit arithmetic; a word count is at most 4^43. They report all prefix totals. The Python implementation uses integer ballot ranks instead of a table indexed by matchings. For two-sided counts see the [table](two-sided/b060111.txt) and [reproduction instructions](two-sided/order44.md).

The author used OpenAI's ChatGPT and Codex for research assistance and verification software. Earlier sequence data and attribution are described in [DATA-SOURCES.md](DATA-SOURCES.md).
