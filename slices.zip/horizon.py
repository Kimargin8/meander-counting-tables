"""Exact two-bank counts with a shrinking window. Heights are optional."""
from collections import defaultdict
from functools import lru_cache
import argparse
import json


def successor(arcs, letter, radius):
    """The bank ends nearest the cut are -1 and 0."""
    def insert(x):
        return x - 1 if x < 0 else x + 1

    def remove(x):
        return x + 1 if x < 0 else x - 1

    if letter == 0:
        moved = [(insert(a), insert(b)) for a, b in arcs]
        moved.append((-1, 0))
    elif letter in (1, 2):
        delta = 1 if letter == 1 else -1
        moved = [(a + delta, b + delta) for a, b in arcs]
    else:
        mates = {}
        moved = []
        for a, b in arcs:
            if (a, b) == (-1, 0):
                return None
            if a in (-1, 0):
                mates[a] = b
            elif b in (-1, 0):
                mates[b] = a
            else:
                moved.append((remove(a), remove(b)))
        if len(mates) == 2:
            moved.append(tuple(sorted((remove(mates[-1]), remove(mates[0])))))
    return tuple(sorted((a, b) for a, b in moved if -radius <= a and b < radius))


def count(length, kind):
    if length < 0 or kind not in ('two-sided', 'one-sided', 'closed'):
        raise ValueError((length, kind))
    if kind == 'closed' and length % 2 == 0:
        raise ValueError('closed uses 2n-1 sites before the final closure')
    layers = {((), 0, 0): 1}
    for depth in range(length):
        following = defaultdict(int)
        radius = length - depth - 1
        advance = lru_cache(maxsize=None)(lambda arcs, op: successor(arcs, op, radius))
        for (arcs, left, right), multiplicity in layers.items():
            for op, (dl, dr) in enumerate(((1, 1), (-1, 1), (1, -1), (-1, -1))):
                l, r = (0, 0) if kind == 'two-sided' else (left + dl, right + dr)
                if min(l, r) < 0:
                    continue
                if kind == 'closed' and max(abs(l - 1), abs(r - 1)) > radius:
                    continue
                target = advance(arcs, op)
                if target is not None:
                    following[target, l, r] += multiplicity
        advance.cache_clear()
        layers = following
    return sum(value for (_, l, r), value in layers.items()
               if kind != 'closed' or (l, r) == (1, 1))


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('kind', choices=['two-sided', 'one-sided', 'closed'])
    cli.add_argument('maximum', type=int, help='last number of sites, or last closed order')
    opt = cli.parse_args()
    start = int(opt.kind == 'closed')
    answer = [count(2 * i - 1 if start else i, opt.kind) for i in range(start, opt.maximum + 1)]
    print(json.dumps({'kind': opt.kind, 'offset': start, 'counts': answer}))
