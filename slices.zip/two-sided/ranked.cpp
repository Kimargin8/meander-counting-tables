// Exact fixed-horizon transfer indexed by two halves of a partial matching.
// The membership tests in finite.cpp are shared with the sparse implementation.
#define SLICE_RULE_ONLY
#include "finite.cpp"
#include <memory>
#include <unordered_map>
#include <cstdio>

using HalfMask=std::uint32_t;
constexpr int maximum_depth=23;
constexpr int extent=maximum_depth+1;
#ifdef SLICE_MOD
static_assert(SLICE_MOD>=2 && SLICE_MOD<=65535);
using ValueSlot=std::uint16_t;
#else
using ValueSlot=Index;
#endif
struct Half {HalfMask opens,closes,mirror_opens,mirror_closes;};
struct Address {int length,height;Index rank;};

class HalfTable {
    std::vector<Index> ranks;
public:
    std::array<std::array<std::vector<Half>,extent>,extent> groups{};
    explicit HalfTable(int depth):ranks(size_t(2)<<depth,empty) {
        groups[0][0].push_back({});ranks[1]=0;
        for(int n=1;n<=depth;++n) {
            const HalfMask boundary=1u<<n;
            // After outside singleton ends are trimmed, the first step is up.
            for(HalfMask word=1;word<boundary;word+=2) {
                HalfMask opens=0,closes=0;
                int h=0;
                for(int i=0;i<n;++i) {
                    bool upwards=(word>>i)&1;
                    int next=h+(upwards?1:-1);
                    if((h>=0)==(next>=0)) {
                        if(upwards==(h>=0)) opens|=1u<<i;
                        else closes|=1u<<i;
                    }
                    h=next;
                }
                auto& group=groups[n][h>=0?h:-h-1];
                ranks[boundary+word]=static_cast<Index>(group.size());
                group.push_back({opens,closes,HalfMask(reverse(opens)>>(64-n)),
                                              HalfMask(reverse(closes)>>(64-n))});
            }
        }
    }
    Address describe(HalfMask o,HalfMask c,int k) const {
        auto outside=std::countr_zero(o|c|(1u<<k));
        int n=k-outside;
        o>>=outside;c>>=outside;
        HalfMask mask=(1u<<n)-1;
        HalfMask parity=(~(o|c))&mask;
        parity^=parity<<1;parity^=parity<<2;parity^=parity<<4;
        parity^=parity<<8;parity^=parity<<16;
        HalfMask word=(o^(parity<<1))&mask;
        Index rank=ranks[(1u<<n)+word];
        if(rank==empty) throw std::logic_error("invalid half code");
        return {n,std::popcount(o)-std::popcount(c),rank};
    }
    void trim_to(int k) {
        if(ranks.size()<=(size_t(2)<<k)) return;
        ranks.resize(size_t(2)<<k);ranks.shrink_to_fit();
        for(int n=k+1;n<extent;++n)
            for(auto& group:groups[n]) std::vector<Half>().swap(group);
    }
};

struct Block {int a,b,j;std::size_t start;};
class Dense {
    const HalfTable& halves;
    int k;
    std::array<std::array<std::array<Index,extent>,extent>,extent> offsets{};
    std::vector<Block> blocks;
    std::vector<ValueSlot> low;
    std::FILE* spill=nullptr;
    std::size_t cells=0;
    // The total weight at most 4^t bounds how many cells can exceed 32 bits.
    // The all-ones sentinel allows the large-count map to stay off the hot path.
    std::unordered_map<Index,Count> large;
    std::size_t address(State s) const {
        if(!k) return 0;
        HalfMask mask=(1u<<k)-1;
        auto a=halves.describe(s.opens&mask,s.closes&mask,k);
        auto b=halves.describe(reverse(s.closes>>k)>>(64-k),reverse(s.opens>>k)>>(64-k),k);
        if(a.height!=b.height || a.height<0) throw std::logic_error("unmatched cross-bank ends");
        if(a.length>b.length || (a.length==b.length && a.rank>b.rank)) std::swap(a,b);
        auto start=offsets[a.length][b.length][a.height];
        if(start==empty) throw std::logic_error("state exceeds its vertex budget");
        std::size_t y=b.rank;
        return start+a.rank+(a.length==b.length ? y*(y+1)/2 :
                          y*halves.groups[a.length][a.height].size());
    }
public:
    Dense(const HalfTable& table,int t,int m):halves(table),k(std::min(t,m-t)) {
        for(auto& row:offsets) for(auto& col:row) col.fill(empty);
        std::size_t size=0;
        for(int a=0;a<=k;++a) for(int b=a;b<=k;++b)
            for(int j=0;j<=a;++j) {
                auto x=halves.groups[a][j].size(),y=halves.groups[b][j].size();
                if(a+b-j>t || !x || !y) continue;
                if(size>=empty) throw std::overflow_error("index width insufficient");
                offsets[a][b][j]=Index(size);blocks.push_back({a,b,j,size});
                size+=a==b ? x*(x+1)/2 : x*y;
            }
        if(size>=empty) throw std::overflow_error("index width insufficient");
        cells=size;low.resize(cells);
    }
    ~Dense(){if(spill) std::fclose(spill);}
    std::size_t stream_source() {
        spill=std::tmpfile();
        if(!spill || std::fwrite(low.data(),sizeof(ValueSlot),cells,spill)!=cells ||
                std::fseek(spill,0,SEEK_SET)!=0)
            throw std::runtime_error("could not store sequential source");
        std::vector<ValueSlot>().swap(low);
        return sizeof(ValueSlot)*cells;
    }
    void add(State s,Count value) {
        Index p=Index(address(s)),old=low[p];
#ifdef SLICE_MOD
        Index sum=old+Index(value);
        if(sum>=SLICE_MOD) sum-=SLICE_MOD;
        low[p]=ValueSlot(sum);
#else
        if(value<empty-old) {low[p]=old+Index(value);return;}
        if(old==empty) {large.at(p)+=value;return;}
        large.emplace(p,Count(old)+value);low[p]=empty;
#endif
    }
    std::size_t allocated() const{return cells;}
#ifdef SLICE_PROFILE
    std::size_t large16() const {
        return std::count_if(low.begin(),low.end(),[](Index x){return x>=65535;});
    }
#endif
    Count answer() const {
        if(low.size()!=1) throw std::logic_error("unfinished boundary");
        return low[0]==empty?large.at(0):Count(low[0]);
    }
    std::size_t transfer(Dense& next,const Movement& move) const {
        std::size_t touched=0;
        constexpr std::size_t chunk_size=16384;
        std::array<ValueSlot,chunk_size> chunk;
        for(auto block:blocks) {
            auto [a,b,j,offset]=block;
            auto& lhs=halves.groups[a][j];auto& rhs=halves.groups[b][j];
            for(std::size_t y=0;y<rhs.size();++y) {
                Mask ro=Mask(rhs[y].mirror_closes)<<k, rc=Mask(rhs[y].mirror_opens)<<k;
                auto size=a==b?y+1:lhs.size();
                for(std::size_t x=0;x<size;++x,++offset) {
                    Count count;
                    if(spill) {
                        auto slot=offset%chunk_size;
                        if(!slot) {
                            auto block_size=std::min(chunk_size,cells-offset);
                            if(std::fread(chunk.data(),sizeof(ValueSlot),block_size,spill)!=block_size)
                                throw std::runtime_error("could not read sequential source");
                        }
                        count=chunk[slot];
                    } else count=low[offset];
                    if(count==empty) count=large.at(Index(offset));
                    if(!count) continue;
                    ++touched;
                    State state{ro|(Mask(lhs[x].opens)<<(k-a)),
                                rc|(Mask(lhs[x].closes)<<(k-a))};
                    move.propagate({state,count},next,false);
                }
            }
        }
        return touched;
    }
};

int main(int argc,char**argv) {
    bool streaming=argc==3 && std::string(argv[2])=="--stream";
    if(argc!=2 && !streaming) throw std::invalid_argument("length [--stream]");
    int m=std::stoi(argv[1]);
    if(m<0 || m>2*maximum_depth+1) throw std::invalid_argument("unsupported length");
    auto start=std::chrono::steady_clock::now();
    HalfTable halves(m/2);
    auto layer=std::make_unique<Dense>(halves,0,m);
    size_t bytes_streamed=0,peak_file=0;
    layer->add({},1);
    std::cout<<"{\"length\":"<<m;
#ifdef SLICE_MOD
    std::cout<<",\"modulus\":"<<SLICE_MOD;
#endif
    std::cout<<",\"layers\":[";
    for(int t=0;t<m;++t) {
        if(t>m/2) halves.trim_to(m-t);
        if(streaming && layer->allocated()>36000000) {
            size_t bytes=layer->stream_source();bytes_streamed+=bytes;
            peak_file=std::max(peak_file,bytes);
        }
        auto next=std::make_unique<Dense>(halves,t+1,m);
        Movement rule(std::min(t,m-t),std::min(t+1,m-t-1));
        auto active=layer->transfer(*next,rule);
        if(t) std::cout<<',';
        std::cout<<"["<<layer->allocated()<<","<<active;
#ifdef SLICE_PROFILE
        std::cout<<","<<layer->large16();
#endif
        std::cout<<"]"<<std::flush;
        layer=std::move(next);
    }
    if(m) std::cout<<',';
    std::cout<<"[1,1]],\"total\":\""<<decimal(layer->answer())<<"\"";
    if(streaming) std::cout<<",\"temporary_bytes_written\":"<<bytes_streamed
                           <<",\"largest_temporary_file\":"<<peak_file;
    std::cout<<",\"seconds\":"
             <<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"}\n";
}
