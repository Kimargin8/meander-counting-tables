// Count all acyclic two-bank words of one fixed length. Only ends that a
// remaining letter can reach are retained. The two banks are interchangeable.
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

using Mask=std::uint64_t;
using Count=__uint128_t;
using Index=std::uint32_t;
struct State {
    Mask opens{},closes{};
    friend bool operator==(State,State)=default;
};
struct Entry {State state; Count count;};
constexpr Index empty=std::numeric_limits<Index>::max();

Mask reverse(Mask x) {
    x=((x>>1)&0x5555555555555555ULL)|((x&0x5555555555555555ULL)<<1);
    x=((x>>2)&0x3333333333333333ULL)|((x&0x3333333333333333ULL)<<2);
    x=((x>>4)&0x0f0f0f0f0f0f0f0fULL)|((x&0x0f0f0f0f0f0f0f0fULL)<<4);
    return __builtin_bswap64(x);
}
State canonical(State s,int width) {
    if(!width) return {};
    Mask a=reverse(s.closes)>>(64-width), b=reverse(s.opens)>>(64-width);
    if(a<s.opens || (a==s.opens && b<s.closes)) return {a,b};
    return s;
}
Mask mix(Mask x) {
    x^=x>>30; x*=0xbf58476d1ce4e5b9ULL;
    x^=x>>27; x*=0x94d049bb133111ebULL;
    return x^(x>>31);
}
class Layer {
    std::vector<Index> table;
    std::size_t limit;
    size_t slot(State s) const {
        auto mask=table.size()-1, p=mix(s.opens^std::rotl(s.closes,29))&mask;
        while(table[p]!=empty && !(entries[table[p]].state==s)) p=(p+1)&mask;
        return p;
    }
public:
    std::vector<Entry> entries;
    explicit Layer(size_t max_states): table(8,empty),limit(max_states) {entries.reserve(limit);}
    void reset() {entries.clear(); std::fill(table.begin(),table.end(),empty);}
    void add(State s,Count count) {
        if(entries.size()*4>table.size()*3){
            table.assign(table.size()*2,empty);
            for(Index i=0;i<entries.size();++i) table[slot(entries[i].state)]=i;
        }
        Index& index=table[slot(s)];
        if(index==empty) {
            if(entries.size()>=limit) throw std::runtime_error("state limit");
            index=static_cast<Index>(entries.size());entries.push_back({s,count});
        } else entries[index].count+=count;
    }
};
std::string decimal(Count value) {
    std::string text;
    do{text.push_back('0'+value%10);value/=10;}while(value);
    std::reverse(text.begin(),text.end());return text;
}
struct Movement {
    std::array<std::array<int,64>,4> dest{};
    int k, next;
    Movement(int depth,int next_depth):k(depth),next(next_depth) {
        for(int i=0;i<2*k;++i) {
            int j=i-k;
            dest[0][i]=next+j+(j<0?-1:1);
            dest[1][i]=next+j+1;
            dest[2][i]=next+j-1;
            dest[3][i]=j==-1||j==0?-100:next+j+(j<0?1:-1);
        }
    }
    template<class Destination>
    void propagate(const Entry &e,Destination& layer,bool fold) const {
        std::array<State,4> row{};
        std::array<int,32> stack;
        int size=0, left=-100, right=-100;
        bool blocked=false;
        auto arc=[&](State &s,int a,int b) {
            if(a>=0 && b<2*next) {s.opens|=Mask(1)<<a;s.closes|=Mask(1)<<b;}
        };
        auto occupied=e.state.opens|e.state.closes;
        while(occupied) {
            int b=std::countr_zero(occupied);
            occupied&=occupied-1;
            if((e.state.opens>>b)&1) {stack[size++]=b;continue;}
            if(!size) throw std::logic_error("unmatched closing bracket");
            int a=stack[--size];
            for(int c=0;c<3;++c) arc(row[c],dest[c][a],dest[c][b]);
            if(a==k-1 || b==k-1 || a==k || b==k) {
                if(a==k-1 && b==k) blocked=true;
                if(a==k-1) left=dest[3][b];
                if(b==k-1) left=dest[3][a];
                if(a==k) right=dest[3][b];
                if(b==k) right=dest[3][a];
            } else arc(row[3],dest[3][a],dest[3][b]);
        }
        if(size) throw std::logic_error("unmatched opening bracket");
        arc(row[0],next-1,next);
        if(left>right) std::swap(left,right);
        arc(row[3],left,right);
        for(int c=0;c<4-int(blocked);++c)
            layer.add(fold?canonical(row[c],2*next):row[c],e.count);
    }
};
#ifndef SLICE_RULE_ONLY
int main(int argc,char**argv) {
    if(argc<3 || argc>4) throw std::invalid_argument("length max_states [--unfold]");
    int m=std::stoi(argv[1]);
    auto limit=std::stoul(argv[2]);
    bool fold=argc==3;
    if((!fold && std::string(argv[3])!="--unfold") || m<0 || m>62 || !limit || limit>12000000)
        throw std::invalid_argument("unsupported arguments");
    Layer a(limit),b(limit);
    a.add({},1);
    auto start=std::chrono::steady_clock::now();
    std::cout<<"{\"length\":"<<m<<",\"folded\":"<<(fold?"true":"false")<<",\"layers\":[";
    for(int t=0;t<m;++t) {
        Movement rule(std::min(t,m-t),std::min(t+1,m-t-1));
        b.reset();
        try {for(auto &entry:a.entries) rule.propagate(entry,b,fold);}
        catch(const std::runtime_error& er) {
            std::cerr<<"at t="<<t+1<<": "<<er.what()<<"\n";return 3;
        }
        std::swap(a,b);
        if(t) std::cout<<',';
        std::cout<<a.entries.size()<<std::flush;
    }
    if(a.entries.size()!=1) throw std::logic_error("unfinished boundary");
    std::cout<<"],\"total\":\""<<decimal(a.entries[0].count)<<"\",\"seconds\":"
             <<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"}\n";
}
#endif
