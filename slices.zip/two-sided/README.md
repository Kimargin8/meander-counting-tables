# A finite-horizon count of open meandric systems

**Iaroslav Argunov. Computational note, 22 November 2026.**

Let $S_m$ count open meandric systems on $m$ ordered crossings, with both ends of the slice open and with every closed component excluded. The crossing word records, separately on each bank, a left or a right end of an arch. A closing symbol without an available opening goes to the exterior on the left. An unclosed opening goes to the exterior on the right. The two banks are labelled. Reflected words retain their full multiplicity. Bobier and Sawada give this four-letter model in Section 2 of their paper and generate its systems with constant amortized time per output. Andrew Howroyd's b-file for A060111 extends to $m=40$. [Bobier and Sawada](https://www.cis.uoguelph.ca/~sawada/papers/meander.pdf) · [OEIS entry](https://oeis.org/A060111) · [Howroyd's table](https://oeis.org/A060111/b060111.txt)

| Crossings | Exact count | Checks |
| ---: | ---: | --- |
| 40 | 26333137453486453641133 | published b-file, forward transfer, backward transfer |
| 41 | 94539070239841754531660 | forward and backward transfers |
| 42 | 339316547235758417371275 | forward and backward transfers |
| 43 | 1217708185024950167648000 | forward and backward transfers |
| 44 | 4368921991789927753013287 | integer forward transfer and reconstructed backward transfer |

Each computation used a single local CPU process. The three backward runs at 41, 42 and 43 crossings took 24.1, 37.6 and 49.2 seconds and reached 325, 568 and 878 MiB of resident memory, respectively. Times are rounded and depend on the machine and its concurrent workload. The accompanying JSON files give the individual measurements.

Bacher studied the associated graded algebra. Transfer matrices that record the connectivity at a cut have a long history in meander enumeration. Di Francesco, Guitter and Jacobsen describe the four local motions and count intermediate signatures for their closed problem in Section 3.1. Here the two exterior boundaries are open, and retaining only the ends within reach of the remaining letters makes the finite computation exact. [Bacher, *Meander algebras*](https://www-fourier.univ-grenoble-alpes.fr/sites/default/files/ref_478.pdf) · [Di Francesco, Guitter and Jacobsen](https://arxiv.org/abs/cond-mat/0003008)

## What the boundary remembers

At a cut after $t$ crossings, the active ends on each bank form a stack, ordered by distance from the cut. Known pairs are the ends of a path traced through the prefix. All other ends extend to the left or have lost their partner under projection. To process an opening on both banks, push a new pair. A horizontal move transfers one end from one bank to the other. A closing on both banks removes their top ends and joins their former partners when both are known. If the two top ends are paired to each other, this crossing closes a component and the word is rejected.

Retain at most $k_t=\min(t,m-t)$ ends per bank. A crossing changes the depth of a surviving end by at most one. Every arc belonging to an internal cycle starts and ends within the word. Its active end at cut $t$ has depth at most $t$ by the prefix length and at most $m-t$ by the number of remaining steps. Thus all edges of every internal cycle survive until it closes. A dropped pair only removes a connection. Together these two observations give exact acceptance at length $m$. Equivalently, before the midpoint the bound $t$ retains every physical end and afterwards a discarded end cannot move back into a window shrinking by one at every crossing.

For a sharper count of states, delete exterior singletons beyond the last paired end on each bank. Write $a,b$ for the resulting lengths and $j$ for the number of pairs going from one bank to the other. In the full prefix, each component with two ends on the same bank consumes at least two crossings. A component joining different banks consumes at least one. A singleton in either retained stack belongs to its own component with a physical crossing, since the untouched exterior terminals lie behind every physical end. Summing over disjoint components gives $a+b-j\le t$. Projection preserves this bound. Every cross-bank pair lost in a projection accounts for at least one deleted end. In particular, every reachable state satisfies

$$
a,b\le m-t,\qquad a+b-j\le t .
$$

Noncrossing connectivity implies that an unmatched end cannot lie under a known arch. Scanning each bank from its outside towards the cut therefore gives up/down steps with a horizontal step allowed only at height zero. Each trimmed nonempty bank begins with an up step and ends at height $j$. Joining the unmatched up steps of two such paths in their unique noncrossing order recovers the state. Reflecting across the river exchanges the two halves and permutes the four letters. Either representative yields the same multiset of successor orbits, so weights in an orbit can be added without dividing the count.

## Addresses and complexity

Unfold a horizontal step at height zero as a crossing between signed heights 0 and $-1$. The positive and negative excursions on the two sides unfold uniquely. For a half of length $a>0$ and internal crossing count $j$, the signed endpoint $h$ is the member of $\{j,-j-1\}$ of the same parity as $a$. The number of possible halves is

$$
L(a,j)=\binom{a-1}{(a+h)/2-1},
\qquad L(0,0)=1.
$$

Out-of-range binomial coefficients are zero. For $a<b$ a sector has $L(a,j)L(b,j)$ addresses. At $a=b$ it has $L(a,j)(L(a,j)+1)/2$ addresses after reflection. The programs enumerate feasible sectors under the two inequalities above and use direct integer addresses. Some addresses correspond to unreachable states. At $m=41$ the largest layer has 44,890,458 addresses and 37,539,442 positive prefix weights.

There is also an all-length bound. Set $C(x)=1+xC(x)^2$, the generating function for Dyck paths counted by pairs, and $D(x)=1/(1-x-x^2C(x^2))$. Here $D$ counts arbitrary outer strings of horizontal singletons and irreducible arches. Each of the $j$ cross-bank pairs leaves an interior Dyck interval on both banks. With weight $z^{3(a+b)-2j}$, all such types are coefficientwise bounded by

$$
\frac{D(z^3)^2}{1-z^4 C(z^6)^2}.
$$

Allowing untrimmed outer strings only enlarges the series. Since $3(a+b)-2j \le 2((a+b-j)+\max(a,b))\le 2m$, only weights up to $2m$ contribute. The first positive pole occurs at $z=\phi^{-1/2}$, where $\phi=(1+\sqrt5)/2$. Indeed $z^2+z^4=1$, $C(z^6)=z^{-2}$, and $z^3<1/2$. The pole is simple and precedes the square-root singularities. Bounding coefficients on a slightly smaller circle, for instance at $z=\phi^{-1/2}(1-1/m)$ for $m>1$, yields $O^*(\phi^m)$ reachable or candidate types; $O^*$ suppresses polynomial factors in $m$. Each transfer uses polynomially many bit operations per address, with counts at most $4^m$. This is a bound for computing a count, whereas Bobier and Sawada generate each object.

## Independent checks

The forward program scans a list of old arches, relocates each pair and sums multiplicities at its target. The backward program counts completions. It updates bit masks across a fixed central gap, locates a partner locally on demand, and removes any pair meeting the exterior of the new window. Its increasing/decreasing signed half codes, sector order, and arithmetic differ from those in the forward program. Both derive their state space from the finite-horizon lemma. Agreement checks their implementations. The proof above and comparison with published values provide complementary evidence for the shared mathematical model.

The forward reader stores small values inline and promotes larger values into exact 128-bit arithmetic. The fixed implementations accept at most 47 crossings, for which $4^{47}=2^{94}$. The backward reader checks each assignment against the width of its packed coefficient. The small auxiliary sparse implementation in `finite.cpp` also counts without direct addresses and supports disabling bank reflection.

## Reproduction

Use a C++20 compiler with unsigned 128-bit integers, such as GCC or Clang on x86-64 Linux. The measured build used GCC 13.3.0 on Ubuntu under WSL. From the directory containing the sources, run the programs in sequence. Each prints an exact decimal integer in the `total` field.

~~~sh
g++ -O3 -march=native -std=c++20 ranked.cpp -o forward
g++ -O3 -march=native -std=c++20 audit.cpp -o backward
for m in 40 41 42 43; do ./forward "$m"; done
for m in 40 41 42 43; do ./backward "$m"; done
~~~

The optional sparse check can be reproduced on a smaller example.

~~~sh
g++ -O3 -march=native -std=c++20 finite.cpp -o sparse
./sparse 24 100000
./sparse 24 100000 --unfold
~~~

Both invocations return 33430012251123. A public priority claim would require a further review of independent tables and implementations.

The archive also includes a literal oracle. It builds both bank matchings directly on the crossings of a word and detects a cycle by joining their connected components. The next command tests all four-letter words through eight crossings against several fixed windows and checks the connected closed counts through order seven.

~~~sh
python3 literal/literal.py --out literal-check.json
~~~

See the [44-crossing calculation](order44.md) for its separate reproduction instructions.
