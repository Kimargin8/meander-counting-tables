# Extending the count to 44 crossings

The backward transfer gives

$$
S_{44}=4\,368\,921\,991\,789\,927\,753\,013\,287 .
$$

At the cut after 23 crossings, every suffix has exactly 21 letters. The number of valid completions of any particular boundary is at most $4^{21}=4\,398\,046\,511\,104$. Compute all suffix counts backward to that cut modulo 65521, 65519 and 65497. These moduli are pairwise coprime and their product exceeds $4^{21}$. Chinese remaindering therefore recovers the complete integer at each individual address. The earlier 23 steps then use integer arithmetic through to the empty initial state. The same calculation at 24 crossings reproduces the published entry 33430012251123.

There are 42,739,486 addresses at the cut. Each of the three binary arrays occupies 85,479,012 bytes including its header. The largest measured resident set for these passes was 730,964 KiB. The three intermediate arrays have independent SHA-256 digests in the included summary; a fresh run regenerates them.

To reproduce this decomposition on Linux, run the following from the directory containing the sources. It uses Python 3.11 or later and GNU time.

~~~sh
g++ -O3 -march=native -std=c++20 audit.cpp -o backward
mkdir -p checks work
python3 split.py ./backward 44 23 --work work --out checks --memory-mib 900
~~~

The forward program independently returned the same integer in 101.425 seconds, with a peak resident set of 782,156 KiB. When both numerical layers would exceed the memory budget together, it writes the older array to an anonymous temporary file, releases its memory and reads it once in address order. Its new layer remains available for random updates. The run wrote and read 3,359,119,932 bytes in total in each direction; its largest temporary file occupied 785,728,300 bytes.

~~~sh
g++ -O3 -march=native -std=c++20 ranked.cpp -o forward
./forward 44 --stream
~~~

The last command below checks the full forward answer modulo 65479. This modulus differs from the three used above. The measured residue was 65020, the reduction of the full integer.

~~~sh
g++ -O3 -march=native -std=c++20 -DSLICE_MOD=65479 ranked.cpp -o forward-mod
./forward-mod 44
~~~
