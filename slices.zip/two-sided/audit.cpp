// Independent backward reader. Endpoints have fixed coordinates around 31|32.
// It unfolds signed walks from the OUTSIDE of either bank, with descending
// half codes and a separate sector ordering. No production code is included.
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using U=std::uint64_t;using I=std::uint32_t;using Big=__uint128_t;
constexpr U west=(U(1)<<32)-1;
constexpr I invalid=~I(0);
constexpr int extent=25;
struct Pair {U open=0,close=0;};
struct Half {I open,close;};
struct Code {int n,j;I rank;};
U bit(int i){return U(1)<<i;}
std::array<unsigned char,256> byte_reverse;
std::array<std::array<unsigned char,256>,256> byte_signed;
void make_bytes() {
    for(int a=0;a<256;++a) {
        for(int i=0;i<8;++i) if(a&(1<<i)) byte_reverse[a]|=1<<(7-i);
        for(int c=0;c<256;++c) {
            bool positive=true;
            for(int i=0;i<8;++i) {
                if(bool(a&(1<<i))==positive) byte_signed[a][c]|=1<<i;
                if(!((a|c)&(1<<i))) positive=!positive;
            }
        }
    }
}
I mirror(I v) {
    return I(byte_reverse[v&255])<<24 | I(byte_reverse[(v>>8)&255])<<16 |
           I(byte_reverse[(v>>16)&255])<<8 | byte_reverse[v>>24];
}
class Halves {
    std::array<std::vector<I>,extent> addresses;
    int maximum=0;
public:
    std::array<std::array<std::vector<Half>,extent>,extent> catalog;
    Halves() {catalog[0][0].push_back({0,0});}
    void ensure(int n) {
        for(int a=maximum+1;a<=n;++a) {
            auto& addr=addresses[a];I size=1u<<(a-1);addr.resize(size);
            for(I pass=0;pass<size;++pass) {
                I code=2*(size-pass)-1;
                I open=0,close=0;
                int h=0;
                for(int i=0;i<a;++i) {
                    int h1=h+(((code>>i)&1)?1:-1);
                    int old_depth=(h<0)?~h:h;
                    int new_depth=(h1<0)?~h1:h1;
                    if(new_depth>old_depth) open|=1u<<i;
                    if(new_depth<old_depth) close|=1u<<i;
                    h=h1;
                }
                auto& group=catalog[a][h<0?~h:h];
                addr[code/2]=group.size();
                group.push_back({open,close});
            }
        }
        maximum=std::max(maximum,n);
    }
    Code decode(I o,I c) const {
        if(!(o|c)) return {0,0,0};
        int first=std::countr_zero(o|c), n=32-first;
        o>>=first;c>>=first;
        int j=std::popcount(o)-std::popcount(c);
        I word=0;bool negative=false;
        for(int i=0;i<n;i+=8) {
            auto a=(o>>i)&255,b=(c>>i)&255;
            auto piece=byte_signed[a][b]^(negative?255:0);
            word|=I(piece)<<i;negative^=(std::popcount(a|b)&1);
        }
        word&=(1u<<n)-1;
        if(!(word&1) || j<0 || j>n) throw std::logic_error("half not in catalog");
        return {n,j,addresses[n][word>>1]};
    }
};

// Find the precisely matching bracket of one marked endpoint, skipping all
// singletons. This reader never constructs a complete list of old pairs.
int partner(const Pair& w,int i) {
    int depth=1;
    U occ=w.open|w.close;
    if(w.open&bit(i)) {
        U to_right=occ&~(bit(i)|(bit(i)-1));
        while(to_right) {
            int p=std::countr_zero(to_right);to_right&=to_right-1;
            depth+=(w.open&bit(p))?1:-1;
            if(!depth) return p;
        }
    } else {
        U to_left=occ&(bit(i)-1);
        while(to_left) {
            int p=63-std::countl_zero(to_left);to_left^=bit(p);
            depth+=(w.close&bit(p))?1:-1;
            if(!depth) return p;
        }
    }
    throw std::logic_error("partner missing");
}
Pair crop(Pair w,U allowed) {
    U outside=(w.open|w.close)&~allowed;
    while(outside) {
        int i=std::countr_zero(outside),j=partner(w,i);
        U keep=~(bit(i)|bit(j));
        w.open&=keep;w.close&=keep;outside&=keep;
    }
    return w;
}
bool close(Pair& w) {
    if((w.open&bit(31)) && (w.close&bit(32))) return false;
    int a=(w.open|w.close)&bit(31)?partner(w,31):-1;
    int b=(w.open|w.close)&bit(32)?partner(w,32):-1;
    U remove=bit(31)|bit(32);
    if(a>=0) remove|=bit(a);
    if(b>=0) remove|=bit(b);
    w.open&=~remove;w.close&=~remove;
    if(a>=0 && b>=0) {w.open|=bit(std::min(a,b));w.close|=bit(std::max(a,b));}
    w.open=((w.open&west)<<1)|((w.open&~west)>>1);
    w.close=((w.close&west)<<1)|((w.close&~west)>>1);
    return true;
}
struct Sector {int a,b,j;I start;};
class Backward {
    Halves& halves;
    int k,remaining,prime;
    std::array<std::array<std::array<I,extent>,extent>,extent> offsets;
    std::vector<Sector> sectors;
    std::vector<I> low,high32;
    std::vector<std::uint8_t> high8;
    std::vector<std::uint16_t> high16;
    std::vector<U> high64;
    std::vector<std::uint16_t> residues;
    static int bytes(int r) {
        if(r<=17) return 4;
        if(r<=19) return 5;
        if(r<=23) return 6;
        if(r<=31) return 8;
        return 12;
    }
    Big get(I i) const {
        if(prime) return residues[i];
        switch(bytes(remaining)) {
        case 4:return low[i];
        case 5:return (U(high8[i])<<32)|low[i];
        case 6:return (U(high16[i])<<32)|low[i];
        case 8:return (U(high32[i])<<32)|low[i];
        default:return (Big(high64[i])<<32)|low[i];
        }
    }
    void set(I i,Big value) {
        if(prime) {
            if(value>4u*unsigned(prime)) throw std::overflow_error("modular reader input");
            I v=I(value);
            while(v>=I(prime)) v-=prime;
            residues[i]=std::uint16_t(v);return;
        }
        int width=bytes(remaining);
        if(value>>(8*width)) throw std::overflow_error("suffix count exceeds packed range");
        low[i]=I(value);
        switch(width) {
        case 5:high8[i]=value>>32;break;
        case 6:high16[i]=value>>32;break;
        case 8:high32[i]=value>>32;break;
        case 12:high64[i]=value>>32;break;
        }
    }
    I index(Pair w) const {
        Code a=halves.decode(I(w.open),I(w.close));
        Code b=halves.decode(mirror(w.close>>32),mirror(w.open>>32));
        if(a.j!=b.j) throw std::logic_error("crossing count mismatch");
        if(a.n>b.n || (a.n==b.n && a.rank>b.rank)) std::swap(a,b);
        I base=offsets[a.j][b.n][a.n];
        if(base==invalid) return invalid; // irrelevant source on the preceding layer
        return base+I(a.n==b.n ? U(b.rank)*(b.rank+1)/2+a.rank :
                         U(a.rank)*halves.catalog[b.n][a.j].size()+b.rank);
    }
public:
    U allowed;
    Backward(Halves& h,int t,int m,int modulus=0):halves(h),k(std::min(t,m-t)),remaining(m-t),prime(modulus),
        allowed((bit(2*k)-1)<<(32-k)) {
        halves.ensure(k);
        for(auto& rows:offsets) for(auto& row:rows) row.fill(invalid);
        U count=0;
        for(int j=0;j<=k;++j) for(int b=j;b<=k;++b) for(int a=j;a<=b;++a) {
            auto x=h.catalog[a][j].size(),y=h.catalog[b][j].size();
            if(!x || !y || a+b-j>t) continue;
            offsets[j][b][a]=I(count);sectors.push_back({a,b,j,I(count)});
            count+=a==b?x*(x+1)/2:x*y;
            if(count>=invalid) throw std::overflow_error("sector index too large");
        }
        if(prime) {residues.resize(count);return;}
        low.resize(count);
        switch(bytes(remaining)) {
        case 5:high8.resize(count);break;
        case 6:high16.resize(count);break;
        case 8:high32.resize(count);break;
        case 12:high64.resize(count);break;
        }
    }
    void terminal(){set(0,1);}
    Big answer() const{return get(0);}
    void dump(const std::string& path,int m,int t) const {
        if(!prime) throw std::logic_error("residues required");
        std::ofstream out(path,std::ios::binary);
        std::array<U,5> header{0x31414d5353343452ULL,U(m),U(t),U(prime),residues.size()};
        out.write(reinterpret_cast<const char*>(header.data()),sizeof(header));
        out.write(reinterpret_cast<const char*>(residues.data()),residues.size()*sizeof(residues[0]));
        if(!out) throw std::runtime_error("seam write failure");
    }
    void recover(char** files,int m,int t) {
        // Mixed-radix Chinese remainder reconstruction, streamed in address order.
        std::array<std::ifstream,3> ins;
        std::array<U,3> moduli{},inverse{};
        U product=1;
        for(int j=0;j<3;++j) {
            ins[j].open(files[j],std::ios::binary);
            std::array<U,5> h{};ins[j].read(reinterpret_cast<char*>(h.data()),sizeof(h));
            if(!ins[j] || h[0]!=0x31414d5353343452ULL || h[1]!=U(m) || h[2]!=U(t) ||
               h[3]<2 || h[3]>65535 || h[4]!=low.size()) throw std::runtime_error("invalid seam header");
            moduli[j]=h[3];
            for(U x=1;x<h[3];++x) if((product%h[3])*x%h[3]==1) {inverse[j]=x;break;}
            if(!inverse[j]) throw std::runtime_error("moduli not coprime");
            product*=h[3];
        }
        Big upper=Big(1)<<(2*(m-t));
        if(upper>=product) throw std::runtime_error("insufficient CRT range");
        constexpr size_t block=8192;
        std::array<std::array<std::uint16_t,block>,3> buf;
        for(size_t at=0;at<low.size();at+=block) {
            size_t n=std::min(block,low.size()-at);
            for(int j=0;j<3;++j) {
                ins[j].read(reinterpret_cast<char*>(buf[j].data()),2*n);
                if(!ins[j]) throw std::runtime_error("truncated seam");
            }
            for(size_t i=0;i<n;++i) {
                U v=0,mult=1;
                for(int j=0;j<3;++j) {
                    U q=moduli[j],residue=buf[j][i];
                    if(residue>=q) throw std::runtime_error("invalid residue");
                    U correction=((residue+q-v%q)*inverse[j])%q;
                    v+=mult*correction;mult*=q;
                }
                if(v>upper) throw std::runtime_error("reconstructed coefficient exceeds word count");
                set(at+i,v);
            }
        }
        for(auto& in:ins) if(in.peek()!=std::char_traits<char>::eof()) throw std::runtime_error("excess seam data");
    }
    Big lookup(Pair w) const {
        I p=index(crop(w,allowed));
        return p==invalid?Big(0):get(p);
    }
    void apply(const Backward& future) {
        for(auto [a,b,j,offset]:sectors) {
            auto& lhs=halves.catalog[a][j];auto& rhs=halves.catalog[b][j];
            for(I outer=0;outer<(a==b?rhs.size():lhs.size());++outer)
                for(I inner=0;inner<(a==b?outer+1:rhs.size());++inner) {
                    Half left=lhs[a==b?inner:outer],right=rhs[a==b?outer:inner];
                    unsigned shift=b?32-b:0;
                    Pair w{(U(left.open)<<(32-a))|(U(mirror(right.close)>>shift)<<32),
                           (U(left.close)<<(32-a))|(U(mirror(right.open)>>shift)<<32)};
                    Big n=future.lookup({w.open<<1,w.close<<1})+
                          future.lookup({w.open>>1,w.close>>1});
                    Pair u{((w.open&west)>>1)|((w.open&~west)<<1)|bit(31),
                           ((w.close&west)>>1)|((w.close&~west)<<1)|bit(32)};
                    n+=future.lookup(u);
                    if(close(w)) n+=future.lookup(w);
                    set(offset++,n);
                }
        }
    }
};
std::string decimal(Big x) {
    std::string s;do{s.push_back('0'+x%10);x/=10;}while(x);
    std::reverse(s.begin(),s.end());return s;
}
int main(int argc,char**argv) {
    bool modular=argc==6 && std::string(argv[2])=="--residue";
    bool merge=argc==7 && std::string(argv[2])=="--reconstruct";
    if(argc!=2 && !modular && !merge) throw std::invalid_argument("length [--residue t modulus file | --reconstruct t file1 file2 file3]");
    int m=std::stoi(argv[1]);
    if(m<0 || m>47) throw std::invalid_argument("unsupported length");
    int seam=argc>2?std::stoi(argv[3]):0, modulus=modular?std::stoi(argv[4]):0;
    if(seam<0 || seam>m || (modular && (modulus<2 || modulus>65535))) throw std::invalid_argument("invalid seam");
    make_bytes();Halves halves;
    auto start=std::chrono::steady_clock::now();
    int initial=merge?seam:m, final=modular?seam:0;
    auto layer=std::make_unique<Backward>(halves,initial,m,modulus);
    if(merge) layer->recover(argv+4,m,seam);else layer->terminal();
    for(int t=initial-1;t>=final;--t) {
        auto previous=std::make_unique<Backward>(halves,t,m,modulus);
        previous->apply(*layer);layer=std::move(previous);
    }
    std::cout<<"{\"length\":"<<m;
    if(modular) {
        layer->dump(argv[5],m,seam);
        std::cout<<",\"cut\":"<<seam<<",\"modulus\":"<<modulus;
    } else std::cout<<",\"total\":\""<<decimal(layer->answer())<<"\"";
    std::cout<<",\"seconds\":"
             <<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"}\n";
}
