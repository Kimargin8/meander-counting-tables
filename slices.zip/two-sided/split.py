"""Exact per-state CRT on the short-suffix side of one prescribed cut."""
import argparse
import hashlib
import json
import resource
import subprocess
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary",type=Path)
    parser.add_argument("length",type=int)
    parser.add_argument("cut",type=int)
    parser.add_argument("--work",type=Path,default=Path("work"))
    parser.add_argument("--out",type=Path,default=Path("checks"))
    parser.add_argument("--memory-mib",type=int,default=900)
    args=parser.parse_args()
    memory=args.memory_mib<<20
    resource.setrlimit(resource.RLIMIT_AS,(memory,memory))
    args.work.mkdir(parents=True,exist_ok=True)
    prefix=f"m{args.length}-cut{args.cut}"
    moduli=(65521,65519,65497)
    record={"length":args.length,"cut":args.cut,"memory_limit_mib":args.memory_mib,"passes":[]}
    paths=[]
    for stage in (*moduli,None):
        if stage is not None:
            name=f"{prefix}-p{stage}"
            data=args.work/(name+".bin")
            arguments=["--residue",str(args.cut),str(stage),str(data)]
        else:
            name=prefix+"-exact"
            arguments=["--reconstruct",str(args.cut),*map(str,paths)]
        timing=args.work/(name+".timing")
        cache=args.out/(name+".json")
        command=["/usr/bin/time","-f","%M","-o",str(timing),str(args.binary.resolve()),
                 str(args.length),*arguments]
        stdout=subprocess.check_output(command,text=True)
        result=json.loads(stdout)
        result["rss_kib"]=int(timing.read_text().strip())
        if stage is not None:
            with data.open("rb") as stream:
                result["sha256"]=hashlib.file_digest(stream,"sha256").hexdigest()
            result["bytes"]=data.stat().st_size
            paths.append(data)
        cache.write_text(json.dumps(result,indent=2)+"\n")
        record["passes"].append(result)
        print(name,result,flush=True)
    (args.out/(prefix+"-summary.json")).write_text(json.dumps(record,indent=2)+"\n")


if __name__=="__main__":
    main()
