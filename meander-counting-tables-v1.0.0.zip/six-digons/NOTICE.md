# Rights and sources
Copyright © 2026 Iaroslav Argunov. Original programs are licensed under the [MIT License](licenses/MIT.txt). Original explanatory text and new results are licensed under [CC BY 4.0](licenses/CC-BY-4.0.txt).
The reference sequences [A300901](https://oeis.org/A300901) and [A301940](https://oeis.org/A301940) are due to Vincent Delecroix and the contributors identified by OEIS. The reference files and the combined table data/b301940.txt, which includes the existing prefix, are supplied under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).

Full share-alike text: [CC BY-SA 4.0](licenses/CC-BY-SA-4.0.txt).
