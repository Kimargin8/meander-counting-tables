// Independent construction using plane trees with suppressed bivalent vertices.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>

using Count=std::uint64_t;
using Mates=std::array<unsigned char,120>;
using Half=std::array<unsigned char,60>;

// An arm is a string of nested pairs. At the central chain of an H-shaped
// tree, its two sides surround the two arms at the opposite trivalent vertex.
void insert_wrap(Mates& partner,int start,int end,int depth) {
    for (int i=0;i<depth;++i) {
        partner[start+i]=end-i;
        partner[end-i]=start+i;
    }
}

Mates shape(int a,int b,int c,int d,int stem) {
    Mates result{};
    int n=a+b+c+d+stem;
    insert_wrap(result,0,2*a-1,a);
    insert_wrap(result,2*a,2*(a+b)-1,b);
    int boundary=2*(a+b);
    insert_wrap(result,boundary,2*n-1,stem);
    int start=boundary+stem;
    insert_wrap(result,start,start+2*c-1,c);
    start+=2*c;
    insert_wrap(result,start,start+2*d-1,d);
    return result;
}

Half map_half(const Mates& row,int n,int shift,int parity) {
    Half out{};
    int size=2*n;
    for (int i=0;i<n;++i) {
        int at=(2*i+parity-shift+size)%size;
        out[i]=((row[at]+shift)%size)/2;
    }
    return out;
}

// A rotated path bank sends odd site 2s+1 to even site 2(t-s mod n).
Count path_partners(const Half& perm,int n) {
    Count result=0;
    for(int t=0;t<n;++t) {
        int i=n-1,length=0;
        do {
            i=t-perm[i];
            if(i<0) i+=n;
            ++length;
        } while(i!=n-1);
        result+=length==n;
    }
    return result;
}

struct Tripod {
    int period;
    Half forward;
};

void count(int n) {
    std::vector<Tripod> lower;
    std::vector<Half> upper;
    for(int a=1;a<n-1;++a) for(int b=1;a+b<n;++b) {
        int c=n-a-b;
        std::array<int,3> current{a,b,c};
        if(current>std::array<int,3>{b,c,a} || current>std::array<int,3>{c,a,b}) continue;
        int period=(a==b && b==c)?(2*n/3):2*n;
        auto three=shape(a,b,c,0,0);
        lower.push_back({period,map_half(three,n,0,0)});
        for(int shift=0;shift<period;++shift) upper.push_back(map_half(three,n,shift,1));
    }
    assert(upper.size()==Count(n)*(n-1)*(n-2)/3);
    Count yy=0,py=0,star=0,branched=0;
    for(const auto& bank:lower) {
        Count connected=0;
        for(const auto& inverse:upper) {
            int start=n/2,i=start,length=0;
            do {
                i=inverse[bank.forward[i]];
                ++length;
            } while(i!=start);
            connected+=length==n;
        }
        yy+=bank.period*connected;
        py+=bank.period*path_partners(bank.forward,n);
    }
    for(int a=1;a<=n-3;++a) for(int b=1;a+b<=n-2;++b)
        for(int c=1;a+b+c<n;++c) for(int d=1;a+b+c+d<=n;++d) {
            int stem=n-a-b-c-d;
            auto four=shape(a,b,c,d,stem);
            auto forward=map_half(four,n,0,0);
            Count value=path_partners(forward,n);
            if(stem==0) star+=value; else branched+=value;
        }
    // All label origins, divided by the four choices of first arm at the
    // star or by the two choices of directed central chain.
    assert((2*n*star)%4==0);
    Count pq=2*n*star/4+n*branched;
    Count pp=0;
    for(int t=0;t<n;++t) if(std::gcd(n,t)==1) pp+=n;
    std::cout<<n<<" "<<yy<<" "<<pq<<" "<<2*py<<" "<<pp+2*py+yy<<" "<<yy+2*pq<<"\n"<<std::flush;
}

int main(int argc,char** argv) {
    if(argc!=3) return 2;
    int first=std::stoi(argv[1]),last=std::stoi(argv[2]);
    if(first<3 || last>60 || last<first) return 2;
    std::cout<<"n three_three path_four five_digons zero_deficit six_digons\n";
    for(int n=first;n<=last;++n) count(n);
}
