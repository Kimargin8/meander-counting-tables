// Count closed meanders with six cyclic digons using trees rooted at a leaf.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

using Word = std::array<unsigned char, 120>;
using Count = std::uint64_t;

void compositions(int n, int parts, std::vector<int>& prefix, std::vector<std::vector<int>>& result) {
    if (parts == 1) {
        if (n >= 1) {
            result.push_back(prefix);
            result.back().push_back(n);
        }
        return;
    }
    for (int first = 1; first <= n - parts + 1; ++first) {
        prefix.push_back(first);
        compositions(n-first, parts-1, prefix, result);
        prefix.pop_back();
    }
}

// The outer arc contains all other arcs. Deleting it leaves a Dyck word
// with k-1 peaks when the original tree has k geometric (unrooted) leaves.
template <class Visitor>
void leaf_rooted(int n, int k, Visitor visit) {
    std::vector<std::vector<int>> parts;
    std::vector<int> prefix;
    compositions(n-1, k-1, prefix, parts);
    for (const auto& rise : parts) {
        for (const auto& fall : parts) {
            int balance=0;
            bool feasible=true;
            for (int r=0; r<k-1; ++r) {
                balance+=rise[r]-fall[r];
                if (balance<0) { feasible=false; break; }
            }
            if (!feasible) continue;
            Word mate{}, stack{};
            int depth=0, pos=1;
            mate[0]=2*n-1;
            mate[2*n-1]=0;
            for (int r=0; r<k-1; ++r) {
                for (int i=0; i<rise[r]; ++i) stack[depth++]=pos++;
                for (int i=0; i<fall[r]; ++i) {
                    int start=stack[--depth];
                    mate[pos]=start;
                    mate[start]=pos++;
                }
            }
            assert(depth==0 && pos==2*n-1);
            visit(mate);
        }
    }
}

Word rotate(const Word& x, int n, int shift) {
    Word y{};
    for (int i=0; i<2*n; ++i) y[(i+shift)%(2*n)]=(x[i]+shift)%(2*n);
    return y;
}

bool connected(const Word& lower, const Word& upper, int n) {
    int current=0, sites=0;
    do {
        current=upper[lower[current]];
        ++sites;
    } while (current!=0);
    return sites==n;
}

Count choose(int n,int k) {
    if (n<k || k<0) return 0;
    Count value=1;
    for (int i=1; i<=k; ++i) value=value*(n-i+1)/i;
    return value;
}

Count unpoint(Count raw,int n,int k) {
    assert((raw*2*n)%k==0);
    return raw*2*n/k;
}

void count(int n) {
    std::vector<Word> paths;
    for (int s=0;s<n;++s) {
        Word p{};
        for (int i=0;i<2*n;++i) p[i]=(4*n+2*s-1-i)%(2*n);
        paths.push_back(p);
    }
    std::vector<Word> rooted_three;
    std::set<Word> three;
    leaf_rooted(n,3,[&](const Word& x) {
        rooted_three.push_back(x);
        for (int t=0;t<2*n;++t) three.insert(rotate(x,n,t));
    });
    assert(three.size()==2*choose(n,3) && three.size()==unpoint(rooted_three.size(),n,3));
    Count yy=0, py=0, pq=0, num_four=0;
    for (const Word& a:rooted_three) {
        for (const Word& b:three) yy+=connected(a,b,n);
        for (const Word& b:paths) py+=connected(a,b,n);
    }
    leaf_rooted(n,4,[&](const Word& a){
        ++num_four;
        for (const Word& b:paths) pq+=connected(a,b,n);
    });
    assert(unpoint(num_four,n,4)==2*choose(n-1,2)*choose(n,4)/(n-1));
    yy=unpoint(yy,n,3);
    py=unpoint(py,n,3);
    pq=unpoint(pq,n,4);
    Count pp=0;
    for (int t=0;t<n;++t) if(std::gcd(n,t)==1) pp+=n;
    std::cout<<n<<" "<<yy<<" "<<pq<<" "<<2*py<<" "<<pp+2*py+yy<<" "<<yy+2*pq<<"\n"<<std::flush;
}

int main(int argc,char** argv) {
    if (argc!=3) return 2;
    int first=std::stoi(argv[1]), last=std::stoi(argv[2]);
    if (first<3 || last>60 || last<first) return 2;
    // For n<=60 every count and the intermediate marked counts fit uint64:
    // the largest loop counts are bounded by 2n times (C(60,3)^2 +
    // n * C(60,4)*C(59,2)), far below 2^64.
    std::cout<<"n three_three path_four five_digons zero_deficit six_digons\n";
    for (int n=first;n<=last;++n) count(n);
}
