"""Check the six-digon table from two constructions, OEIS and small literal pairs."""
import argparse
from collections import Counter
from functools import cache
from hashlib import sha256
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory


@cache
def matchings(n):
    if n == 0:
        return [()]
    result = []
    for inside in range(n):
        partner = 2 * inside + 1
        for a in matchings(inside):
            for b in matchings(n-1-inside):
                result.append((partner, *(i+1 for i in a), 0, *(i+partner+1 for i in b)))
    return result


def literal(n):
    banks = matchings(n)
    m = 2*n
    sizes = {row:sum(row[i] == (i+1) % m for i in range(m)) for row in banks}
    counts = Counter()
    for a in banks:
        for b in banks:
            # Ordinary graph search on the union, without using rotation or a parity orbit.
            stack = [0]
            seen = {0}
            while stack:
                x = stack.pop()
                for y in (a[x], b[x]):
                    if y not in seen:
                        seen.add(y)
                        stack.append(y)
            if len(seen) == m:
                counts[sizes[a],sizes[b]] += 1
    assert counts[2,4] == counts[4,2] and counts[2,3] == counts[3,2]
    yy, pq, five = counts[3,3], counts[2,4], counts[2,3] + counts[3,2]
    return yy, pq, five, counts[2,2]+yy+five, yy+2*pq


def table(contents):
    lines = contents.splitlines()
    assert lines[0].split() == ["n","three_three","path_four","five_digons","zero_deficit","six_digons"]
    data = {}
    for line in lines[1:]:
        n,*row = map(int,line.split())
        assert n not in data and len(row) == 5
        data[n] = tuple(row)
    return data


def reference(path):
    return {int(n):int(value) for line in path.read_text().splitlines()
            if line.strip() and not line.lstrip().startswith("#") for n,value in [line.split()]}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--data", type=Path, required=True)
    cli.add_argument("--full-replay", action="store_true")
    cli.add_argument("--write", action="store_true", help="write an OEIS-format b-file and hash receipt")
    opt = cli.parse_args()
    if not __debug__:
        raise ValueError("Use Python with assertions enabled.")
    data = opt.data
    local = Path(__file__).resolve().parent
    names = ["leaf-rooted.txt","leaf-rooted-40-60.txt","core-shapes.txt",
             "reference-b301940.txt","reference-b300901.txt"]
    first = table((data/names[0]).read_text())
    second = table((data/names[1]).read_text())
    assert not first.keys() & second.keys()
    rows = first | second
    assert sorted(rows) == list(range(3,61)) and table((data/names[2]).read_text()) == rows
    six = reference(data/names[3])
    five = reference(data/names[4])
    assert sorted(six) == list(range(3,36)) and all(rows[n][4] == value for n,value in six.items())
    assert all(rows[n][2] == five[n] for n in range(4,61))
    assert rows[39][3] == 97259526
    for n in range(3,8):
        assert literal(n) == rows[n]
    if opt.full_replay:
        with TemporaryDirectory() as folder:
            path = Path(folder)/"digon-counter"
            for file in ("digons.cpp", "digons_shapes.cpp"):
                subprocess.run(["g++","-O3","-std=c++17",str(local/file),"-o",str(path)],check=True)
                fresh = subprocess.check_output([str(path),"3","60"],text=True)
                assert table(fresh) == rows
    if opt.write:
        bfile = data/"b301940.txt"
        bfile.write_bytes("".join(f"{n} {rows[n][4]}\n" for n in sorted(rows)).encode())
        metadata = {
            "sequence":"A301940","orders":[3,60],"published_reference_orders":[3,35],
            "exact_agreement_all_five_columns":[3,60],"physical_pairs_tested_at_orders":[3,4,5,6,7],
            "A300901_reference_agrees":[4,60],
            "previous_independent_zero_deficit_at_39":rows[39][3],
            "fetched_before_submission":"2026-11-22 America/New_York",
            "reference_urls":{"A301940":"https://oeis.org/A301940/b301940.txt",
                              "A300901":"https://oeis.org/A300901/b300901.txt"},
            "range_36_60":[rows[n][4] for n in range(36,61)],
            "compiler":"g++ (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0; -O3 -std=c++17",
            "source_and_data_sha256":{p.name:sha256(p.read_bytes()).hexdigest() for p in
                                      [bfile,*[data/name for name in names], local/"digons.cpp",
                                       local/"digons_shapes.cpp",Path(__file__)]},
        }
        (data/"verified.json").write_text(json.dumps(metadata,indent=2)+"\n",encoding="utf8")
    signed = json.loads((data/"verified.json").read_bytes())
    assert reference(data/"b301940.txt") == {n:row[4] for n,row in rows.items()}
    for name,expected in signed["source_and_data_sha256"].items():
        candidate = local/name if name.endswith((".cpp",".py")) else data/name
        assert sha256(candidate.read_bytes()).hexdigest() == expected
    print("All 58 orders matched in all five columns; 33 published six-digon and 57 five-digon checks passed.")
    print("Orders 3 to 7 passed direct enumeration. A301940(39, 60):",rows[39][4],rows[60][4])


if __name__ == "__main__":
    main()
