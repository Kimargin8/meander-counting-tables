# Six cyclic digons in closed plane meanders

Iaroslav Argunov · 22 November 2026 · Computational note

Let \(D_{n;l,h}\) count connected pairs of noncrossing perfect matchings on \(2n\) cyclically ordered, individually labelled sites. The lower and upper banks have \(l\) and \(h\) arcs between cyclically adjacent sites. The arc between the last and first sites is included. For \(n\ge2\) these arcs correspond precisely to leaves of the dual plane trees. Six digons therefore means \((l,h)=(2,4),(3,3),(4,2)\), and reflection interchanges the first and last cases. Vincent Delecroix introduced the sequence A301940 in 2018. The public b-file retrieved on 22 November 2026 covers orders 3 through 35. [Sequence and definition](https://oeis.org/A301940) · [Reference b-file](https://oeis.org/A301940/b301940.txt)

| Order \(n\) | Both banks have three leaves | Lower bank has two, upper has four | Total with six digons |
|---:|---:|---:|---:|
| 35 | 49,041,230 | 17,734,710 | 84,510,650 |
| 36 | 52,666,896 | 17,084,520 | 86,835,936 |
| 37 | 69,689,426 | 25,328,202 | 120,345,830 |
| 38 | 73,895,712 | 23,879,352 | 121,654,416 |
| 39 | 96,609,318 | 35,400,222 | 167,409,762 |
| 59 | 1,262,653,690 | 474,192,086 | 2,211,037,862 |
| 60 | 1,221,107,200 | 410,323,800 | 2,041,754,800 |

### Two finite constructions

In the first construction, root a bank at a leaf corner. Removing the outermost arc leaves an ordinary Dyck word on \(2(n-1)\) sites with exactly \(k-1\) peaks when the original bank has \(k\) leaves. Generate it from ordered positive lengths of its successive up-runs and down-runs, keeping each nonnegative word once. If all banks on the other side are allowed within a rotation-invariant class, multiplying the count with first corner at a leaf by \(2n/k\) gives the full labelled count. To see this, mark a leaf of a labelled bank and rotate its corner to the origin, retaining the old origin as one of \(2n\) corners. The argument counts marked objects, including objects with rotational symmetry. For the three-versus-three count, generate all distinct rotations of the second bank. For two versus four, its second bank ranges over the \(n\) labelled paths. Following alternating edges tests connectedness.

The second construction suppresses bivalent vertices and assigns positive lengths to the remaining edges. With three leaves the core is a tripod. Its plane cyclically ordered triples of lengths have distinct rotations except when all lengths agree. With four leaves there is a degree-four star or two degree-three vertices connected by a positive chain. Marking a first star arm gives four choices. Orienting the chain in the other case gives two choices. Rooting the final decorated tree at a labelled corner supplies \(2n\) choices. At a fixed representative of one bank the algorithm counts all permitted relative rotations of its partner. Its connectedness check uses the cycle on the \(n\) even sites induced by two successive edges. In the path case this is the composition of one indexed permutation with the reflection \(x\mapsto t-x\bmod n\).

The counts agree in each of the five reported columns at all 58 orders from 3 through 60. They recover all 33 public terms of A301940 and all values of the distinct five-digon sequence A300901 in the common test range 4 through 60. Its published b-file extends through 164. An unrestricted pair enumeration with graph search verifies the five columns at every order from 3 through 7. The final 25 six-digon entries extend the reference table. [Five-digon b-file](https://oeis.org/A300901/b300901.txt)

## Reproduction
Run `python check_digons.py --data data` with Python 3.10 or later. This compares both constructions, the entire published prefix and the unrestricted enumeration through order 7. To rebuild the two C++17 counters and reproduce all orders, add `--full-replay`. Read the [complete table](data/b301940.txt) and the [license and source credits](NOTICE.md).
