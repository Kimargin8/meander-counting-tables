# Short-interval tests in open meanders

**Iaroslav Argunov** · Preprint and computational supplement.

[Manuscript](open_profiles.pdf) · [LaTeX source](open_profiles.tex)

The river has 2n+1 ordered crossings, one free ray on each bank and one connected path. The banks are distinguished. A three-site test succeeds when the sites form two consecutive short arches on opposite banks. For three starts, the most effective placement is consecutive for n = 2, 3, 4 and has both gaps equal to two for every n ≥ 5. Effectiveness is the number of paths hit by at least one of the tests. For four starts the article identifies the minimum avoidance count through n = 48 and for all sufficiently large n. The finite and eventual arguments give no explicit starting index for the latter range. The companion lattice theorem identifies the complete integer span for every closed order from four onwards.

## Reproduce the finite results

From this directory run the following with Python 3.10 or later and assertions enabled:

    python -B verify.py

The replay covers one-parity tests, the reduced transfer, physical diagram enumeration for mixed tests, the finite extremal certificates and the small lattice witnesses. It computes in a temporary directory and takes only the standard library. The placement checks cover every hit set through n = 7. An additional independent check enumerates both labelled matchings and tests every three-start placement through n = 7. Run python -B checks/placement/direct_triples.py. The primitive-arch bounds can be checked with python -B checks/primitive/check.py. For an optional independent calculation of the lattice normal forms, install SymPy and run:

    python -B checks/placement/independent_lattice.py

[Supplementary proof sources](supplement) give the sparse-start theorem (first-ray.tex), the prefix-profile inequalities (finite-prefix.tex), the consecutive parity estimates (parity.tex), the primitive-interval bound (primitive-arch.md) and the marked width estimates (marked-width.md and width-tail.tex). The reference count inputs are attributed in [DATA-SOURCES.md](DATA-SOURCES.md). Intermediate values and the programs generating the width inputs are under checks/width. To build the article use pdflatex twice, or Tectonic, on open_profiles.tex.

The article acknowledges OpenAI's ChatGPT and Codex for assistance with research, programming and preparation.
