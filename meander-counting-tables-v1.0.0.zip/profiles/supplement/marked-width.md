# A marked first arch in the width tail of a connected meander

**Iaroslav Argunov · research note · 19 November 2026**

Let \(M_N\) count ordered pairs of noncrossing perfect matchings on \(2N\) labelled sites with connected union. Let \(T_N\) count the pairs whose total number of open strands exceeds an even width \(W\ge2\) at some cut. Let \(E_N\) be the subset count in \(T_N\) with upper arch \((1,2)\). The supplied width-tail note and its finite inputs use the left-to-right Jensen transfer, its root after site 1, and the \(N-1\) aligned two-letter slots \((2,3),(4,5),\ldots,(2N-2,2N-1)\). An idle slot consists of opposite shifts of the slit and has two orientations. Either orientation leaves the full state and the maximal width unchanged when the slot is removed. Deleting whole slots preserves alignment.

**First-slot identity.** Write \(D_s\) for the number of diagrams in \(T_s\) without idle slots and \(F_s\) for the number of these with the specified upper arch. For \(N\ge2\),

\[
E_N=T_{N-1}+\sum_{s=2}^{N}\binom{N-2}{s-2}2^{N-s}F_s,
\qquad 0\le2F_s\le D_s\quad(s\ge2).
\]

If the first slot is idle, its first shift must close the upper end at site 2. Exactly one orientation does so. Removing this first slot yields an arbitrary diagram in \(T_{N-1}\). If the first slot is nonidle, it survives erasure, and its first move still closes the upper end. For each reduced diagram counted by \(F_s\), choose the other \(s-2\) surviving slots among the remaining \(N-2\), then orient the \(N-s\) insertions. This procedure recovers the original diagram uniquely. Reflection interchanges upper and lower arches and preserves reducedness and width. For \(s\ge2\) the two specified first arches would form a component on sites 1 and 2, so their events are disjoint. This proves the asserted inequality.

**Finite input.** Take \(W=30\). The earlier certificate supplies confined counts \(C_N\) and confined upper-ear counts \(B_N\) through \(N=47\), upper bounds \(H_s\) on \(D_s\) at orders 39–47, exact closed counts through \(N=38\), and exact open counts \(O_{2n}\) through \(n=29\). The closed transform

\[
T_N=\sum_{s=1}^N\binom{N-1}{s-1}2^{N-s}D_s
\]

uniquely recovers \(D_s\) through 38. Since \(E_N=O_{2N-2}-B_N\), the first-slot identity then recovers \(F_s\) through 30. For \(31\le s\le38\) only \(F_s\) varies within the interval \([0,D_s/2]\). For \(39\le s\le47\) the pair \((D_s,F_s)\) varies in the triangle with vertices \((0,0),(H_s,0),(H_s,H_s/2)\). Fractions at endpoints are harmless. The product of these sets contains every possible collection of actual counts, and the **same** point is used for every order. No probabilistic independence of the orders is assumed.

**Primitive factors.** Put \(a_n=M_{n+1}\), \(b_n=O_{2n}\), \(a_0=b_0=1\). The two displayed transforms express these numbers as affine linear forms on the product. Write \(Q(z)=1-1/\sum_{n\ge0}a_nz^n\) and \(C(z)=1-1/\sum_{n\ge0}b_nz^n\), with coefficients \(q_j,c_j\). If \(S_0\) is the fixed initial part of either ordinary series up to the first uncertain degree \(h\), then

\[
1-S^{-1}=1-S_0^{-1}+(S-S_0)S_0^{-2}\pmod{z^{2h}} .
\]

Here \(h=38\) for \(a\) and \(h=30\) for \(b\). Hence all needed coefficients through degree 46 are affine forms. The ratio of the even and odd probabilities of an ordered two-part profile in the open ensemble is \(a_n c_i c_{n-i}/(b_n q_i q_{n-i})\), by the prefix factorization of the accompanying notes. The four small factors \(c_i/q_i\), \(1\le i\le4\), are known exactly.

**Two finite certificates.** For separate bounds on positive-denominator linear quotients, the checker minimizes the denominator first. To maximize \(P/Q\), start from a vertex score \(t\), maximize \(P-tQ\), and replace \(t\) by the score of the maximizing vertex. Each group is optimized independently for the linear objective. A zero maximum certifies the exact upper bound. Otherwise the score strictly increases through a finite set of vertex scores. Minimization works in the same way. This bounds all splits with smaller part at least 5 at each of 45 and 46 by the respective targets in the table. The checker also uses the preceding universal bounds \(c_i/q_i\le1/2\) and \(b_n/a_n>3/20\).

For \(1\le i\le4\), let \(j=n-i\), \(V=(q_j,b_n,c_j,a_n)\) and take a rational target \(\tau\). Prove directly that

\[
\tau q_i V_1V_2-c_iV_3V_4>0
\]

everywhere on the same product domain. Let \(L(v,w)\) be its symmetric polarization, multiplied by a fixed positive scalar to clear denominators. The program doubles \(V\) at each vertex and evaluates \(L(V,V)\) on that scale. Choose any base point \(v_0\) at a product vertex. In group \(g\) let \(d_{g,k}\) be the four-vector change from its selected vertex to vertex \(k\). Each admissible \(V\) is \(v_0+\sum_g d_g\), with \(d_g\) a convex combination of the \(d_{g,k}\). The identity \(L(V,V)-L(v_0,v_0)=\sum_g L(V+v_0,d_g)\) gives the following lower bound for \(L(V,V)\):

\[
L(v_0,v_0)
+\sum_g\min_k\left(2L(v_0,d_{g,k})+
                   \sum_h\min_l L(d_{g,k},d_{h,l})\right).
\]

To see this, expand \(d_g\) in its vertex weights in the second argument. For each fixed vertex \(d_{g,k}\) the contribution \(L(d_h,d_{g,k})\) is at least its minimum over the vertices of group \(h\). This remains true for \(h=g\) since it is just a linear bound for the given point \(d_g\). The final minimum over \(k\) bounds the weighted average. Each of the eight signs is certified on the full product by this single inequality; the integers specifying the base point and the contribution of each group are supplied.

| Pair index \(n\) | Strict upper bound for every ordered two-part ratio |
|---:|---:|
| 45 | \(9/10\) |
| 46 | \(99/100\) |

Together with the earlier comparison through 44 and the all-order theorem for three or more parts, this gives strict suppression of all nonsingleton profiles through pair index 46. For index 47 the required confined counts at order 48 lie beyond this transfer table. The result concerns open profiles, not strict log convexity of the ordinary closed counts at these two indices.


## Computation

From the profiles directory the following commands reproduce the marked-first-arch and joint-domain computations. Each command writes its result as JSON to standard output.

    python -B checks/width/marked_ear.py checks/placement/width-inputs.zip
    python -B checks/width/joint.py checks/placement/width-inputs.zip
    python -B checks/width/check.py checks/placement/width-inputs.zip

The width-30 source tables and their generators are in checks/width. The four-member compressed input contains the tables used by the marked-domain calculation.
