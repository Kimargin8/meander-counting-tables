# Primitive intervals at a specified short arch

## Counting conventions

Use labelled, connected closed meanders with \(2n\) vertices and distinguish the upper and lower matching. Write \(M_n\) for their number and \(E_n=O_{2n}\) for the ordinary even open meandric number, with \(E_0=1\) in formal series. Put \(r=1/\mu\), \(p_n=E_{n-1}/M_n\). For \(n\ge2\) the latter is the probability of the specified upper short arch \(01\) in a uniform closed diagram. Closing the two exposed ends with one short lower arch proves this identification, after exchanging colours. Both \(M_{n-1}/M_n\) and \(E_{n-1}/E_n\) tend to \(r\), as proved in the [earlier self-contained parity manuscript](parity.tex). In particular, every fixed predecessor of \(p_n\) has the same limit along any subsequence on which \(p_n\) converges.

A template on \(2j+1\) consecutive vertices is an open path with one exposed port of each colour. A matching edge leaving a tested interval is seen as a port at its interior vertex. Contracting a template replaces it with one vertex with the same external incidences. Exposure and linear order give a unique inverse for each prescribed template. A suffix of an open template, or a proper interval of a connected closed diagram, is a template precisely when it has one exterior incidence of each colour. Indeed its restriction then consists of one path and no internal cycle, since the original diagram has a single component. A right primitive is a template of positive index \(j\) with no proper suffix of odd length at least three that is a template. Reflection defines left primitives.

## Four template series

Put \(T(z)=\sum_{j\ge0}M_{j+1}z^j\), \(U(z)=\sum_{j\ge0}E_jz^j\). In a right primitive let \(A_j\) count all possibilities, \(B_j\) those with their upper port at the right boundary, \(D_j\) those with an upper arch in the last gap, and \(J_j\) those with this arch and a lower port at the right boundary. The four series have zero constant term:
\[
 A=1-1/T,\qquad B=1-1/U,\qquad D=(U-1)/T,\qquad J=zT/U.
\]
For the first identity a template of positive size has a unique shortest template suffix of length at least three. Contract that suffix. The result is any smaller template. Conversely a prescribed right primitive inserted at the last vertex of any such template is its shortest possible suffix. For the second identity observe that the upper port lies on the last vertex of the enlarged template exactly when it does in both factors. The number of unrestricted templates with upper port there is \(E_j\), since adding a rightmost closing vertex produces a closed diagram with one specified upper ear. For \(j\ge1\), an upper ear in the last gap also occurs in \(E_j\) unrestricted templates by closing and cyclic symmetry. This last-gap property depends only on the inserted factor, proving \(U-1=DT\). The additional lower boundary-port condition becomes two consecutive specified short arches in the closed diagram, counted by \(M_j\). Under contraction it requires the terminal lower port in both factors. Hence \(zT=JU\).

Write \(A_K,B_K,D_K,J_K\) for the respective polynomials truncated at degree \(K\), evaluated at \(r\). We first work at fixed \(K\), so no interchange of size limits is needed.

## A two-sided theorem for the ear probability

For every subsequential limit \(p\) of \(p_n\), put \(\tau_K=(1-A_K)/(1-B_K)\). Then
\[
 \boxed{\displaystyle
 \frac{2D_K}{1+\mu J_K^2}\ \le\ p\ \le\
 \frac14\left(\tau_K+\frac{2r}{\tau_K}\right).}
 \tag{1}
\]
The denominators are positive for every finite cutoff and at the limit. Indeed \(B_j\le A_j\), with \(A_1=2,B_1=1\). Therefore \(B(r)\le1-r\), and \(U(r)=1/(1-B(r))\le1/r\) by monotone radial convergence. Cutting an outer upper arch of a closed diagram gives \(M_n\le E_n\). Thus \(T(r)<\infty\) and \(A(r)<1\). This also permits taking \(K\to\infty\) in (1): the sums \(D(r)\) and \(J(r)\) are finite by their series above, and \(\tau_\infty=U(r)/T(r)\).

**Upper estimate.** Fix a central vertex \(v\). Let \(Z\) mean that it has no short arch to either neighbour. Its finite probability is \(z_n=1-4p_n+2M_{n-1}/M_n\) for \(n\ge2\). For each orientation the two short opposite-colour arches at \(v\) contract to a single vertex. Define \(L\) by the existence of a right primitive of degrees \(1,\ldots,K\) immediately to the left of \(v\), ending at \(v-1\). Define \(R\) by its mirror on the right, beginning at \(v+1\). At most one such primitive can occur on a side, because the shorter would otherwise be a proper template suffix or prefix of the longer. If \(n\ge2K+2\), the two windows are disjoint.

On the subsequence in (1) set \(z=1-4p+2r\). When the left neighbour of a neutral vertex is expanded, all \(A_i\) templates leave it neutral. If its sole ear is to the left in a specified colour, exactly \(A_i-B_i\) templates break this ear. An old right ear would persist. Thus after summing over the permitted degrees
\[
 \lim\Pr(Z\cap L)=A_K z+2(A_K-B_K)(p-r).
\]
For both neighbours, a template blocks \(B_i\) choices precisely if the old vertex had an ear to that neighbour. If \(I_L,I_R\) are their indicators, their means are \(2p,2p\) and the joint mean is \(2r\) in the limit. Expanding the product of the numbers of permissible choices gives
\[
 \lim\Pr(Z\cap L\cap R)=A_K^2-4p A_KB_K+2r B_K^2 .
\]
Applying two-set inclusion--exclusion within \(Z\) gives
\[
 4(1-A_K)(1-B_K)p\le (1-A_K)^2+2r(1-B_K)^2.
\]
This proves the upper estimate.

**Lower estimate.** Fix the specified upper ear \(01\). The first event is that a right primitive ending at 1 contains this ear. The second is that a left primitive starting at 0 contains it. Each event separately has limiting probability \(D_K\). When both occur, the blocks overlap exactly in the two vertices 0 and 1. Their two lower partners cannot equal each other or pair these vertices, since that would produce an isolated doubled edge. Each block has at most one lower port, so one partner lies to the left of the common gap and the other to its right. Noncrossing forces 0 to join to the left and 1 to the right. The left template thus has its lower port at 1, and the right template has its lower port at 0. Conversely any pair of such templates glues uniquely along the common ear. Viewed as graphs, two paths have been glued along terminal segments consisting of this edge. The union is a single path with two exposed upper ports. The complement must be a connected even open path with two upper ports of its own and the joining edges are forced by cyclic noncrossing order. Connecting the ports inside the union instead would close a separate component. Thus degrees \(i,j\) give exactly \(J_iJ_j E_{n-i-j}\) closed diagrams in the intersection; here \(J_i,J_j\) denote individual coefficients. Normalization gives \(\mu p J_K^2\). The union is a subset of the specified ear event. Rearranging proves the lower bound.

## An exact finite certificate

The first six positive degrees of \(A\) are \(2,4,18,110,772,5936\), those of \(B\) are \(1,2,9,52,350,2594\). Define \(P_A=x^6-\sum_{i=1}^6 A_i x^{6-i}\), and define \(P_B\) similarly. If \(x=\mu\), the upper bound on the ordinary amplitude \(E_n/M_n\) supplied by (1) is \(P/Q\), with
\[
 P=xP_A^2+2P_B^2,\qquad Q=4P_A P_B .
\]
On \(11\le x\le12.91\) the computed positive-polynomial certificates give
\[
 P/Q<86/25,\qquad P/(xQ)<67/250,\qquad (P/Q)^2<x-53/50.
\]
The looser inequality \((P/Q)^2<x-1\) is certified on \(11\le x\le13\). For example to certify the third, form \(W=(50x-53)Q^2-50P^2\). Under \(x=(1100+1291s)/(100(1+s))\), multiplying by \([100(1+s)]^{\deg W}\) gives a polynomial all of whose coefficients are strictly positive. The other two tests use \(86Q-25P\) and \(67xQ-250P\). Positivity of \(P_A,P_B\) is checked in exactly the same way. The classical [Albert--Paterson estimates](https://doi.org/10.1016/j.jcta.2005.02.006) put \(\mu\) inside this interval. The ordinary odd-to-even limsup is consequently below 3.44, and the even-to-odd liminf exceeds \(250/67\).

The [verifier](../checks/primitive/check.py) compares direct template enumeration through 13 vertices with the coefficient formulas. It also checks the one- and two-sided finite event counts for each possible pair of degrees through 16 crossings and evaluates the polynomial certificates over the integers. [Inputs, source hashes and results](../checks/primitive/checks.json)

## Precedents and limits

Insertion of meanders, prime decompositions and endpoint closures have a substantial earlier literature. In particular, critical summability already follows from Belousov's canonical substitution theorem. By its Theorem 6 the irreducible count of bidegree \(2,3\) is \(\varphi(5)-2=2\). Put \(Y(x)=\sum_{n\ge1}O_{2n-1}x^{2n-1}\), \(V(x)=\sum_{n\ge1}O_{2n}x^{2n}\). After setting the tangency variable to zero, the irreducible-root term of Theorem 4 allows independent insertions of two odd paths and three even ones at these five sites. Its degrees are even, so \(V\ge 2Y^2V^3\) coefficientwise. It follows that \(YV\le1/\sqrt2\) on the positive radius interval. Since \(Y(x)\ge x\) and \(V(x)\ge x^2\), both are bounded at the common positive radius by monotone convergence. The terminal-primitive argument above gives a different proof and an explicit defect in the renewal denominator. [Belousov, Theorem 4](https://arxiv.org/pdf/2112.10289#page=13) · [Theorem 6](https://arxiv.org/pdf/2112.10289#page=18) · [Journal article](https://www.combinatorics.org/ojs/index.php/eljc/article/view/v33i2p28)

Inequality (1) constrains all subsequential limits. The two sides do not coincide and it does not assert the existence of the limiting probability of one fixed short ear. A separate project note gives applications to weighted counts.
