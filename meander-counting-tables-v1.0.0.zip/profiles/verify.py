"""Reproduce the finite certificates from the public inputs."""
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent / "checks"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def replay():
    if not __debug__:
        raise RuntimeError("Run with Python assertions enabled.")
    first = ROOT / "paired"
    for program, expected in [
        ("overlap_check", "overlap_check"), ("disjoint_check", "checks"),
        ("live_states", "live_states"), ("verify_mixed", "mixed_checks"),
    ]:
        output = subprocess.check_output([sys.executable, "-B", program + ".py"], cwd=first)
        if json.loads(output) != read(first / (expected + ".json")):
            raise ValueError("Numerical mismatch in " + program)
        print("Verified", program, flush=True)
    t = Fraction(11, 50)
    rows = ((1, 2*t, 0), (1, 1+t, t), (1, 2, 1))
    vector = (22, 55, 120)
    assert all(sum(a*b for a, b in zip(row, vector)) == Fraction(21, 10)*v
               for row, v in zip(rows, vector))
    assert 441**8 * 50**5 < 1138**8 * 11**5 and 625**25*12**6 < 1138**25
    placement = ROOT / "placement"
    tables = ["--tables", "b005315.txt", "b005316.txt"]
    jobs = [
        ("verify.py", tables + ["--output"], "checks.json"),
        ("maxima.py", tables + ["--width", "width-inputs.zip", "--reader-dir", ".", "--output"], "maxima.json"),
        ("ear_lattice.py", ["--output"], "ear_lattice.json"),
        ("four_windows.py", ["b005315.txt", "b005316.txt"], "four_windows.json"),
    ]
    with TemporaryDirectory() as work:
        for name, args, expected in jobs:
            out = Path(work) / expected
            subprocess.run([sys.executable, "-B", name, *args, str(out)], cwd=placement,
                           check=True, stdout=subprocess.DEVNULL)
            if read(out) != read(placement / expected):
                raise ValueError("Numerical mismatch in " + name)
            print("Verified", name, flush=True)


if __name__ == "__main__":
    replay()

