"""Check finite inputs, the induction step and every pair of starts through n=6."""
import argparse
from collections import Counter
from functools import cache
from hashlib import sha256
from itertools import combinations
import json
from math import comb
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
from check_geometry import banks, odd_paths

# Connected closed counts on 2m sites and even-open counts on 2m sites.
# I. Jensen and A. J. Guttmann, Tables 1 and 2, arXiv:cond-mat/0004321.
CLOSED = (
    1, 1, 2, 8, 42, 262, 1828, 13820, 110954, 933458, 8152860, 73424650,
    678390116, 6405031050, 61606881612, 602188541928, 5969806669034,
    59923200729046, 608188709574124, 6234277838531806, 64477712119584604,
    672265814872772972, 7060941974458061392, 74661728661167809752,
)
EVEN = (1, 1, 3, 14, 81, 538, 3926, 30694, 252939, 2172830, 19304190, 176343390)


def narayana(m, j):
    return comb(m, j) * comb(m, j - 1) // m


def few_leaf_bound(m):
    catalan = comb(2 * m, m) // (m + 1)
    peaks = sum(narayana(m, j) for j in (1, 2, 3))
    assert peaks == 1 + m * (m - 1) // 2 + m * (m - 1)**2 * (m - 2) // 12
    return catalan * peaks


@cache
def dual_degrees(bank):
    degrees = [0]
    stack = [0]
    for i, partner in enumerate(bank):
        if i < partner:
            degrees[stack[-1]] += 1
            stack.append(len(degrees))
            degrees.append(1)
        else:
            stack.pop()
    assert stack == [0]
    return tuple(degrees)


def check_positions(n):
    positions = tuple(combinations(range(2 * n - 1), 2))
    joint = Counter()
    avoided = Counter()
    upper_frequency = Counter()
    for top, bottom in odd_paths(n):
        hits = []
        for start in range(2 * n - 1):
            def exits(bank):
                return sum(not start <= mate < start + 3 for mate in bank[start:start+3])
            hits.append(exits(top) == exits(bottom) == 1)
        for i, j in positions:
            joint[i, j] += hits[i] and hits[j]
            avoided[i, j] += not (hits[i] or hits[j])
        last = len(top)
        free = top.index(-1)
        closed_bank = tuple(last if v == -1 else v for v in top) + (free,)
        upper_frequency[closed_bank] += 1
    assert sum(upper_frequency.values()) == CLOSED[n + 1]
    counts = {}
    for i, j in positions:
        d = min(3, j - i)
        expected = {1: 2*EVEN[n - 1], 2: 2*CLOSED[n - 1], 3: 4*CLOSED[n - 1]}[d]
        assert joint[i, j] == expected
        assert avoided[i, j] == CLOSED[n + 1] - 4*CLOSED[n] + expected
        counts[d] = [joint[i, j], avoided[i, j]]
    m = n + 1
    roots = squares = leaves = 0
    for bank, occurrences in upper_frequency.items():
        degrees = dual_degrees(bank)
        leaf_count = degrees.count(1)
        short = sum(mate == (i + 1) % (2 * m) for i, mate in enumerate(bank))
        assert short == leaf_count
        square = sum(d*d for d in degrees)
        assert square >= 4*m - 2 + 2*(leaf_count - 2)
        squares += occurrences * square
        roots += occurrences * degrees[0]
        leaves += occurrences * leaf_count
    assert squares == 2*m*roots == 2*m*EVEN[m]
    assert leaves == 2*m*EVEN[m - 1]
    return dict(index=n, pairs=len(positions), joint_and_avoidance_by_gap=counts,
                closed_order=m, closed=CLOSED[m], outer_marked=roots,
                cyclic_upper_leaves=leaves, upper_squared_degrees=squares)


def check():
    finite = {m: EVEN[m] - 2*CLOSED[m] for m in range(1, 12)}
    assert all(finite[m] < 0 for m in range(1, 5))
    assert all(finite[m] > 0 for m in range(5, 12))
    assert all(EVEN[m] > CLOSED[m] for m in range(2, 5))
    margins = {m: CLOSED[m] - 2*few_leaf_bound(m) for m in range(12, 24)}
    assert min(margins.values()) > 0
    assert 4**12 * 11**4 < CLOSED[12] * 5**4
    assert 25**5 * 16 < (4*11)**5
    for m in range(2, 9):
        distribution = Counter(sum(x == i+1 for i, x in enumerate(bank))
                               for bank in banks(m))
        assert all(distribution[j] == narayana(m,j) for j in range(1, m+1))
    return dict(table_source="Jensen and Guttmann, arXiv:cond-mat/0004321, Tables 1 and 2",
                even_minus_twice_closed=finite, twelve_initial_margins=margins,
                induction_integer_slack=CLOSED[12]*5**4 - 4**12*11**4,
                entropy_integer_slack=(4*11)**5 - 25**5*16,
                direct_geometry=[check_positions(n) for n in range(2, 7)],
                largest_Narayana_enumeration=8)


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Assertions must be enabled.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    options = parser.parse_args()
    results = check()
    results["source_sha256"] = sha256(Path(__file__).read_bytes()).hexdigest()
    results["generator_sha256"] = sha256(Path(sys.modules["check_geometry"].__file__).read_bytes()).hexdigest()
    text = json.dumps(results, indent=2) + "\n"
    if options.output:
        options.output.parent.mkdir(parents=True, exist_ok=True)
        options.output.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
