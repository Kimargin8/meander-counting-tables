"""Finite geometric and transfer checks of disjoint marked windows (stdlib)."""
from collections import Counter
from functools import lru_cache
from itertools import product
from math import comb
from pathlib import Path
import argparse
import json


@lru_cache(None)
def matchings(n):
    if n == 0:
        return ((),)
    out = []
    for k in range(n):
        middle = 2*k + 1
        for left, right in product(matchings(k), matchings(n-k-1)):
            out.append((middle, *(x+1 for x in left), 0, *(middle+1+x for x in right)))
    return tuple(out)


def banks(n):
    for k in range(n+1):
        for left, right in product(matchings(k), matchings(n-k)):
            yield (*left, -1, *(2*k+1+x for x in right))


def paths(n):
    choices = list(banks(n))
    upper_ends = [(bank, bank.index(-1)) for bank in choices]
    for (upper, start), lower in product(upper_ends, choices):
        sides = (lower, upper)
        vertex = start
        steps = 0
        while vertex >= 0:
            vertex = sides[steps % 2][vertex]
            steps += 1
        if steps == 2*n+1:
            yield (upper, lower)


def exit_count(bank, start, stop):
    return sum(not start <= v <= stop for v in bank[start:stop+1])


def admissible(d, start, stop):
    return all(exit_count(b, start, stop) == 1 for b in d)


def is_neutral(d):
    length = len(d[0])
    return (length >= 3 and all(b[0] >= 0 for b in d)
            and not any(admissible(d, 0, end) for end in range(2, length-1, 2)))


def triple_mask(d):
    return sum(1 << i for i in range(len(d[0])-2) if admissible(d, i, i+2))


def reduced(d):
    # A ray attaches to the closing site on the right. Signs give the two
    # half-plane directions visited by the sweep before terminal closure.
    for i in range(1, len(d[0]), 2):
        first = tuple(0 <= b[i] < i for b in d)
        last = tuple(0 <= b[i+1] < i+1 for b in d)
        if first in ((True,False), (False,True)) and last == first[::-1]:
            return False
    return True


def masks(count, start=0):
    if start >= count:
        yield 0
        return
    yield from masks(count, start+1)
    for other in masks(count, start+3):
        yield other | (1 << start)


def insert(host, guest, site):
    size = len(guest[0])
    sides = []
    for outer, inner in zip(host, guest):
        port = inner.index(-1)
        def shift(x):
            if x < site:
                return x
            if x == site:
                return site+port
            return x+size-1
        patch = tuple(shift(outer[site]) if v < 0 else v+site for v in inner)
        sides.append((*map(shift,outer[:site]), *patch, *map(shift,outer[site+1:])))
    return tuple(sides)


def avoidance(n, t, r):
    return sum(comb(n-t,k)*2**k*r[n-k] for k in range(n-t+1))


def run(maximum=6):
    a, r, neutral = [], [], []
    checked_families = checked_bins = checked_placements = checked_patterns = 0
    crossing = Counter()
    frame = tuple(tuple(-1 if (axis-v)%14 == 13 else (axis-v)%14 for v in range(13))
                  for axis in (1,5))
    assert is_neutral(frame) and exit_count(frame[0],0,5) == 4
    assert all(not 3<=b[v]<=7 for b in frame for v in range(3,8))
    for n in range(maximum+1):
        selected = Counter()
        reduced_count = neutral_count = 0
        for d in paths(n):
            mask = triple_mask(d)
            selected[mask] += 1
            reduced_count += reduced(d)
            neutral_count += is_neutral(d)
            if n <= 4:
                image = insert(frame,d,5)
                assert is_neutral(image)
                assert triple_mask(image) == mask << 5
                left, right = 5, 5+2*n
                for start in range(len(image[0])-2):
                    inside = sum(left <= i <= right for i in range(start,start+3))
                    if inside not in (1,2):
                        continue
                    side = ("both" if start<left and start+2>right else
                            "left" if start<left else "right")
                    assert not admissible(image,start,start+2)
                    crossing[f"{side}_{inside}_guest_vertices"] += 1
                checked_placements += 1
        a.append(sum(selected.values()))
        r.append(reduced_count)
        neutral.append(neutral_count)
        assert a[n] == sum(comb(n,k)*2**k*r[n-k] for k in range(n+1))
        for family in masks(max(0,2*n-1)):
            t = family.bit_count()
            histogram = [0] * (t+1)
            patterns = Counter()
            for observed, count in selected.items():
                realized = observed & family
                histogram[realized.bit_count()] += count
                patterns[realized] += count
            inclusion = sum(comb(t,k)*(-2)**k*a[n-k] for k in range(t+1))
            assert inclusion == histogram[0] == avoidance(n,t,r)
            for k, count in enumerate(histogram):
                assert count == comb(t,k)*2**k*avoidance(n-k,t-k,r)
            subset = family
            while True:
                hits = subset.bit_count()
                assert patterns[subset] == 2**hits*avoidance(n-hits,t-hits,r)
                checked_patterns += 1
                if subset == 0:
                    break
                subset = (subset-1) & family
            checked_families += 1
            checked_bins += t+1
    assert r[:4] == [1,0,4,10]
    assert a[:2] == [1,2] and neutral[:2] == [0,0]
    assert avoidance(0,0,r) == 1 and avoidance(1,1,r) == 0
    assert checked_placements and crossing["both_1_guest_vertices"] == 1
    return dict(maximum_index=maximum,odd_counts=a,reduced_returns=r,neutral_counts=neutral,
                disjoint_window_families=checked_families,individual_hit_counts=checked_bins,
                labelled_outcome_patterns=checked_patterns,
                seam_triples=dict(sorted(crossing.items())),
                neutral_frame_insertions=checked_placements)


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Enable assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = run()
    if args.check:
        assert json.loads(args.check.read_bytes()) == result
    print(json.dumps(result,indent=2))
