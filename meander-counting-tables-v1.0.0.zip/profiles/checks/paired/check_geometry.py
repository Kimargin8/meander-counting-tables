"""Check the prefix decomposition, third-site core, and insertion on odd diagrams."""
from collections import Counter
from functools import lru_cache
from itertools import product


@lru_cache(None)
def banks(n):
    if n == 0:
        return ((),)
    return tuple((2*k+1,*(v+1 for v in inside),0,*(v+2*k+2 for v in outside))
                 for k in range(n) for inside in banks(k) for outside in banks(n-1-k))


def odd_paths(j):
    for upper,lower in product(banks(j+1),repeat=2):
        vertex=0
        length=0
        while True:
            vertex=lower[upper[vertex]]
            length+=1
            if vertex==0:
                break
        if length!=j+1:
            continue
        yield tuple(tuple(v if v<len(bank)-1 else -1 for v in bank[:-1])
                    for bank in (upper,lower))


def widths(d,start):
    size=len(d[0])
    exits=[0,0]
    for site in range(start,size):
        for side in (0,1):
            mate=d[side][site]
            exits[side]+= -1 if start<=mate<site else 1
        if exits==[1,1]:
            yield site-start+1


def split(diagram,start,length):
    stop=start+length
    host=[]; guest=[]
    for bank in diagram:
        block=bank[start:stop]
        (external,)=tuple(v for v in block if not start<=v<stop)
        def shrink(v):
            if v<start: return v
            return start if v<stop else v-length+1
        host.append(tuple(shrink(v) for v in (*bank[:start],external,*bank[stop:])))
        guest.append(tuple(v-start if start<=v<stop else -1 for v in block))
    return tuple(host),tuple(guest)


def insert(host,guest,start):
    diagram=[]
    length=len(guest[0])
    for outer,inner in zip(host,guest):
        port=inner.index(-1)
        def move(v):
            if v<start: return v
            return start+port if v==start else v+length-1
        block=tuple(move(outer[start]) if v<0 else start+v for v in inner)
        diagram.append(tuple(map(move,outer[:start]))+block+tuple(map(move,outer[start+1:])))
    return tuple(diagram)


def is_primitive(d):
    return list(widths(d,0))==[1,len(d[0])]


def run(maximum=7):
    a=[]; q=[]; c=[]; u=[]; h=[]
    all_guests=[]
    cores=[]
    fibre_rows=[]
    for j in range(maximum+1):
        diagrams=set(odd_paths(j))
        all_guests.append(diagrams)
        primitives={d for d in diagrams if j and is_primitive(d)}
        unpinned={d for d in primitives if all(side[0]>=0 for side in d)}
        basic={d for d in unpinned if max(widths(d,2))==1}
        cores.append(basic)
        a.append(len(diagrams)); q.append(len(primitives))
        c.append(sum(d[0][0]==-1 for d in primitives))
        u.append(len(unpinned)); h.append(len(basic))
        fibres=Counter()
        for d in unpinned:
            length=max(widths(d,2))
            host,guest=split(d,2,length)
            r=(len(host[0])-1)//2
            assert host in cores[r] and guest in all_guests[j-r]
            assert insert(host,guest,2)==d
            fibres[r]+=1
        for r in range(4,j+1):
            for host in cores[r]:
                for guest in all_guests[j-r]:
                    image=insert(host,guest,2)
                    assert image in unpinned and max(widths(image,2))==len(guest[0])
        assert all(v==h[r]*a[j-r] for r,v in fibres.items())
        assert u[j]==q[j]-2*c[j]==sum(h[r]*a[j-r] for r in range(j+1))
        fibre_rows.append(dict(sorted(fibres.items())))
    assert h[4:8]==[6,60,580,5544] and list(zip(q[1:5],c[1:5]))==[(2,1),(4,2),(18,9),(110,52)]
    return dict(maximum_index=maximum,odd=a,primitives=q,upper_pinned=c,
                neutral=u,third_site_cores=h,counts_by_core_index=fibre_rows)
