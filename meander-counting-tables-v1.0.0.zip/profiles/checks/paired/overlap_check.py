"""Oracle on labelled paths, and exact polynomial identities for overlapping triple tests."""
from functools import cache
from math import comb
from pathlib import Path
import json
import sys

from check_geometry import odd_paths


def add(a, b, factor=1):
    c = [0]*max(len(a),len(b))
    for i,x in enumerate(a):
        c[i] += x
    for i,x in enumerate(b):
        c[i] += factor*x
    while len(c)>1 and c[-1]==0:
        c.pop()
    return tuple(c)


def mul(a, b):
    coeff = [0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            coeff[i+j] += x*y
    return tuple(coeff)


@cache
def P(n):
    if n == 0: return (1,)
    if n == 1: return (-2,1)
    return add(mul((-1,1),P(n-1)),(0,*P(n-2)),-1)


def basis(p):
    q = list(p)
    h = [0]*len(q)
    for j in reversed(range(len(q))):
        h[j] = q[j]
        for k,x in enumerate(P(j)):
            q[k] -= h[j]*x
    assert not any(q)
    return h


def runs(mask, size):
    values=[]
    length=0
    for i in range(size+1):
        if mask & (1<<i):
            length+=1
        elif length:
            values.append(length)
            length=0
    return tuple(values)


def polynomial(n, parts):
    q=(0,)*(n-sum(parts))+(1,)
    for d in parts:
        q=mul(q,P(d))
    return q


def oracle(n):
    tables = [[0]*(1<<n), [0]*(1<<max(0,n-1))]
    total=0
    for top,bot in odd_paths(n):
        total+=1
        masks=[0,0]
        for s in range(2*n-1):
            if ((top[s]==s+1 and bot[s+1]==s+2) or
                (bot[s]==s+1 and top[s+1]==s+2)):
                masks[s%2] |= 1<<(s//2)
        for parity,mask in enumerate(masks):
            tables[parity][mask] += 1
    for table in tables:
        step=1
        while step<len(table):
            for m in range(len(table)):
                if m & step: table[m] += table[m ^ step]
            step*=2
        table.reverse()
    return total,tables


def evaluate(p,moments):
    return sum(x*y for x,y in zip(p,moments))


def check(maximum=7):
    counts=[]; full=[]; cases=0; extrema=0; example={}
    for n in range(maximum+1):
        a,tables=oracle(n)
        counts.append(a)
        full.append(tables[0][-1])
        for parity,table in enumerate(tables):
            size=max(n-parity,0)
            by_size={}
            for mask,true in enumerate(table):
                pieces=runs(mask,size)
                k=sum(pieces)
                p=polynomial(n,pieces)
                assert evaluate(p,counts)==true
                h=basis(p)
                assert min(h)>=0 and evaluate(h,full)==true
                if n>k and n: assert h[1]<=h[0]
                by_size.setdefault(k,[]).append(true)
                cases+=1
            for k,values in by_size.items():
                if k == 0: continue
                r=min(k,size-k+1)
                d,rem=divmod(k,r)
                balanced=(d+1,)*rem+(d,)*(r-rem)
                assert evaluate(polynomial(n,(k,)),counts)==min(values)
                assert evaluate(polynomial(n,balanced),counts)==max(values)
                for mask,true in enumerate(table):
                    if mask.bit_count()!=k: continue
                    pieces=runs(mask,size)
                    assert (len(pieces)==1)==(true==min(values))
                    assert (len(pieces)==r and max(pieces)-min(pieces)<=1)==(true==max(values))
                extrema+=1
                if n==6 and parity==0 and k==3:
                    example=dict(index=n,tests=k,minimum=min(values),maximum=max(values),total=a)
    for a in range(11):
        for b in range(a+2,15):
            diff=add(mul(P(a+1),P(b-1)),mul(P(a),P(b)),-1)
            s=(0,)
            for j in range(b-a-1): s=add(s,P(j))
            assert diff==(0,)*a+tuple(2*x for x in s)
            assert min(basis(mul(P(a),P(b))))>=0
    mixed={}
    for n in (5,6):
        totals=[0,0]
        for top,bot in odd_paths(n):
            def hit(s):
                return (top[s]==s+1 and bot[s+1]==s+2) or (bot[s]==s+1 and top[s+1]==s+2)
            if not hit(0):
                for j,s in enumerate((1,3)):
                    totals[j] += not hit(s)
        mixed[n]=totals
    assert mixed=={5:[942,948],6:[7584,7556]}
    return dict(maximum=maximum,diagrams=counts,all_sites_avoidance=full,
                site_sets=cases,extremal_checks=extrema,example=example,mixed_pairs=mixed)


if __name__=="__main__":
    if not __debug__: raise RuntimeError("Enable assertions.")
    print(json.dumps(check(),indent=2))
