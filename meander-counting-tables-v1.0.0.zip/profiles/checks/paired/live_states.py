"""Test the four-slot inclusion by comparing complete state sets at finite cutoffs."""
from collections import Counter
import argparse
import json
from pathlib import Path

ROOT = ((1, 0), 1)


def moves(state, cap):
    # Geometry follows the mate/slit transfer in the width-55 experiment.
    mates, slit = state
    if slit > 0:
        yield "L", (mates, slit-1)
    if slit < len(mates):
        yield "R", (mates, slit+1)
    if len(mates) < cap:
        lifted = [m + 2*(m>=slit) for m in mates]
        lifted[slit:slit] = [slit+1, slit]
        yield "U", (tuple(lifted), slit+1)
    if 0 < slit < len(mates) and mates[slit-1] != slit:
        a,b = mates[slit-1:slit+1]
        out = list(mates)
        out[a],out[b] = b,a
        del out[slit-1:slit+1]
        yield "D", (tuple(m-2*(m>slit) for m in out), slit-1)


def graph(cap):
    vertices = [ROOT]
    ids = {ROOT:0}
    full, red = [], []
    for state in vertices:
        row = Counter()
        for a,middle in moves(state,cap):
            for b,last in moves(middle,cap):
                if last not in ids:
                    ids[last] = len(vertices)
                    vertices.append(last)
                j = ids[last]
                if a+b in ("LR","RL"):
                    assert last == state
                else:
                    row[j] += 1
        red.append(set(row))
        full.append(set(row) | {ids[state]})
    return full, red


def reachable(rows,horizon):
    layers=[{0}]
    for _ in range(horizon):
        layers.append({j for i in layers[-1] for j in rows[i]})
    return layers


def supports(rows,horizon):
    incoming=[set() for _ in rows]
    for i,row in enumerate(rows):
        for j in row:
            incoming[j].add(i)
    return reachable(rows,horizon), reachable(incoming,horizon)


def check_extensions():
    frontier = {ROOT}
    for _ in range(6):
        frontier.update(y for x in list(frontier) for _,y in moves(x,16))
    count = 0
    for state in frontier:
        for a,middle in moves(state,24):
            for b,last in moves(middle,24):
                if a+b in ("LR","RL"):
                    continue
                if a in "LR":
                    word = "U"+a+"D"+b
                elif b in "LR":
                    word = a+"U"+b+"D"
                else:
                    shift = "L" if middle[1] else "R"
                    inverse = "R" if shift=="L" else "L"
                    word = a+shift+inverse+b
                assert word[:2] not in ("LR","RL") and word[2:] not in ("LR","RL")
                endpoint = state
                for step in word:
                    endpoint = dict(moves(endpoint,24))[step]
                assert endpoint == last
                count += 1
    return len(frontier), count


def run():
    summary=[]
    tests=0
    unrestricted_checks=0
    for cap in (4,8,12,16):
        full,red=graph(cap)
        ff,fb=supports(full,16)
        rf,rb=supports(red,16)
        for n in range(13):
            for k in range(n+1):
                ordinary=ff[k]&fb[n-k]
                smaller=rf[k]&rb[n-k]
                padded=rf[k+2]&rb[n-k+2]
                assert smaller<=ordinary<=padded
                tests+=1
                # For a closed order n+1 the width is at most 2n for n>0:
                # reaching 2n+2 forces two coincident rainbow matchings.
                if cap>=max(2,2*n):
                    expected = ordinary - ({0} if k==1 or n-k==1 else set())
                    assert smaller == expected
                    unrestricted_checks += 1
            if cap==16 and n<=8:
                f=[len(ff[k]&fb[n-k]) for k in range(n+1)]
                r=[len(rf[k]&rb[n-k]) for k in range(n+1)]
                summary.append(dict(slots=n,full_total=sum(f),reduced_total=sum(r),
                                    full_peak=max(f),reduced_peak=max(r)))
    states, rewrites=check_extensions()
    return dict(width_caps=[4,8,12,16],max_ordinary_slots=12,
                inclusions_checked=tests,unrestricted_layers_compared=unrestricted_checks,
                rewrite_start_states=states,nonempty_slot_replacements=rewrites,
                full_horizon_examples=summary)


if __name__=="__main__":
    if not __debug__:
        raise RuntimeError("Enable assertions")
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check",type=Path)
    args=parser.parse_args()
    result=run()
    if args.check:
        assert result==json.loads(args.check.read_bytes())
    print(json.dumps(result,indent=2))
