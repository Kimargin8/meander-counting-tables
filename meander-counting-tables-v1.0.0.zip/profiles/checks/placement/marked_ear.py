"""Certified width-tail estimates with or without a prescribed first upper ear."""
import argparse
import hashlib
import json
from fractions import Fraction
from math import comb
from pathlib import Path
from zipfile import ZipFile


def choose(n, k):
    return comb(n, k) if 0 <= k <= n else 0


def weights(n, s, keep_first=False):
    if s > n:
        return 0
    offset = 2 if keep_first else 1
    return choose(n-offset, s-offset) * 2**(n-s)


def add(left, right, scale=1):
    return tuple(a + scale*b for a, b in zip(left, right, strict=True))


def primitive(ordinary, first_unknown):
    """Exact linearized primitive coefficients below twice the first unknown."""
    assert len(ordinary) <= 2*first_unknown
    size = len(ordinary[0])
    known = [ordinary[i][0] for i in range(first_unknown)]
    assert known[0] == 1 and all(not any(row[1:]) for row in ordinary[:first_unknown])
    fixed = known + [0]*(len(ordinary)-first_unknown)
    inverse = [1]
    for i in range(1, len(fixed)):
        inverse.append(-sum(inverse[j]*fixed[i-j] for j in range(i)))
    deriv = [sum(inverse[j]*inverse[i-j] for j in range(i+1))
             for i in range(len(ordinary)-first_unknown)]
    result = []
    for i in range(len(ordinary)):
        row = ((int(i == 0)-inverse[i]),)+(0,)*(size-1)
        for j in range(first_unknown, i+1):
            row = add(row, ordinary[j], deriv[i-j])
        result.append(row)
    return result


class CoreDomain:
    """Per order, D bounded, and 0 <= E <= D/2. Vertices suffice for linear forms."""

    def __init__(self, intervals):
        self.intervals = intervals

    def vertex(self, coeffs, maximize):
        choice = max if maximize else min
        result = [1]
        for i, (lo, hi) in enumerate(self.intervals):
            a, b = coeffs[2*i+1:2*i+3]
            options = [(v,u) for v in (lo,hi) for u in (0,Fraction(v,2))]
            result.extend(choice(options, key=lambda x: a*x[0]+b*x[1]))
        return result

    def quotient(self, numerator, denominator, maximize):
        def dot(c, point):
            return sum(a*b for a,b in zip(c,point,strict=True))

        point = self.vertex(denominator, False)
        assert dot(denominator,point)>0
        value = Fraction(dot(numerator,point),dot(denominator,point))
        while True:
            residual = add(numerator,denominator,-value)
            point = self.vertex(residual,maximize)
            new = Fraction(dot(numerator,point),dot(denominator,point))
            if new == value:
                return new
            assert (new > value) == maximize
            value = new


def integer_table(raw):
    return dict(tuple(map(int,line.split())) for line in raw.decode().splitlines()
                if line.strip() and not line.startswith('#'))


def build(path, exact_open_through=None, exact_closed_through=None):
    with ZipFile(path) as archive:
        source = json.loads(archive.read('data/profiles_final.json'))
        closed = integer_table(archive.read('data/b005315.txt'))
        opened = integer_table(archive.read('data/b005316.txt'))
        reverse = [line.split() for line in archive.read('data/reverse30.txt').decode().splitlines()]
    confined = {int(line[1]):int(line[2]) for line in reverse if line[0]=='C'}
    ears = {int(line[1]):int(line[2]) for line in reverse if line[0]=='B'}
    maximum = max(confined)
    last_open = min(max(opened)//2+1,exact_open_through or maximum)
    last_closed = min(max(closed),exact_closed_through or maximum)
    assert last_open <= last_closed and maximum<=2*last_open
    reduced = {1:0}
    first_ear = {}
    for n in range(2, last_closed+1):
        reduced[n] = closed[n]-confined[n]-sum(weights(n,s)*v for s,v in reduced.items())
        assert reduced[n]>=0
        if n<=last_open:
            first_ear[n] = (opened[2*(n-1)]-ears[n]-(closed[n-1]-confined[n-1])
                            -sum(weights(n,s,True)*v for s,v in first_ear.items()))
            assert 0<=2*first_ear[n]<=reduced[n]
    beyond = range(last_open+1,maximum+1)
    intervals = [(reduced[s],reduced[s]) if s in reduced else (0,source['reduced_witness'][str(s)]['core_upper'])
                 for s in beyond]
    domain = CoreDomain(intervals)
    def form(n, ear):
        if ear and n==1:
            return (1,)+(0,)*(2*len(beyond))
        base = ears[n] if ear else confined[n]
        for s in range(1,min(n,last_open)+1):
            base += weights(n-int(ear),s)*reduced[s]
            if ear and s>=2:
                base += weights(n,s,True)*first_ear[s]
        row = [base]
        for s in beyond:
            row.extend((weights(n-int(ear),s),weights(n,s,True) if ear else 0))
        return tuple(row)
    def absorb_fixed(row):
        # Fixed closed core values must be carried as constants before linearization.
        row = list(row)
        for i,(lo,hi) in enumerate(intervals):
            if lo==hi:
                row[0] += row[2*i+1]*lo
                row[2*i+1] = 0
        return tuple(row)
    a = [absorb_fixed(form(n,False)) for n in range(1,maximum+1)]
    b = [absorb_fixed(form(n,True)) for n in range(1,maximum+1)]
    q = primitive(a,last_closed)
    c = primitive(b,last_open)
    return domain,a,b,q,c,last_open,last_closed


def calculate(path):
    domain,a,b,q,c,last_open,last_closed=build(path)
    caps = [0]+[min(Fraction(1,2),domain.quotient(c[i],q[i],True)) for i in range(1,len(a))]
    rows = {}
    for n in range(2,len(a)):
        lower = domain.quotient(b[n],a[n],False)
        p = max(Fraction(3,20),lower)
        ratios = [caps[i]*caps[n-i]/p for i in range(1,n//2+1)]
        rows[n] = dict(ear_fraction_lower=str(lower),worst_upper=str(max(ratios)),
                      unproved_smaller_parts=[i for i,v in enumerate(ratios,1) if v>=1],
                      upper_by_smaller_part=[str(v) for v in ratios])
    return dict(input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                exact_last_closed=last_closed,exact_last_ear_order=last_open,
                primitive_ratio_upper=[str(x) for x in caps], rows=rows)


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    args = parser.parse_args()
    print(json.dumps(calculate(args.input),indent=2))
