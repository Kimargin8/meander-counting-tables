"""Exact face/ear certificates for the competitors to the worst three-window placement."""
import argparse
from fractions import Fraction
from hashlib import sha256
from itertools import product
from collections import Counter
import json
from math import comb
from pathlib import Path
import sys

from verify import matchings, table


def tree(mates):
    degrees = [0]
    stack = [0]
    for i, j in enumerate(mates):
        if j > i:
            degrees[stack[-1]] += 1
            stack.append(len(degrees))
            degrees.append(1)
        else:
            stack.pop()
    excess = sum((d-2)*(d-3) for d in degrees if d >= 4)
    return degrees, excess


def geometric_check():
    totals = []
    for m in range(2,8):
        mats = matchings(m)
        stats = {v:tree(v) for v in mats}
        cap = 0
        for mat in mats:
            if mat[0] == 1:
                continue
            j, k = mat[:2]
            reduced = list(mat[2:])
            reduced[j-2], reduced[k-2] = k,j
            reduced = tuple(x-2 for x in reduced)
            D = tree(reduced)[0][0]
            ds,t = stats[mat]
            # The face on the inner side of the second arch is node number 2 in preorder.
            assert D == ds[0]+ds[2]-1
            assert D*max(0, 6-t//2) <= 30
            cap += 1
        check = 0
        for above, below in product(mats, repeat=2):
            i = below[above[0]]
            length = 1
            while i:
                length += 1
                i = below[above[i]]
            if length != m:
                continue
            ds,t = stats[above]
            assert sum(d*d for d in ds)==4*m-6+2*ds.count(1)+t
            check += 1
        totals.append(dict(order=m, single_bank_contractions=cap, connected=check))
    return totals


def narayana(m, j):
    return comb(m,j)*comb(m,j-1)//m


def sparse_peaks(m):
    return sum(narayana(m,i)*narayana(m,j) for i in range(1,15) for j in range(1,16-i))


def face_certificate(closed_file,open_file):
    closed, opened = map(table,(closed_file,open_file))
    bounds = []
    for m in range(25,37):
        P = sparse_peaks(m)
        a = closed[m-1]
        assert 12*P < m*a
        bounds.append(dict(m=m, peak_pairs=P, lower_after_deletion=a))
    assert 2**28 < closed[12]
    finite = []
    for m in range(3,25):
        difference = 2*((opened[2*m]-2*closed[m])-2*(opened[2*m-2]-2*closed[m-1]))
        assert difference == 0 if m==3 else difference>0
        finite.append(difference)
    return dict(anchors=bounds,step_ratio_bound=2**28, closed_12=closed[12],
                exact_differences_m3_to_24=finite, geometry=geometric_check())


def four_score(n,pattern):
    """A lower expression, exact unless all four hits leave two marked arches."""
    pos=[0]
    for step in pattern:
        pos.append(pos[-1]+step)
    score=Counter()
    for mask in range(16):
        groups=[]
        for j,i in enumerate(pos):
            if mask & (1<<j):
                if groups and i<=groups[-1][-1]+2:
                    groups[-1].append(i)
                else:
                    groups.append([i])
        sizes=[g[-1]-g[0]+3 for g in groups]
        odd=sum(w%2 for w in sizes)
        even=len(sizes)-odd
        k=n-sum(w-1 if w%2 else w-2 for w in sizes)//2
        sign=(-1)**len([j for j in range(4) if mask&(1<<j)])
        if even<2:
            key=("E",k) if even else ("M",k+1)
            score[key]+=sign*(1 << (even+odd))
        else:
            assert mask==15 and pattern==(1,3,1)
    return score


def four_width(domain,C,E):
    patterns=sorted({min(p,p[::-1]) for p in product(range(1,4),repeat=3)})
    rows=[]
    for n in range(30,49):
        base=four_score(n,(2,2,2))
        margins={}
        for p in patterns:
            if p==(2,2,2):
                continue
            expr=four_score(n,p)
            expr.subtract(base)
            if n==48 or (n==47 and p==(1,1,1)):
                # From tree degrees E_j >= (2-3/j) M_j+2E_{j-1}.
                orders=(47,46) if n==48 and p==(1,1,1) else (n-1,)
                for j in orders:
                    weight=expr.pop(("E",j),0)
                    assert weight>=0
                    expr["M",j]+=weight*(2-Fraction(3,j))
                    expr["E",j-1]+=2*weight
            v=[0]*len(C[0])
            for (typ,i),c in expr.items():
                if c:
                    f=C[i-1] if typ=="M" else E[i]
                    v=[x+c*y for x,y in zip(v,f)]
            point=domain.vertex(v,False)
            lo=sum(x*y for x,y in zip(v,point))
            margins["".join(map(str,p))]=str(lo)
            if n in (47,48) and p==(1,1,1):
                relative=domain.quotient(v,C[n-2],False)
                assert relative > (Fraction(26,100) if n==47 else Fraction(553,10000))
        positive=all(Fraction(s)>0 for s in margins.values())
        assert positive
        record=dict(n=n, all_positive=positive, margins=margins)
        if n in (47,48):
            record["relative_111_bound"]=str(relative)
        rows.append(record)
    return rows


def width_certificate(width_file,marked_reader):
    sys.path.insert(0,str(marked_reader))
    from marked_ear import build
    domain,closed,even,*_ = build(width_file)
    rows = []
    for m in range(30,47):
        score = tuple(4*a-b-2*c for a,b,c in zip(closed[m-1],even[m],even[m-1]))
        point = domain.vertex(score,False)
        lower = sum(x*y for x,y in zip(score,point))
        relative = domain.quotient(score,closed[m-1],False)
        assert (lower>0) == (m<=43)
        rows.append(dict(m=m, exact_lower=str(lower), relative_lower=str(relative)))
    # G is the number of neutral orders-45 vertices avoiding both neighbouring single-window tests.
    m = 44
    neutral = tuple(x-2*y+2*z-4*u+12*v-8*w for x,y,z,u,v,w in
                    zip(closed[m],closed[m-1],closed[m-3],even[m],even[m-1],even[m-2]))
    score = tuple(4*a-b-2*c for a,b,c in zip(closed[m-1],even[m],even[m-1]))
    certificate = tuple(10*f-3*g for f,g in zip(score,neutral))
    lower = sum(x*y for x,y in zip(certificate,domain.vertex(certificate,False)))
    relative = domain.quotient(certificate,closed[m-1],False)
    assert lower>0 and 100*relative>86
    return dict(width_archive_sha256=sha256(width_file.read_bytes()).hexdigest(),
                domain_reader_sha256=sha256((marked_reader/"marked_ear.py").read_bytes()).hexdigest(),
                four_against_222=four_width(domain,closed,even),
                plain_rows=rows,with_neutral_at_m44=dict(multiplied_lower=str(lower),
                    relative_multiplied_lower=str(relative),scale=10,neutral_weight=3))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tables",nargs=2,required=True,type=Path)
    parser.add_argument("--width",type=Path,required=True)
    parser.add_argument("--reader-dir",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args = parser.parse_args()
    obj = dict(faces=face_certificate(*args.tables), width=width_certificate(args.width,args.reader_dir))
    args.output.write_text(json.dumps(obj,indent=2)+"\n",encoding="utf8")
