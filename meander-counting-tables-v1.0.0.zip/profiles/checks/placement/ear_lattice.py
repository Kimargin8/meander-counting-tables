"""Integer affine lattice of cyclic short-arch indicators, with exact witnesses."""
from argparse import ArgumentParser
from itertools import combinations
import json
from math import gcd
from pathlib import Path


def matchings(m):
    """Balanced parentheses via positions of opening brackets."""
    for positions in combinations(range(2*m),m):
        opening=set(positions)
        stack=[]
        arcs=[-1]*(2*m)
        for i in range(2*m):
            if i in opening:
                stack.append(i)
            elif stack:
                j=stack.pop()
                arcs[i],arcs[j]=j,i
            else:
                break
        else:
            if not stack:
                yield tuple(arcs)


def connected(pair):
    p,q=pair
    visited=set()
    i=0
    while i not in visited:
        visited.update((i,p[i]))
        i=q[p[i]]
    return i==0 and len(visited)==len(p)


def ears(pair):
    p,q=pair
    return [int((i+1)%len(p) in (p[i],q[i])) for i in range(len(p))]


def det(values):
    a=[list(row) for row in values]
    sign,divisor=1,1
    for k in range(len(a)-1):
        pivot=next((i for i in range(k,len(a)) if a[i][k]),None)
        if pivot is None:
            return 0
        if pivot!=k:
            a[pivot],a[k]=a[k],a[pivot]
            sign=-sign
        for i in range(k+1,len(a)):
            for j in range(k+1,len(a)):
                top=a[i][j]*a[k][k]-a[i][k]*a[k][j]
                assert top%divisor==0
                a[i][j]=top//divisor
        divisor=a[k][k]
    return sign*a[-1][-1]


def coloured(pair):
    return [int(j==(i+1)%len(p)) for p in pair for i,j in enumerate(p)]


def seed(m,required,colours=False):
    catalogue=list(matchings(m))
    found={}
    images=set()
    for p in catalogue:
        for q in catalogue:
            if connected((p,q)):
                v=coloured((p,q)) if colours else ears((p,q))
                mask=sum(x<<i for i,x in enumerate(v))
                images.add(mask)
                if mask in required and mask not in found:
                    found[mask]=(p,q)
    assert set(required)==set(found)
    minor=[[1,*(coloured(found[i]) if colours else ears(found[i]))] for i in required]
    determinant=det(minor)
    assert abs(determinant)==1
    return dict(order=m,masks=required,pairs=[found[i] for i in required],
                distinct_vectors=len(images),determinant=determinant)


def rainbow_pair(m):
    return tuple(tuple((a-i)%(2*m) for i in range(2*m)) for a in (1,3))


def insert_site(pair,s,reverse=False):
    result=[]
    for index,matching in enumerate(pair):
        bank=index^int(reverse)
        v=s if bank else s+2
        f=lambda i:v if i==s else i+2*int(i>s)
        p=[-1]*(len(matching)+2)
        for i,j in enumerate(matching):
            p[f(i)]=f(j)
        k=s+bank
        p[k],p[k+1]=k+1,k
        result.append(tuple(p))
    return tuple(result)


def extend_ear(pair):
    p,q=pair
    assert p[0]==1
    f=lambda i:i+2*int(i>=1)
    a,b=[-1]*(len(p)+2),[-1]*(len(q)+2)
    for i in range(len(p)):
        a[f(i)]=f(p[i])
        b[f(i)]=f(q[i])
    a[:4]=1,0,3,2
    b[1:3]=2,1
    return tuple(a),tuple(b)


def validate(pair):
    for p in pair:
        stack=[]
        for i,j in enumerate(p):
            assert i!=j and p[j]==i
            if i<j:
                stack.append(j)
            else:
                assert stack.pop()==i
        assert not stack
    assert connected(pair)


def run():
    small=[seed(4,[204,218,102,214,182,246,222,153,173]),
           seed(5,[792,660,820,396,844,716,972,812,828,594,561])]
    coloured_small=[
        seed(4,[17544,21128,4488,9608,34884,8772,37444,10564,21156,18852,
                8852,19092,17442,17554,34898,37962,34833],True),
        seed(5,[270864,135696,299536,68112,297488,338448,34320,540936,135432,
                594184,561416,332424,280200,135752,332328,540804,270916,663876,
                565524,540738,540705],True)]
    odd=((1,0,3,2,7,6,5,4),(7,6,5,4,3,2,1,0))
    for m in range(4,151):
        validate(odd)
        v=ears(odd)
        assert sum(v)==2*m-3 and sum(v[::2])-sum(v[1::2])==-1
        cv=coloured(odd)
        assert (sum(cv[:2*m]),sum(cv[2*m:]))==(m-1,m-2)
        if m>=6:
            a,b=(insert_site(rainbow_pair(m-1),s) for s in (3,4))
            swap=insert_site(rainbow_pair(m-1),3,True)
            for pair in (a,b,swap,rainbow_pair(m)):
                validate(pair)
            assert sum(ears(rainbow_pair(m)))==4 and sum(ears(a))==sum(ears(b))==6
            assert [x-y for x,y in zip(ears(a),ears(b))]==[int(i==3)-int(i==5) for i in range(2*m)]
            def difference(x,y):
                return [i for i,v in enumerate(zip(coloured(x),coloured(y))) if v==(1,0)]
            assert difference(a,swap)==[3,2*m+4] and difference(swap,a)==[4,2*m+3]
            assert difference(a,b)==[3,2*m+4] and difference(b,a)==[4,2*m+5]
            assert gcd(2,sum(v)-4)==1
        odd=extend_ear(odd)
    return dict(coordinates="Gap i joins i to i+1 mod 2m; bit i is the coefficient of 2^i.",
                exact_small_minors=small,bank_labelled_minors=coloured_small,construction_tested_orders=[6,150],
                scope="Large-order tests supplement the all-order proof.")


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    result=run()
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print([(r["order"],r["determinant"]) for r in result["exact_small_minors"]])
