"""Independently test the three-window placement theorem on labelled Dyck pairs."""
from collections import Counter
from itertools import combinations
from math import comb


def dyck_partners(size):
    sites = 2 * size
    for openings in combinations(range(sites), size):
        opening_set = set(openings)
        stack = []
        partner = [-1] * sites
        for site in range(sites):
            if site in opening_set:
                stack.append(site)
            elif stack:
                earlier = stack.pop()
                partner[site], partner[earlier] = earlier, site
            else:
                break
        else:
            yield partner


def connected(top, bottom):
    index = current = 0
    while True:
        current = bottom[top[current]]
        index += 1
        if current == 0:
            return 2 * index == len(top)


def hits(top, bottom):
    result = 0
    # Deleting the closing site leaves an odd open path. Its two external
    # rays cannot be internal edges of a three-site interval.
    for i in range(len(top) - 3):
        if ((top[i] == i + 1 and bottom[i + 1] == i + 2) or
                (bottom[i] == i + 1 and top[i + 1] == i + 2)):
            result |= 1 << i
    return result


def check_order(n):
    banks = list(dyck_partners(n + 1))
    assert len(banks) == comb(2 * n + 2, n + 1) // (n + 2)
    population = Counter(hits(a, b) for a in banks for b in banks if connected(a, b))
    expected_gaps = (1, 1) if n <= 4 else (2, 2)
    scores = {}
    for triple in combinations(range(2*n - 1), 3):
        tested = sum(1 << i for i in triple)
        scores[triple] = sum(count for mask, count in population.items() if not (tested & mask))
    best = min(scores.values())
    for (a, b, c), score in scores.items():
        assert (score == best) == ((b-a, c-b) == expected_gaps)
    return sum(population.values()), len(scores), best


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Enable Python assertions.")
    for order in range(2, 8):
        diagrams, placements, minimum = check_order(order)
        print(f"n={order}: {diagrams} diagrams, {placements} placements, minimum avoidance {minimum}")

