"""Independently check small-order ear lattices from all labelled diagrams."""
from functools import cache
from itertools import product
import json
from pathlib import Path
from sympy import Matrix, eye
from sympy.matrices.normalforms import hermite_normal_form, smith_normal_form
from sympy.polys.domains import ZZ


def certificate_file():
    here = Path(__file__).resolve().parent
    bundled = here / "ear_lattice.json"
    return bundled


@cache
def matchings(lo, hi):
    """Use the partner of the left endpoint to split an interval in two."""
    if lo == hi:
        return ((),)
    return tuple(
        ((lo, partner),) + left + right
        for partner in range(lo + 1, hi, 2)
        for left in matchings(lo + 1, partner)
        for right in matchings(partner + 1, hi)
    )


def reaches_all(arcs, size):
    reached = {0}
    while True:
        previous = len(reached)
        reached |= {v for a, b in arcs for u, v in ((a, b), (b, a)) if u in reached}
        if len(reached) == previous:
            return len(reached) == size


def differences(vectors):
    return Matrix([[x - y for x, y in zip(row, vectors[0])] for row in vectors[1:]]).T


def verify_certificates(records, m, size, gaps):
    catalogue = set(matchings(0, size))
    for key in ("exact_small_minors", "bank_labelled_minors"):
        record, = [r for r in records[key] if r["order"] == m]
        vectors = []
        for upper, lower in record["pairs"]:
            banks = []
            for partners in (upper, lower):
                assert len(partners) == size
                assert all(0 <= j < size and partners[j] == i and i != j for i, j in enumerate(partners))
                arcs = tuple((i, j) for i, j in enumerate(partners) if i < j)
                assert arcs in catalogue
                banks.append(arcs)
            assert reaches_all(banks[0] + banks[1], size)
            if key == "bank_labelled_minors":
                bits = [int(g in bank) for bank in banks for g in gaps]
            else:
                bits = [int(g in banks[0] + banks[1]) for g in gaps]
            vectors.append(bits)
        assert record["masks"] == [sum(x << i for i, x in enumerate(v)) for v in vectors]
        assert differences(vectors).det(method="domain-ge") == record["determinant"] == -1


def verify(m):
    size = 2 * m
    gaps = [tuple(sorted((i, (i + 1) % size))) for i in range(size)]
    split = []
    combined = []
    for upper, lower in product(matchings(0, size), repeat=2):
        if reaches_all(upper + lower, size):
            bits = [int(gap in bank) for bank in (upper, lower) for gap in gaps]
            split.append(bits)
            combined.append([a + b for a, b in zip(bits[:size], bits[size:])])
    bases = [hermite_normal_form(differences(vectors)) for vectors in (combined, split)]
    assert len(split) == {2: 2, 3: 8, 4: 42, 5: 262}[m]
    if m >= 4:
        assert bases == [eye(size), eye(2 * size)]
        verify_certificates(json.loads(certificate_file().read_bytes()), m, size, gaps)
    else:
        assert [basis.cols for basis in bases] == {2: [0, 1], 3: [3, 6]}[m]
        for basis in bases:
            if basis.cols:
                smith = smith_normal_form(basis, domain=ZZ)
                assert all(abs(d) == 1 for d in smith.diagonal())
    return len(split), [basis.cols for basis in bases]


if __name__ == "__main__":
    for order in (2, 3, 4, 5):
        count, ranks = verify(order)
        print(f"m={order}, diagrams={count}, combined rank={ranks[0]}, split rank={ranks[1]}")
