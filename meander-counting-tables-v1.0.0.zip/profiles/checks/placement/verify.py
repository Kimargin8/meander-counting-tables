"""Enumerate rooted, bank-labelled diagrams and check all prescribed hit sets."""
import argparse
from functools import cache
from itertools import combinations
import json
from pathlib import Path


@cache
def matchings(n):
    if n == 0:
        return ((),)
    result = []
    for k in range(n):
        mate = 2*k+1
        for left in matchings(k):
            for right in matchings(n-1-k):
                result.append((mate, *(1+x for x in left), 0, *(mate+1+x for x in right)))
    return tuple(result)


def supersets(frequencies):
    values = frequencies.copy()
    bit = 1
    while bit < len(values):
        for base in range(0, len(values), 2*bit):
            for i in range(base, base+bit):
                values[i] += values[i+bit]
        bit *= 2
    return values


def closed_geometry(n):
    """Cut off the last site of a closed pair. Test individual bank exits directly."""
    size = 2*n+1
    starts = max(0, size-2)
    flags = []
    for bank in matchings(n+1):
        intervals = 0
        for i in range(starts):
            exits = sum(not i <= mate < i+3 for mate in bank[i:i+3])
            intervals += (exits == 1) << i
        ears = sum((bank[i] == i+1) << i for i in range(size-1))
        flags.append((bank, intervals, ears))
    hits = [0]*(1 << starts)
    arch = [0]*(1 << (size-1))
    even_at_next_order = 0
    for upper, up_intervals, up_ears in flags:
        height = exposed = 0
        for i, mate in enumerate(upper):
            if mate > i:
                exposed += height == 0
                height += 1
            else:
                height -= 1
        for lower, low_intervals, low_ears in flags:
            vertex = lower[upper[0]]
            length = 1
            while vertex:
                vertex = lower[upper[vertex]]
                length += 1
            if length == n+1:
                hits[up_intervals & low_intervals] += 1
                arch[up_ears | low_ears] += 1
                even_at_next_order += exposed
    return hits, supersets(arch), even_at_next_order


def hyp(starts, n, archives):
    groups = []
    for i in starts:
        if groups and i <= groups[-1][-1]+2:
            groups[-1].append(i)
        else:
            groups.append([i])
    deleted = free = ears = 0
    for group in groups:
        width = group[-1]-group[0]+3
        if width % 2:
            free += 1
            deleted += width-1
        else:
            ears |= 1 << (group[0]-deleted)
            deleted += width-2
    return (1 << free)*archives[n-deleted//2][ears]


def scores(n, closed, even):
    m = n-1
    a, A = closed[m-1:m+1]
    b, B = even[m-1:m+1]
    return {"11": 4*B, "12": 2*B+6*A-2*b, "22": 8*A-2*a,
            "13": 2*B+8*A-4*b, "23": 10*A-4*a, "33": 12*A-8*a}


def gap_type(starts):
    x, y, z = starts
    return "".join(map(str, sorted((min(y-x,3),min(z-y,3)))))


def table(path):
    return dict(tuple(map(int, line.split())) for line in path.read_text().splitlines()
                if line and line[0].isdigit())


def check(maximum=7):
    archives = []
    rows = []
    closed, even = [1], [1]
    counterexample = []
    for n in range(maximum+1):
        hits, ears, e = closed_geometry(n)
        archives.append(ears)
        closed.append(sum(hits))
        even.append(e)
        intersection = supersets(hits)
        # Avoidance is a subset query on the complement of the set of actual hits.
        avoidance = supersets(list(reversed(hits)))
        start_count = max(0, 2*n-1)
        for mask, actual in enumerate(intersection):
            starts = [i for i in range(start_count) if mask & (1 << i)]
            assert hyp(starts,n,archives) == actual, (n, starts, actual)
        observed = {}
        placements = 0
        for starts in combinations(range(start_count),3):
            kind = gap_type(starts)
            mask = sum(1 << i for i in starts)
            d = avoidance[mask]
            formula = closed[n+1]-6*closed[n]+scores(n,closed,even)[kind]
            assert d == formula
            assert observed.setdefault(kind,d) == d
            placements += 1
        if n >= 2:
            best = "11" if n <= 4 else "22"
            assert [k for k,v in observed.items() if v == min(observed.values())] == [best]
        if n == 4:
            for starts in ((0,1,4,5),(0,1,5,6)):
                mask = sum(1 << i for i in starts)
                counterexample.append(dict(starts=list(starts), all_four=intersection[mask],
                                           none=avoidance[mask]))
        assert intersection[0] == avoidance[0] == closed[n+1]
        rows.append(dict(n=n,diagrams=closed[n+1],all_masks=1 << start_count,three_placements=placements,
                         avoidance=observed))
    assert [x["all_four"] for x in counterexample] == [4,6]
    assert [x["none"] for x in counterexample] == [66,68]
    return dict(rows=rows, four=counterexample,
                total_three_placements=sum(row["three_placements"] for row in rows),
                total_masks=sum(row["all_masks"] for row in rows),
                total_diagrams=sum(row["diagrams"] for row in rows))


def table_extrema(closed_file, open_file):
    M = table(closed_file)
    O = table(open_file)
    closed = [M[i] for i in range(max(M)+1)]
    even = [O[2*i] for i in range(max(O)//2+1)]
    rows = []
    for n in range(2, min(len(even)+1,len(closed)-1)):
        values = {k:v+M[n+1]-6*M[n] for k,v in scores(n,closed,even).items()
                  if sum(map(int,k)) <= 2*n-2}
        rows.append(dict(n=n, minimum=[k for k,v in values.items() if v==min(values.values())],
                         maximum=[k for k,v in values.items() if v==max(values.values())],avoidance=values))
    return rows


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--maximum",type=int,default=7)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--tables",type=Path,nargs=2,metavar=("CLOSED","OPEN"))
    args=parser.parse_args()
    if not __debug__ or not 4<=args.maximum<=8:
        raise ValueError("Use enabled assertions and a maximum between four and eight")
    result=check(args.maximum)
    if args.tables:
        result["tabular_extrema"]=table_extrema(*args.tables)
    text=json.dumps(result,indent=2)+"\n"
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(text,encoding="utf8")
    else:
        print(text,end="")
