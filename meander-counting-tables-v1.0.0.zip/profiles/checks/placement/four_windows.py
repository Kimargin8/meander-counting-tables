"""Four-window avoidance from closed counts, one-mark counts and a two-mark remainder."""
from fractions import Fraction
from itertools import combinations,product
import json
from pathlib import Path
import sys


def contract(starts):
    blocks=[]
    for s in starts:
        if blocks and s<=blocks[-1][-1]+2:
            blocks[-1].append(s)
        else:
            blocks.append([s])
    deleted=0
    free=0
    marks=[]
    for group in blocks:
        w=group[-1]-group[0]+3
        if w%2:
            free+=1
            deleted+=w-1
        else:
            marks.append(group[0]-deleted)
            deleted+=w-2
    return deleted//2,2**free,marks


def correction(gaps,M,E):
    starts=[0]
    for d in gaps:
        starts.append(starts[-1]+d)
    lower=upper=0
    for k in range(2,5):
        for group in combinations(starts,k):
            delta,mul,marks=contract(group)
            if len(marks)==2:
                assert k==4 and tuple(min(3,x) for x in gaps)==(1,3,1)
                assert marks[1]-marks[0]==gaps[1]-1 and mul==1
                upper+=2*E(delta+1)
            else:
                change=(-1)**k*mul*(2*E(delta+1) if marks else M(delta))
                lower+=change
                upper+=change
    return lower,upper


TYPES=[g for g in product((1,2,3),repeat=3) if g<=g[::-1]]


def finite(closed,even):
    rows=[]
    for n in range(3,min(max(closed)-1,max(even)//2+1)+1):
        terms={g:correction(g,lambda d:closed[n+1-d],lambda d:even[2*(n+1-d)])
               for g in TYPES if sum(g)<=2*n-2}
        certain=[g for g,(_,hi) in terms.items() if all(hi<lo for other,(lo,_) in terms.items() if g!=other)]
        possible_max=[g for g,(_,hi) in terms.items() if hi>=max(lo for lo,_ in terms.values())]
        rows.append(dict(n=n,certain_min=certain,possible_max=possible_max,
                         corrections={''.join(map(str,k)):v for k,v in terms.items()}))
    return rows


def polynomial(gaps,t):
    # Normalize by M_{n-1}. All needed closed terms have exponent delta-2 >=0.
    samples=[correction(gaps,lambda d:r**(d-2),lambda d:t*r**(d-2))[0] for r in range(1,5)]
    def basis(values):
        return [values[0],*(basis([y-x for x,y in zip(values,values[1:])]) if len(values)>1 else [])]
    from math import factorial
    coeff=[Fraction(0)]*4
    p=[1]
    for k,a in enumerate(basis(samples)):
        for i,b in enumerate(p):
            coeff[i]+=Fraction(a,factorial(k))*b
        p=[x-(k+1)*y for x,y in zip([0,*p],[*p,0])]
    assert not coeff[-1]
    return coeff[:3]


def asymptotic():
    # Every subsequential t=E_m/M_m is bounded and has the same limit at
    # either of the two preceding indices along that subsequence.
    lo,hi=Fraction(100,1291),Fraction(1,11)
    ts=(Fraction(37,16),Fraction(86,25))
    target=(2,2,2)
    margins={}
    for g in TYPES:
        if g==target:
            continue
        bounds=[]
        for t in ts:
            a,b,c=[x-y for x,y in zip(polynomial(g,t),polynomial(target,t))]
            # Coefficients in the Bernstein basis of the quadratic on [lo,hi].
            values=[a+b*lo+c*lo**2,a+b*(lo+hi)/2+c*lo*hi,a+b*hi+c*hi**2]
            bounds.extend(values)
        margins[''.join(map(str,g))]=str(min(bounds))
    assert all(Fraction(m)>0 for m in margins.values())
    return margins


def direct():
    from verify import closed_geometry,supersets
    counts,opens=[1],[1]
    cases=0
    for n in range(8):
        h,_,e=closed_geometry(n)
        counts.append(sum(h))
        opens.append(e)
        exc=supersets(list(reversed(h)))
        best=[]
        score=None
        for starts in combinations(range(max(0,2*n-1)),4):
            gaps=tuple(b-a for a,b in zip(starts,starts[1:]))
            lo,hi=correction(gaps,lambda d:counts[n+1-d],lambda d:opens[n+1-d])
            observed=exc[sum(1<<i for i in starts)]
            base=counts[n+1]-8*counts[n]
            assert base+lo<=observed<=base+hi
            if score is None or observed<score:
                best=[]
                score=observed
            if score==observed:
                best.append(gaps)
            cases+=1
        if n>=3:
            assert set(best)=={(1,1,1)}
    return cases


if __name__=="__main__":
    def table(path):
        return dict(tuple(map(int,s.split())) for s in Path(path).read_text().splitlines()
                    if s.strip() and s[0].isdigit())
    m,e=map(table,sys.argv[1:3])
    rows=finite(m,e)
    margins=asymptotic()
    assert all(r["certain_min"]==([(1,1,1)] if r["n"]<=7 else [(2,2,2)]) for r in rows)
    out=dict(finite=rows,bernstein_lower_bounds=margins,direct_placements=direct())
    Path(sys.argv[3]).write_text(json.dumps(out,indent=2)+"\n")
    print([(r["n"],r["certain_min"]) for r in rows])
    print(margins)
