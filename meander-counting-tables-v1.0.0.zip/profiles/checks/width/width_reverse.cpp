// Compute confined closed counts and confined specified upper ears by the reverse recurrence.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

using Word = std::uint32_t;

struct Count{ std::uint64_t a{},b{},c{}; };
void add(Count& x,const Count& y){
    const auto a=x.a+y.a, b=x.b+y.b;
    const auto t=a<x.a;
    const auto c=(b<x.b || b+t<b);
    // At most 4^L walks at length L <= 94, hence fewer than 2^192.
    x.a=a; x.b=b+t; x.c+=y.c+c;
}
std::string decimal(Count v){
    std::string text;
    while(v.a||v.b||v.c){
       unsigned __int128 p=v.c; v.c=p/10; p=((p%10)<<64)|v.b;
       v.b=p/10; p=((p%10)<<64)|v.a; v.a=p/10; text.push_back('0'+int(p%10));
    }
    if(text.empty()) return "0";
    std::reverse(text.begin(),text.end()); return text;
}
void words(int n,int pos,int level,Word word,std::vector<Word>& answer){
    if(pos==n){answer.push_back(word);return;}
    if(n-pos>level) words(n,pos+1,level+1,word|(1u<<pos),answer);
    if(level>0) words(n,pos+1,level-1,word,answer);
}

struct Node {int start,slit,outer[2];};
int main(int argc,char** argv){
    if(argc!=3) return 1;
    const int bound=std::stoi(argv[1]),orders=std::stoi(argv[2]);
    if(bound%2 || bound<2 || bound>30 || orders<2 || orders>47) return 2;
    std::vector<std::vector<Word>> by_width(bound+1);
    std::vector<std::unordered_map<Word,int>> bases(bound+1);
    int size=0;
    for(int w=2;w<=bound;w+=2){
        words(w,0,0,0,by_width[w]);
        for(auto p:by_width[w]){
            bases[w].emplace(p,size);
            size+=w/2+1;
        }
    }
    std::vector<Node> nodes(size);
    for(int w=2;w<=bound;w+=2) for(auto p:by_width[w]){
        int mate[32],stack[32],top=0;
        for(int i=0;i<w;++i){
            if(p&(1u<<i)) stack[top++]=i;
            else {const int j=stack[--top];mate[i]=j;mate[j]=i;}
        }
        Word reflected=0;
        for(int i=0;i<w;++i) if(!(p&(1u<<i))) reflected|=1u<<(w-1-i);
        const auto start=bases[w].at(p), opposite=bases[w].at(reflected);
        for(int u=0;u<=w/2;++u){
            // Swapping the sides reverses endpoint order and interchanges matching brackets.
            const int right=u<w/2 ? start+u+1 : opposite+u-1;
            Node node{u>0 ? start+u-1:-1, right, {-1,-1}};
            if(w<bound){
                const Word mask=(1u<<u)-1;
                const Word pat=(p&mask)|(1u<<u)|((p>>u)<<(u+2));
                node.outer[0]=bases[w+2].at(pat)+u+1;
            } else node.outer[0]=-2-u;
            if(u>0 && u<w && mate[u-1]!=u){
                const int a=mate[u-1],b=mate[u];
                const Word exp=(p|(1u<<std::min(a,b)))&~(1u<<std::max(a,b));
                const Word mask=(1u<<(u-1))-1;
                const Word pat=(exp&mask)|((exp>>(u+1))<<(u-1));
                node.outer[1]=bases[w-2].at(pat)+u-1;
            }
            nodes[start+u]=node;
        }
    }


    // In reverse time every state asks for the weights of its four permitted
    // successors. The root gives all bounded-width closed diagrams, its shifted
    // neighbor gives diagrams in which the upper arch at sites 1,2 is specified.
    const int root=bases[2].at(1)+1, shifted=nodes[root].start;
    bases.clear();by_width.clear();
    std::vector<Count> current(size),next(size);
    current[root].a=1;
    std::cout<<"# width "<<bound<<" orders "<<orders<<" states "<<size<<std::endl;
    for(int dist=0;dist<=2*orders-2;++dist){
        if(dist%2==0) std::cout<<"C "<<(dist+2)/2<<" "<<decimal(current[root])<<std::endl;
        else std::cout<<"B "<<(dist+3)/2<<" "<<decimal(current[shifted])<<std::endl;
        if(dist==2*orders-2) break;
        #pragma omp parallel for schedule(static)
        for(int i=0;i<size;++i){
            Count out{};
            const auto &v=nodes[i];
            for(int j:{v.start,v.slit,v.outer[0],v.outer[1]}) if(j>=0) add(out,current[j]);
            next[i]=out;
        }
        current.swap(next);
    }
}
