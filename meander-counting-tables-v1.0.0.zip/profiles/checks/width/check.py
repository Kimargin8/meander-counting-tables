"""Chord enumeration, held-out open counts and profile-certificate cross-checks."""
import argparse
import json
from collections import Counter
from fractions import Fraction
from functools import cache
from itertools import product
from math import comb
from pathlib import Path
from zipfile import ZipFile

from marked_ear import build, calculate, integer_table
from joint import joint_certificate


@cache
def matchings(n):
    if not n:
        return ((),)
    result=[]
    for left_size in range(n):
        j=2*left_size+1
        for left,right in product(matchings(left_size),matchings(n-1-left_size)):
            result.append((j,)+tuple(x+1 for x in left)+(0,)+tuple(x+j+1 for x in right))
    return tuple(result)


def small_oracle():
    hist=Counter()
    for n in range(1,8):
        for upper,lower in product(matchings(n),repeat=2):
            vertex=0
            for moves in range(1,n+1):
                vertex=lower[upper[vertex]]
                if vertex==0:
                    break
            if moves!=n:
                continue
            width=maximum=0
            steps=[]
            for i in range(2*n):
                top,bottom=(upper[i]>i),(lower[i]>i)
                width+=2*(int(top)+int(bottom)-1)
                maximum=max(maximum,width)
                steps.append((top,bottom))
            reduced=all((steps[i],steps[i+1]) not in
                        (((True,False),(False,True)),((False,True),(True,False)))
                        for i in range(1,2*n-2,2))
            hist[n,maximum,upper[0]==1,reduced]+=1
    tail=lambda n,w,ear=False,red=False: sum(value for (size,width,has_ear,is_red),value in hist.items()
                                            if size==n and width>w and (not ear or has_ear)
                                            and (not red or is_red))
    checked=0
    for n in range(2,8):
        for w in range(2,2*n+1,2):
            e=tail(n,w,True)
            fixed=tail(n-1,w)
            retained=sum(comb(n-2,s-2)*2**(n-s)*tail(s,w,True,True)
                         for s in range(2,n+1))
            assert e==fixed+retained
            assert 2*tail(n,w,True,True)<=tail(n,w,False,True)
            checked+=1
    return dict(identities_by_order_and_cap=checked,connected_diagrams=sum(hist.values()))


def run(path):
    result=small_oracle()
    with ZipFile(path) as archive:
        closed=integer_table(archive.read('data/b005315.txt'))
        known=integer_table(archive.read('data/b005316.txt'))
    domain,a,b,q,c,_,_=build(path,exact_open_through=24)
    exact_b=[1]+[known[2*j] for j in range(1,30)]
    exact_a=[closed[j+1] for j in range(30)]
    def direct_primitive(ordinary):
        result=[0]
        for i in range(1,len(ordinary)):
            result.append(ordinary[i]-sum(result[j]*ordinary[i-j] for j in range(1,i)))
        return result
    exact_c,exact_q=direct_primitive(exact_b),direct_primitive(exact_a)
    for n in range(24,30):
        for lhs,rhs,observed in ((b[n],a[n],Fraction(exact_b[n],exact_a[n])),
                                 (c[n],q[n],Fraction(exact_c[n],exact_q[n]))):
            assert domain.quotient(lhs,rhs,False)<=observed<=domain.quotient(lhs,rhs,True)
    result['withheld_open_orders']=[2*24,2*29]
    result['held_out_ratio_enclosures']=12
    singles=calculate(path)['rows']
    result['max_upper_by_pair_index']={}
    for n,pct in ((45,90),(46,99)):
        target=Fraction(pct,100)
        for i in (1,2,3,4):
            r=joint_certificate(path,n,i,target)
            assert Fraction(r['proof']['lower'])>0
        assert max(map(Fraction,singles[n]['upper_by_smaller_part'][4:]))<target
        result['max_upper_by_pair_index'][n]=str(target)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    args=parser.parse_args()
    print(json.dumps(run(args.input),indent=2))
