"""A rational lower bound for the joint profile comparison on product simplices."""
import argparse
import json
from fractions import Fraction
from pathlib import Path

from marked_ear import build


def plus(a,b):
    return tuple(x+y for x,y in zip(a,b,strict=True))


def minus(a,b):
    return tuple(x-y for x,y in zip(a,b,strict=True))


def joint_certificate(path, n, split, target=Fraction(1)):
    domain,a,b,q,c,_,_=build(path)
    assert not any(q[split][1:]) and not any(c[split][1:])
    den,num=q[split][0],c[split][0]
    forms=(q[n-split],b[n],c[n-split],a[n])
    def bilinear(v,w):
        return (target.numerator*den*(v[0]*w[1]+v[1]*w[0])
                -target.denominator*num*(v[2]*w[3]+v[3]*w[2]))

    # The four coordinate values in the product are doubled to keep integral vertices.
    base=tuple(2*row[0] for row in forms)
    groups=[]
    for i,(lo,hi) in enumerate(domain.intervals):
        options={tuple((2*d)*row[2*i+1]+twice_e*row[2*i+2] for row in forms)
                 for d in (lo,hi) for twice_e in (0,d)}
        if len(options)==1:
            base=plus(base,options.pop())
        else:
            groups.append(sorted(options))
    return dict(n=n,small=split,groups=len(groups),ratio_target=str(target),
                proof=quadratic_bound(base,groups,bilinear))


def quadratic_bound(base,groups,bilinear):
    # Choose a vertex as an expansion origin. The bound below is valid for every origin.
    chosen=[g[0] for g in groups]
    center=base
    for v in chosen:
        center=plus(center,v)
    for _ in range(100):
        changed=False
        for i,g in enumerate(groups):
            previous=chosen[i]
            remainder=minus(center,previous)
            v=min(g,key=lambda u:bilinear(plus(remainder,u),plus(remainder,u)))
            if previous!=v:
                chosen[i]=v
                center=plus(remainder,v)
                changed=True
        if not changed:
            break
    deviations=[[minus(v,ref) for v in g] for g,ref in zip(groups,chosen,strict=True)]
    origin=bilinear(center,center)
    # Expand B(V,V)-B(C,C)=sum_g B(2C+sum_h d_h,d_g).
    # Conditional on a vertex of d_g, all inner minima may be bounded separately.
    contributions=[min(2*bilinear(center,x)+sum(min(bilinear(x,y) for y in h)
                                                  for h in deviations) for x in g)
                   for g in deviations]
    return dict(lower=origin+sum(contributions),origin=origin,
                origin_indices=[g.index(v) for g,v in zip(groups,chosen,strict=True)],
                contributions=contributions)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    options=parser.parse_args()
    results=[joint_certificate(options.input,n,i,Fraction(limit,100))
             for n,limit in ((45,90),(46,99)) for i in (1,2,3,4)]
    assert all(Fraction(v['proof']['lower'])>0 for v in results)
    print(json.dumps(results,indent=2))
