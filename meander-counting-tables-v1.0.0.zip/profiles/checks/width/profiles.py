"""Exact interval arithmetic for closed counts, the specified short arch, and primitive profiles."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from tail import reduced_bounds,tail_bounds


def integer_table(path):
    return dict(tuple(map(int,line.split())) for line in path.read_text().splitlines()
                if line.strip() and not line.startswith("#"))


def primitive(words):
    out=[0]
    for i in range(1,len(words)):
        out.append(words[i]-sum(out[j]*words[i-j] for j in range(1,i)))
    return out


def primitive_bounds(lo,hi,first):
    # With all uncertain entries past degree first-1, the quadratic Taylor
    # remainder starts in degree 2*first.
    size=len(lo)
    assert len(hi)==size and size<=2*first and lo[:first]==hi[:first]
    base=primitive(lo[:first]+[0]*(size-first))
    inv=[1]+[-v for v in base[1:]]
    direction=[sum(inv[j]*inv[i-j] for j in range(i+1)) for i in range(size-first)]
    low,high=base.copy(),base.copy()
    for i in range(first,size):
        for j in range(first,i+1):
            v=direction[i-j]
            low[i]+=v*(lo[j] if v>=0 else hi[j])
            high[i]+=v*(hi[j] if v>=0 else lo[j])
    return low,high


def analyze(closed_file,open_file,reverse_file,exceptional_file,reduced_file=None):
    exact=integer_table(closed_file); even=integer_table(open_file)
    lines=[s.split() for s in reverse_file.read_text().splitlines()]
    expected=int(lines[0][4]); width=int(lines[0][2])
    C={int(v[1]):int(v[2]) for v in lines if v[0]=="C"}
    B={int(v[1]):int(v[2]) for v in lines if v[0]=="B"}
    assert max(C)==max(B)==expected
    lines=[s.split() for s in exceptional_file.read_text().splitlines()]
    assert int(lines[0][2])==width and int(lines[0][4])==expected
    U={int(v[0]):list(map(int,v[1:])) for v in lines[1:]}
    T,proofs=tail_bounds(expected,exact,C,U)
    tail_lower={i:exact[i]-C[i] if i in exact else 0 for i in C}
    red_cert={}
    if reduced_file:
        lines=[s.split() for s in reduced_file.read_text().splitlines()]
        assert int(lines[0][2])==width and int(lines[0][4])==expected and lines[0][-2:]==["reduced","1"]
        u_red={int(v[0]):list(map(int,v[1:])) for v in lines[1:]}
        tail_lower,other,red_cert=reduced_bounds(expected,exact,C,u_red)
        T={i:min(T[i],other[i]) for i in C}
    lowM=[1]+[C[i]+tail_lower[i] for i in range(1,expected+1)]
    highM=[1]+[C[i]+T[i] for i in range(1,expected+1)]
    lowB=[1];highB=[1]
    for n in range(1,expected):
        L=max(B[n+1], ((2*n-3)*lowM[n]+2*n*lowB[n-1]+n-1)//n)
        # Reflection exchanges the two disjoint first-ear events in the width tail.
        H=min(B[n+1]+T[n+1]//2,highM[n+1]//2)
        if 2*n in even:
            assert L<=even[2*n]<=H
            L=H=even[2*n]
        assert L<=H
        lowB.append(L);highB.append(H)
    lowQ,_=primitive_bounds(lowM[1:],highM[1:],max(exact))
    _,highC=primitive_bounds(lowB,highB,max(even)//2+1)
    cap=[0]+[min(Fraction(1,2),Fraction(highC[i],lowQ[i])) if lowQ[i]>0
             else Fraction(1,2) for i in range(1,expected)]
    # The unknown excess in M_(i+1) appears in both primitive coefficients.
    # Its contribution to the numerator is at most half its contribution to
    # the denominator, as the two possible first ears are disjoint.
    for i in range(max(exact),expected):
        u=B[i+1]+highC[i]-highB[i]
        v=C[i+1]+lowQ[i]-lowM[i+1]
        left,right=tail_lower[i+1],T[i+1]
        if v+left>0:
            coupled=max(Fraction(2*u+z,2*(v+z)) for z in (left,right))
            cap[i]=min(cap[i],coupled)
    decisions={}
    for n in range(2,expected):
        p=Fraction(lowB[n],highM[n+1])
        one=[cap[i]*cap[n-i] for i in range(1,n//2+1)]
        missing=[i for i,x in enumerate(one,1) if x>=p and x>Fraction(3,20)]
        decisions[n]=dict(worst=str(max(one)/max(p,Fraction(3,20))),worst_small=one.index(max(one))+1,
                          unproved_smaller_parts=missing)
    farther=[(i,j) for i in range(1,expected) for j in range(1,expected)
             if i+j>=expected and cap[i]*cap[j]<=Fraction(3,20)]
    return dict(input_sha256={f.name:sha256(f.read_bytes()).hexdigest()
                              for f in (closed_file,open_file,reverse_file,exceptional_file,reduced_file) if f},
                width=width,bounds={i:dict(closed_lower=lowM[i],closed_upper=highM[i],
                    ear_lower=lowB[i-1],ear_upper=highB[i-1],tail_upper=T[i]) for i in range(2,expected+1)},
                tail_witness_j_k={i:[r[1],r[2]] for i,r in proofs.items()},
                reduced_witness=red_cert,
                primitive_caps=[str(x) for x in cap],comparisons=decisions,
                farther_pairs=farther)


if __name__=="__main__":
    args=argparse.ArgumentParser()
    for k in ("closed","opened","width","exceptional"):args.add_argument(k,type=Path)
    args.add_argument("--reduced",type=Path)
    files=args.parse_args()
    print(json.dumps(analyze(files.closed,files.opened,files.width,files.exceptional,files.reduced),indent=2))
