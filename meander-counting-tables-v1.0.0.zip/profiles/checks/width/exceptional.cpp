// Count pairs of Dyck paths that reach width > W, with finitely many allowed backtracks.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

// A length <= 94 word has at most 4^94 realizations, below 2^192.
struct Count { std::uint64_t a=0,b=0,c=0; };
void add(Count& x,const Count& y){
    const auto a=x.a+y.a,b=x.b+y.b;
    const auto t=a<x.a;
    x.c+=y.c+(b<x.b || b+t<b);
    x.a=a; x.b=b+t;
}
bool empty(const Count& x){return !(x.a||x.b||x.c);}
std::string decimal(Count v){
    std::string s;
    while(!empty(v)){
        unsigned __int128 p=v.c; v.c=p/10; p=(p%10<<64)|v.b;
        v.b=p/10; p=(p%10<<64)|v.a;
        v.a=p/10; s.push_back('0'+int(p%10));
    }
    if(s.empty()) return "0";
    std::reverse(s.begin(),s.end()); return s;
}
int main(int argc,char** argv){
    if(argc!=5 && argc!=6)return 1;
    std::ifstream f(argv[1]);
    const int W=std::stoi(argv[2]),N=std::stoi(argv[3]),K=std::stoi(argv[4]);
    if(W<2 || N<2 || N>47 || K<0 || K>32)return 2;
    int states,root; f>>states>>root;
    std::vector<std::array<int,5>> rules(states);
    for(auto &row:rules)for(auto &cell:row)if(!(f>>cell))return 3;
    const int H=N+1,pitch=2*(K+1);
    auto off=[&](int u,int l,int s){return ((u*H+l)*states+s)*pitch;};
    std::vector<Count> v(H*H*states*pitch),z(v),tail(K+1);
    v[off(1,1,root)].a=1;
    const bool reduced=argc==6&&std::string(argv[5])=="reduced";
    std::cout<<"# W "<<W<<" N "<<N<<" K "<<K<<" states "<<states<<" reduced "<<reduced<<std::endl;
    for(int t=1;t<2*N;++t){
        std::fill(z.begin(),z.end(),Count{});
        std::fill(tail.begin(),tail.end(),Count{});
        const int cap=std::min(t,2*N-t), limit=std::min(t+1,2*N-t-1);
        for(int u=t%2;u<=cap;u+=2)for(int l=t%2;l<=cap;l+=2){
            if(!u&&!l)continue;
            for(int s=0;s<states;++s){
                const auto &row=rules[s]; const auto in=off(u,l,s);
                for(int sym=0;sym<4;++sym){
                    const int dest=row[sym+1];
                    if(dest<0)continue;
                    const int a=u+2*(sym&1)-1,b=l+2*(sym>>1)-1;
                    if(std::min(a,b)<0||std::max(a,b)>limit)continue;
                    const int delta=(row[0]==1&&sym==2)||(row[0]==2&&sym==1);
                    if(reduced && t%2==0 && delta)continue;
                    const auto out=off(a,b,dest); const int big=a+b>W;
                    for(int h=0;h<=K-delta;++h)for(int seen=0;seen<2;++seen){
                        const auto &value=v[in+2*h+seen];
                        if(empty(value))continue;
                        const int flag=big|seen;
                        if(a==0&&b==0){
                            if(flag)add(tail[h+delta],value);
                        }else add(z[out+2*(h+delta)+flag],value);
                    }
                }
            }
        }
        if(t%2) {
            std::cout<<(t+1)/2;
            for(const auto &x:tail)std::cout<<" "<<decimal(x);
            std::cout<<std::endl;
        }
        v.swap(z);
    }
}
