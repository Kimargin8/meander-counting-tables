"""Finite upper bounds from marked, disjoint opposite slit shifts."""
from math import comb


def choices(c,j):
    # Adjacent marked edges of a path cannot both be removed.
    return comb(c-j+1,j) if c>=2*j-1 else 0


def tail_bounds(N,exact,closed,exceptional):
    hi={n:exact[n]-closed[n] for n in closed if n in exact}
    proofs={}
    for n in range(max(hi)+1,N+1):
        u=exceptional[n]
        best=None
        for j in range(1, min(n-2,(len(u)+1)//2)+1):
            # 2(n-j)-1 possible internal gaps. Repeated gaps permitted.
            ways=2**j*comb(2*n-j-2,j)
            for k in range(2*j-1,len(u)+1):
                threshold=choices(k,j)
                correction=sum((threshold-choices(c,j))*u[c] for c in range(k))
                bound=(ways*hi[n-j]+correction)//threshold
                if best is None or bound<best[0]:
                    best=(bound,j,k,ways,correction,threshold)
        hi[n]=best[0];proofs[n]=best
    return hi,proofs


def reduced_bounds(N, exact, closed, exceptional):
    """Remove all aligned inverse shifts, then charge remaining inverse shifts."""
    first=max(exact)+1
    lower,upper={},{}
    known={}
    for n in range(1,first):
        lower[n]=upper[n]=exact[n]-closed[n]
        known[n]=lower[n]-sum(comb(n-1,s-1)*2**(n-s)*known[s] for s in range(1,n))
        assert known[n]>=0
    core_upper=known.copy(); cert={}
    for n in range(first,N+1):
        row=exceptional[n]
        charge=2*(n-2)*(core_upper[n-1]+core_upper[n-2])
        candidates=[((charge+sum((k-c)*row[c] for c in range(k)))//k,k)
                    for k in range(1,len(row)+1)]
        core_upper[n],k=min(candidates)
        cert[n]=dict(core_upper=core_upper[n],threshold=k)
        lower[n]=sum(comb(n-1,s-1)*2**(n-s)*known[s] for s in known)
        upper[n]=sum(comb(n-1,s-1)*2**(n-s)*core_upper[s] for s in range(1,n+1))
    return lower,upper,cert
