"""Verify primitive replacement counts and the two-sided local ear bounds."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
from itertools import product
from math import comb
from pathlib import Path
import json
import platform
import sys


HERE = Path(__file__).resolve().parent
GEN = HERE
sys.path.insert(0, str(GEN))
from check_fluctuations import connected, sides


def table(path):
    rows = {}
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        fields = line.partition("#")[0].split()
        if fields:
            index, count = map(int, fields)
            rows[index] = count
    return rows


def quotient(num, den):
    assert den[0] == 1
    out = []
    for k, coeff in enumerate(num):
        out.append(coeff - sum(out[i]*den[k-i] for i in range(k)))
    return out


def suffices(side, windows):
    """Mask windows whose restriction exposes exactly one end on this side."""
    return sum(1 << j for j, window in enumerate(windows)
               if sum(side[i] not in window for i in window) == 1)


def verify_templates(k):
    nsites = 2*k+1
    windows = [frozenset(range(nsites-2*j-1, nsites)) for j in range(1, k)]
    candidates = [(s, suffices(s, windows)) for s in sides(nsites, 1)]
    totals = [0] * 4
    for (upper, u), (lower, v) in product(candidates, repeat=2):
        if u & v or not connected(upper, lower):
            continue
        edge = upper[-1] == nsites-2
        terminal = lower[-1] == -1
        for i, event in enumerate((True, upper[-1] == -1, edge, edge and terminal)):
            totals[i] += event
    return totals


def least(mask):
    return (mask & -mask).bit_length()


def verify_events(n, M, E, a, b, d, jcoef):
    K = (n-2)//2
    size = 2*n
    windows = []
    for anchor, direction in [(-1, -1), (1, 1), (1, -1), (0, 1)]:
        windows.append([frozenset((anchor+direction*t) % size for t in range(2*k+1))
                        for k in range(1, K+1)])
    candidates = [(p, [suffices(p, w) for w in windows]) for p in sides(size, 0)]
    counts = Counter()
    for (upper, u), (lower, v) in product(candidates, repeat=2):
        if not connected(upper, lower):
            continue
        counts["total"] += 1
        neutral = all(side[0] not in (1, size-1) for side in (upper, lower))
        if neutral:
            i, j = least(u[0] & v[0]), least(u[1] & v[1])
            counts["neutral-left", i] += 1
            counts["neutral-both", i, j] += 1
        if upper[0] == 1:
            i, j = least(u[2] & v[2]), least(u[3] & v[3])
            counts["ear-left", i] += 1
            counts["ear-both", i, j] += 1
    assert counts["total"] == M[n]
    tested = 0
    for i in range(1, K+1):
        m = n-i
        z = M[m]-4*E[m-1]+2*M[m-1]
        assert counts["neutral-left", i] == a[i]*z + 2*(a[i]-b[i])*(E[m-1]-M[m-1])
        assert counts["ear-left", i] == d[i]*M[m]
        tested += 2
        for j in range(1, K+1):
            m = n-i-j
            expected = (a[i]*a[j]*M[m] - 2*(a[i]*b[j]+a[j]*b[i])*E[m-1]
                        + 2*b[i]*b[j]*M[m-1])
            assert counts["neutral-both", i, j] == expected
            assert counts["ear-both", i, j] == jcoef[i]*jcoef[j]*E[m]
            tested += 2
    return dict(order=n, cutoff=K, connected=M[n], equalities=tested)


def verify_exposed_ends(n, M, E, a, b):
    K = (n-2)//2
    size = 2*n
    windows = [[frozenset(range(2*k+1)) for k in range(1,K+1)],
               [frozenset(range(size-2*k-1,size)) for k in range(1,K+1)]]
    def candidates(rays):
        return [(s, [suffices(s,w) for w in windows]) for s in sides(size,rays)]
    counts = Counter()
    for (upper,u), (lower,v) in product(candidates(2),candidates(0)):
        if not connected(upper,lower):
            continue
        counts["all"] += 1
        counts["one"] += upper[0] == -1
        counts["both"] += upper[0] == upper[-1] == -1
        if upper[0] != -1 and upper[-1] != -1:
            i, j = least(u[0]&v[0]), least(u[1]&v[1])
            counts["neither-left",i] += 1
            counts["neither-both",i,j] += 1
    assert (counts["all"],counts["one"],counts["both"]) == (E[n],M[n],E[n-1])
    tested = 3
    for i in range(1,K+1):
        m = n-i
        assert counts["neither-left",i] == a[i]*(E[m]-M[m])-b[i]*(M[m]-E[m-1])
        tested += 1
        for j in range(1,K+1):
            m = n-i-j
            predicted = (a[i]*a[j]*E[m] - (a[i]*b[j]+b[i]*a[j])*M[m]
                         + b[i]*b[j]*E[m-1])
            assert counts["neither-both",i,j] == predicted
            tested += 1
    return dict(order=n, cutoff=K, connected=E[n], equalities=tested)


def mul(a, b):
    out = [0] * (len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] += x*y
    return out


def combine(a, b, factor):
    out = [0] * max(len(a), len(b))
    for i, x in enumerate(a):
        out[i] += x
    for i, x in enumerate(b):
        out[i] += factor*x
    return out


def hom(poly, degree, L, U, den=1):
    """Clear denominators after substituting x=(L+U*s)/(den*(1+s))."""
    out = [0]*(degree+1)
    for i, value in enumerate(poly):
        a = [comb(i,j)*L**(i-j)*U**j for j in range(i+1)]
        b = [comb(degree-i,j) for j in range(degree-i+1)]
        for j, c in enumerate(mul(a,b)):
            out[j] += value*c*den**(degree-i)
    return out


def polynomials(a, b, K):
    A = [-a[i] for i in range(K, 0, -1)] + [1]
    B = [-b[i] for i in range(K, 0, -1)] + [1]
    P = combine([0]+mul(A,A), mul(B,B), 2)
    Q = [4*x for x in mul(A,B)]
    return A, B, P, Q


def cert_half_line(a, b, K):
    A, B, P, Q = polynomials(a,b,K)
    q = combine(mul([-1,1],mul(Q,Q)), mul(P,P), -1)
    assert min(hom(A,K,11,13)) > 0 and min(hom(B,K,11,13)) > 0
    t = hom(q, len(q)-1, 11, 13)
    assert min(t) > 0
    return dict(cutoff=K, interval=[11,13], transformed_coefficients=t)


def cert_weight_and_gap(a, b, K):
    _, _, P, Q = polynomials(a,b,K)
    checks = {
        "squared_amplitude_below_mu_minus_53_over_50":
            combine(mul([-53,50],mul(Q,Q)), mul(P,P), -50),
        "amplitude_below_86_over_25":
            combine([86*x for x in Q], P, -25),
        "ear_probability_below_67_over_250":
            combine([0]+[67*x for x in Q], P, -250)
    }
    records = {}
    for name, poly in checks.items():
        transformed = hom(poly,len(poly)-1,1100,1291,100)
        assert min(transformed) > 0
        records[name] = dict(degree=len(poly)-1, minimum_coefficient=min(transformed))
    return dict(interval="[11,1291/100]", cutoff=K, polynomials=records)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--order", type=int, default=8, choices=range(4,10))
    options = parser.parse_args()
    paths = [HERE.parent / "placement" / name for name in ("b005315.txt", "b005316.txt")]
    M, O = map(table, paths)
    E = {m//2:x for m,x in O.items() if m % 2 == 0}
    K = min(max(M)-1,max(E))
    T = [M[i+1] for i in range(K+1)]
    U = [E[i] for i in range(K+1)]
    a = quotient([0]+T[1:],T)
    b = quotient([0]+U[1:],U)
    d = quotient([0]+U[1:],T)
    jcoef = quotient([0]+T[:-1],U)
    templates = [verify_templates(i) for i in range(1,7)]
    assert templates == [[c[i] for c in (a,b,d,jcoef)] for i in range(1,7)]
    exact = [verify_events(n,M,E,a,b,d,jcoef) for n in range(4,options.order+1)]
    boundary = [verify_exposed_ends(n,M,E,a,b) for n in range(4,options.order+1)]
    result = dict(templates=templates, primitive_coefficients=dict(A=a,B=b,D=d,J=jcoef),
                  exact_local_events=exact, exact_open_extremes=boundary,
                  proof_certificate=cert_half_line(a,b,6),
                  weight_region_certificate=cert_weight_and_gap(a,b,6),
                  python=platform.python_version(), sha256={p.name:sha256(p.read_bytes()).hexdigest()
                  for p in [*paths,GEN/"check_fluctuations.py",Path(__file__)]})
    (HERE/"checks.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(f"Verified {sum(x['equalities'] for x in exact)} ear equalities, "
          f"{sum(x['equalities'] for x in boundary)} open-end equalities and 24 template counts.")


if __name__ == "__main__":
    main()
