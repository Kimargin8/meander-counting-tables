"""Independently enumerate connected diagrams and check signed weighted moments."""

from collections import Counter
from functools import cache
from hashlib import sha256
from itertools import product
from math import factorial, prod
from pathlib import Path
import json
import platform


@cache
def sides(size, rays):
    """Take horizontal steps only at height zero (a free ray must be exposed)."""
    matches = []
    partners = [-1] * size
    stack = []

    def visit(site, free_left):
        remaining = size - site
        if remaining < len(stack) + free_left:
            return
        if not remaining:
            matches.append(tuple(partners))
            return
        stack.append(site)
        visit(site + 1, free_left)
        stack.pop()
        if stack:
            other = stack.pop()
            partners[other], partners[site] = site, other
            visit(site + 1, free_left)
            partners[other] = partners[site] = -1
            stack.append(other)
        elif free_left:
            visit(site + 1, free_left - 1)

    visit(0, rays)
    return tuple(matches)


def connected(above, below):
    reached = {0}
    pending = [0]
    while pending:
        v = pending.pop()
        for w in (above[v], below[v]):
            if w >= 0 and w not in reached:
                reached.add(w)
                pending.append(w)
    return len(reached) == len(above)


def histogram(n, model):
    size = 2*n - (model == "odd_open")
    top_rays, bottom_rays = {"closed": (0, 0), "even_open": (2, 0),
                             "odd_open": (1, 1)}[model]
    counts = Counter()
    for upper, lower in product(sides(size, top_rays), sides(size, bottom_rays)):
        if connected(upper, lower):
            word = tuple(int(upper[v] == v+1 and lower[v+1] == v+2) -
                         int(lower[v] == v+1 and upper[v+1] == v+2)
                         for v in range(0, 2*n-2, 2))
            counts[word] += 1
    return counts


@cache
def exponents(length, degree):
    if not length:
        return ((),) if degree == 0 else ()
    return tuple((m, *tail) for m in range(degree+1)
                 for tail in exponents(length-1, degree-m))


def predicted_moment(weights, degree, totals, n):
    result = 0
    for powers in exponents(len(weights), degree):
        runs = []
        used = 0
        for i, m in enumerate(powers):
            if m:
                used += 1
                if i == 0 or powers[i-1] == 0:
                    runs.append(0)
                runs[-1] += m
        if all(total % 2 == 0 for total in runs):
            permutations = factorial(degree) // prod(factorial(m) for m in powers)
            coefficient = permutations * prod(w**m for w, m in zip(weights, powers))
            result += coefficient * 2**len(runs) * totals[n-used]
    return result


def weight_vectors(sites):
    vectors = {tuple(int(a <= i < b) for i in range(sites))
               for a in range(sites) for b in range(a+1, sites+1)}
    vectors.add(tuple((-1)**i for i in range(sites)))
    vectors.add(tuple((2, -1, 0)[i % 3] for i in range(sites)))
    return sorted(vectors)


def main():
    rows = {}
    degree_limit = 8
    for model in ("closed", "odd_open", "even_open"):
        rows[model] = []
        totals = {}
        for n in range(1, 8):
            words = histogram(n, model)
            totals[n] = sum(words.values())
            tests = 0
            for weights in weight_vectors(n-1):
                distribution = Counter()
                for word, count in words.items():
                    distribution[sum(a*b for a,b in zip(word, weights))] += count
                for degree in range(1, degree_limit+1):
                    measured = sum(count*value**degree for value,count in distribution.items())
                    expected = predicted_moment(weights, degree, totals, n)
                    if measured != expected:
                        raise AssertionError((model, n, weights, degree, measured, expected))
                    tests += 1
            rows[model].append(dict(n=n, diagrams=totals[n], signed_words=len(words),
                                    weighted_moments_checked=tests))
    assert [r["diagrams"] for r in rows["closed"]] == [r["diagrams"] for r in rows["odd_open"]]
    here = Path(__file__)
    output = dict(python=platform.python_version(), source_sha256=sha256(here.read_bytes()).hexdigest(),
                  arithmetic="unbounded integers", maximum_moment=degree_limit,
                  weights="every interval, alternating signs, repetitions of (2,-1,0)",
                  method="independent half-plane walks and graph connectivity", results=rows)
    here.with_name("checks.json").write_text(json.dumps(output, indent=2)+"\n", encoding="utf-8")
    print({model: sum(r["weighted_moments_checked"] for r in rows[model]) for model in rows})


if __name__ == "__main__":
    main()
