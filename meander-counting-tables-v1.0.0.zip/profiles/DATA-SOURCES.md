# Sequence data and attribution

Under checks/placement and checks/width, including the two b-files inside width-inputs.zip, the b-files are numerical snapshots of the cited sequence tables. Their index zero is retained when present in the reference input.

- The On-Line Encyclopedia of Integer Sequences, [A005315](https://oeis.org/A005315), [b-file](https://oeis.org/A005315/b005315.txt).
- The On-Line Encyclopedia of Integer Sequences, [A005316](https://oeis.org/A005316), [b-file](https://oeis.org/A005316/b005316.txt).

The OEIS Foundation Inc. and the individual contributors named in the linked entries provide the reference tables. The OEIS reference data are available under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). See the [OEIS End-User License Agreement](https://oeis.org/wiki/The_OEIS_End-User_License_Agreement). The sequence tables have separate terms from the manuscript and programs.
